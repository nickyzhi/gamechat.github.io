import re
import ast
from setuptools import setup
_version_re = re.compile(r'__version__\s+=\s+(.*)')
with open('flask/__init__.py', 'rb') as f:
    version = str(ast.literal_eval(_version_re.search(
        f.read().decode('utf-8')).group(1)))
setup(
    name='Flask',
    version=version,
    url='http://github.com/pallets/flask/',
    license='BSD',
    author='Armin Ronacher',
    author_email='armin.ronacher@active-4.com',
    description='A microframework based on Werkzeug, Jinja2 '
                'and good intentions',
    long_description=__doc__,
    packages=['flask', 'flask.ext'],
    include_package_data=True,
    zip_safe=False,
    platforms='any',
    install_requires=[
        'Werkzeug>=0.7',
        'Jinja2>=2.4',
        'itsdangerous>=0.21',
        'click>=2.0',
    ],
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.6',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
        'Topic :: Software Development :: Libraries :: Python Modules'
    ],
    entry_points='''
        [console_scripts]
        flask=flask.cli:main
    '''
)
from __future__ import print_function
from datetime import datetime
import os
import sys
import pkg_resources
sys.path.append(os.path.join(os.path.dirname(__file__), '_themes'))
sys.path.append(os.path.dirname(__file__))
extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.intersphinx',
    'flaskdocext'
]
templates_path = ['_templates']
source_suffix = '.rst'
master_doc = 'index'
project = u'Flask'
copyright = u'2010 - {0}, Armin Ronacher'.format(datetime.utcnow().year)
try:
    release = pkg_resources.get_distribution('Flask').version
except pkg_resources.DistributionNotFound:
    print('Flask must be installed to build the documentation.')
    print('Install from source using `pip install -e .` in a virtualenv.')
    sys.exit(1)
if 'dev' in release:
    release = ''.join(release.partition('dev')[:2])
version = '.'.join(release.split('.')[:2])
exclude_patterns = ['_build']
html_theme_path = ['_themes']
html_favicon = '_static/flask-favicon.ico'
html_static_path = ['_static']
html_sidebars = {
    'index': [
        'sidebarintro.html',
        'sourcelink.html',
        'searchbox.html'
    ],
    '**': [
        'sidebarlogo.html',
        'localtoc.html',
        'relations.html',
        'sourcelink.html',
        'searchbox.html'
    ]
}
html_use_modindex = False
html_show_sphinx = False
htmlhelp_basename = 'Flaskdoc'
latex_documents = [
  ('latexindex', 'Flask.tex', u'Flask Documentation', u'Armin Ronacher', 'manual'),
]
latex_use_modindex = False
latex_elements = {
    'fontpkg': r'\usepackage{mathpazo}',
    'papersize': 'a4paper',
    'pointsize': '12pt',
    'preamble': r'\usepackage{flaskstyle}'
}
latex_use_parts = True
latex_additional_files = ['flaskstyle.sty', 'logo.pdf']
intersphinx_mapping = {
    'python': ('https://docs.python.org/3/', None),
    'werkzeug': ('http://werkzeug.pocoo.org/docs/', None),
    'click': ('http://click.pocoo.org/', None),
    'jinja': ('http://jinja.pocoo.org/docs/', None),
    'sqlalchemy': ('http://docs.sqlalchemy.org/en/latest/', None),
    'wtforms': ('https://wtforms.readthedocs.io/en/latest/', None),
    'blinker': ('https://pythonhosted.org/blinker/', None)
}
try:
    __import__('flask_theme_support')
    pygments_style = 'flask_theme_support.FlaskyStyle'
    html_theme = 'flask'
    html_theme_options = {
        'touch_icon': 'touch-icon.png'
    }
except ImportError:
    print('-' * 74)
    print('Warning: Flask themes unavailable.  Building with default theme')
    print('If you want the Flask themes, run this command and build again:')
    print()
    print('  git submodule update --init')
    print('-' * 74)
def unwrap_decorators():
    import sphinx.util.inspect as inspect
    import functools
    old_getargspec = inspect.getargspec
    def getargspec(x):
        return old_getargspec(getattr(x, '_original_function', x))
    inspect.getargspec = getargspec
    old_update_wrapper = functools.update_wrapper
    def update_wrapper(wrapper, wrapped, *a, **kw):
        rv = old_update_wrapper(wrapper, wrapped, *a, **kw)
        rv._original_function = wrapped
        return rv
    functools.update_wrapper = update_wrapper
unwrap_decorators()
del unwrap_decorators
import re
import inspect
_internal_mark_re = re.compile(r'^\s*:internal:\s*$(?m)')
def skip_member(app, what, name, obj, skip, options):
    docstring = inspect.getdoc(obj)
    if skip:
        return True
    return _internal_mark_re.search(docstring or '') is not None
def setup(app):
    app.connect('autodoc-skip-member', skip_member)
from pygments.style import Style
from pygments.token import Keyword, Name, Comment, String, Error, \
     Number, Operator, Generic, Whitespace, Punctuation, Other, Literal
class FlaskyStyle(Style):
    background_color = "#f8f8f8"
    default_style = ""
    styles = {
        Whitespace:                "underline #f8f8f8",      # class: 'w'
        Error:                     "#a40000 border:#ef2929", # class: 'err'
        Other:                     "#000000",                # class 'x'
        Comment:                   "italic #8f5902", # class: 'c'
        Comment.Preproc:           "noitalic",       # class: 'cp'
        Keyword:                   "bold #004461",   # class: 'k'
        Keyword.Constant:          "bold #004461",   # class: 'kc'
        Keyword.Declaration:       "bold #004461",   # class: 'kd'
        Keyword.Namespace:         "bold #004461",   # class: 'kn'
        Keyword.Pseudo:            "bold #004461",   # class: 'kp'
        Keyword.Reserved:          "bold #004461",   # class: 'kr'
        Keyword.Type:              "bold #004461",   # class: 'kt'
        Operator:                  "#582800",   # class: 'o'
        Operator.Word:             "bold #004461",   # class: 'ow' - like keywords
        Punctuation:               "bold #000000",   # class: 'p'
        Name:                      "#000000",        # class: 'n'
        Name.Attribute:            "#c4a000",        # class: 'na' - to be revised
        Name.Builtin:              "#004461",        # class: 'nb'
        Name.Builtin.Pseudo:       "#3465a4",        # class: 'bp'
        Name.Class:                "#000000",        # class: 'nc' - to be revised
        Name.Constant:             "#000000",        # class: 'no' - to be revised
        Name.Decorator:            "#888",           # class: 'nd' - to be revised
        Name.Entity:               "#ce5c00",        # class: 'ni'
        Name.Exception:            "bold #cc0000",   # class: 'ne'
        Name.Function:             "#000000",        # class: 'nf'
        Name.Property:             "#000000",        # class: 'py'
        Name.Label:                "#f57900",        # class: 'nl'
        Name.Namespace:            "#000000",        # class: 'nn' - to be revised
        Name.Other:                "#000000",        # class: 'nx'
        Name.Tag:                  "bold #004461",   # class: 'nt' - like a keyword
        Name.Variable:             "#000000",        # class: 'nv' - to be revised
        Name.Variable.Class:       "#000000",        # class: 'vc' - to be revised
        Name.Variable.Global:      "#000000",        # class: 'vg' - to be revised
        Name.Variable.Instance:    "#000000",        # class: 'vi' - to be revised
        Number:                    "#990000",        # class: 'm'
        Literal:                   "#000000",        # class: 'l'
        Literal.Date:              "#000000",        # class: 'ld'
        String:                    "#4e9a06",        # class: 's'
        String.Backtick:           "#4e9a06",        # class: 'sb'
        String.Char:               "#4e9a06",        # class: 'sc'
        String.Doc:                "italic #8f5902", # class: 'sd' - like a comment
        String.Double:             "#4e9a06",        # class: 's2'
        String.Escape:             "#4e9a06",        # class: 'se'
        String.Heredoc:            "#4e9a06",        # class: 'sh'
        String.Interpol:           "#4e9a06",        # class: 'si'
        String.Other:              "#4e9a06",        # class: 'sx'
        String.Regex:              "#4e9a06",        # class: 'sr'
        String.Single:             "#4e9a06",        # class: 's1'
        String.Symbol:             "#4e9a06",        # class: 'ss'
        Generic:                   "#000000",        # class: 'g'
        Generic.Deleted:           "#a40000",        # class: 'gd'
        Generic.Emph:              "italic #000000", # class: 'ge'
        Generic.Error:             "#ef2929",        # class: 'gr'
        Generic.Heading:           "bold #000080",   # class: 'gh'
        Generic.Inserted:          "#00A000",        # class: 'gi'
        Generic.Output:            "#888",           # class: 'go'
        Generic.Prompt:            "#745334",        # class: 'gp'
        Generic.Strong:            "bold #000000",   # class: 'gs'
        Generic.Subheading:        "bold #800080",   # class: 'gu'
        Generic.Traceback:         "bold #a40000",   # class: 'gt'
    }
from flask import Flask
from simple_page.simple_page import simple_page
app = Flask(__name__)
app.register_blueprint(simple_page)
app.register_blueprint(simple_page, url_prefix='/pages')
if __name__=='__main__':
  app.run()
import pytest
import blueprintexample
@pytest.fixture
def client():
    return blueprintexample.app.test_client()
def test_urls(client):
    r = client.get('/')
    assert r.status_code == 200
    r = client.get('/hello')
    assert r.status_code == 200
    r = client.get('/world')
    assert r.status_code == 200
    r = client.get('/pages/hello')
    assert r.status_code == 200
    r = client.get('/pages/world')
    assert r.status_code == 200
from flask import Blueprint, render_template, abort
from jinja2 import TemplateNotFound
simple_page = Blueprint('simple_page', __name__,
                        template_folder='templates')
@simple_page.route('/', defaults={'page': 'index'})
@simple_page.route('/<page>')
def show(page):
    try:
        return render_template('pages/%s.html' % page)
    except TemplateNotFound:
        abort(404)
from setuptools import setup
setup(
    name='flaskr',
    packages=['flaskr'],
    include_package_data=True,
    install_requires=[
        'flask',
    ],
    setup_requires=[
        'pytest-runner',
    ],
    tests_require=[
        'pytest',
    ],
)
import os
from sqlite3 import dbapi2 as sqlite3
from flask import Flask, request, session, g, redirect, url_for, abort, \
     render_template, flash
app = Flask(__name__)
app.config.update(dict(
    DATABASE=os.path.join(app.root_path, 'flaskr.db'),
    DEBUG=True,
    SECRET_KEY='development key',
    USERNAME='admin',
    PASSWORD='default'
))
app.config.from_envvar('FLASKR_SETTINGS', silent=True)
def connect_db():
    
    rv = sqlite3.connect(app.config['DATABASE'])
    rv.row_factory = sqlite3.Row
    return rv
def init_db():
    
    db = get_db()
    with app.open_resource('schema.sql', mode='r') as f:
        db.cursor().executescript(f.read())
    db.commit()
@app.cli.command('initdb')
def initdb_command():
    
    init_db()
    print('Initialized the database.')
def get_db():
    
    if not hasattr(g, 'sqlite_db'):
        g.sqlite_db = connect_db()
    return g.sqlite_db
@app.teardown_appcontext
def close_db(error):
    
    if hasattr(g, 'sqlite_db'):
        g.sqlite_db.close()
@app.route('/')
def show_entries():
    db = get_db()
    cur = db.execute('select title, text from entries order by id desc')
    entries = cur.fetchall()
    return render_template('show_entries.html', entries=entries)
@app.route('/add', methods=['POST'])
def add_entry():
    if not session.get('logged_in'):
        abort(401)
    db = get_db()
    db.execute('insert into entries (title, text) values (?, ?)',
               [request.form['title'], request.form['text']])
    db.commit()
    flash('New entry was successfully posted')
    return redirect(url_for('show_entries'))
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != app.config['USERNAME']:
            error = 'Invalid username'
        elif request.form['password'] != app.config['PASSWORD']:
            error = 'Invalid password'
        else:
            session['logged_in'] = True
            flash('You were logged in')
            return redirect(url_for('show_entries'))
    return render_template('login.html', error=error)
@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash('You were logged out')
    return redirect(url_for('show_entries'))
import sys, os
basedir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, basedir + '/../')
from flaskr import flaskr
import pytest
import os
import tempfile
from context import flaskr
@pytest.fixture
def client(request):
    db_fd, flaskr.app.config['DATABASE'] = tempfile.mkstemp()
    flaskr.app.config['TESTING'] = True
    client = flaskr.app.test_client()
    with flaskr.app.app_context():
        flaskr.init_db()
    def teardown():
        os.close(db_fd)
        os.unlink(flaskr.app.config['DATABASE'])
    request.addfinalizer(teardown)
    return client
def login(client, username, password):
    return client.post('/login', data=dict(
        username=username,
        password=password
    ), follow_redirects=True)
def logout(client):
    return client.get('/logout', follow_redirects=True)
def test_empty_db(client):
    
    rv = client.get('/')
    assert b'No entries here so far' in rv.data
def test_login_logout(client):
    
    rv = login(client, flaskr.app.config['USERNAME'],
               flaskr.app.config['PASSWORD'])
    assert b'You were logged in' in rv.data
    rv = logout(client)
    assert b'You were logged out' in rv.data
    rv = login(client, flaskr.app.config['USERNAME'] + 'x',
               flaskr.app.config['PASSWORD'])
    assert b'Invalid username' in rv.data
    rv = login(client, flaskr.app.config['USERNAME'],
               flaskr.app.config['PASSWORD'] + 'x')
    assert b'Invalid password' in rv.data
def test_messages(client):
    
    login(client, flaskr.app.config['USERNAME'],
          flaskr.app.config['PASSWORD'])
    rv = client.post('/add', data=dict(
        title='<Hello>',
        text='<strong>HTML</strong> allowed here'
    ), follow_redirects=True)
    assert b'No entries here so far' not in rv.data
    assert b'&lt;Hello&gt;' in rv.data
    assert b'<strong>HTML</strong> allowed here' in rv.data
from flask import Flask, jsonify, render_template, request
app = Flask(__name__)
@app.route('/_add_numbers')
def add_numbers():
    
    a = request.args.get('a', 0, type=int)
    b = request.args.get('b', 0, type=int)
    return jsonify(result=a + b)
@app.route('/')
def index():
    return render_template('index.html')
if __name__ == '__main__':
    app.run()
import time
from sqlite3 import dbapi2 as sqlite3
from hashlib import md5
from datetime import datetime
from flask import Flask, request, session, url_for, redirect, \
     render_template, abort, g, flash, _app_ctx_stack
from werkzeug import check_password_hash, generate_password_hash
DATABASE = '/tmp/minitwit.db'
PER_PAGE = 30
DEBUG = True
SECRET_KEY = 'development key'
app = Flask(__name__)
app.config.from_object(__name__)
app.config.from_envvar('MINITWIT_SETTINGS', silent=True)
def get_db():
    
    top = _app_ctx_stack.top
    if not hasattr(top, 'sqlite_db'):
        top.sqlite_db = sqlite3.connect(app.config['DATABASE'])
        top.sqlite_db.row_factory = sqlite3.Row
    return top.sqlite_db
@app.teardown_appcontext
def close_database(exception):
    
    top = _app_ctx_stack.top
    if hasattr(top, 'sqlite_db'):
        top.sqlite_db.close()
def init_db():
    
    db = get_db()
    with app.open_resource('schema.sql', mode='r') as f:
        db.cursor().executescript(f.read())
    db.commit()
@app.cli.command('initdb')
def initdb_command():
    
    init_db()
    print('Initialized the database.')
def query_db(query, args=(), one=False):
    
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    return (rv[0] if rv else None) if one else rv
def get_user_id(username):
    
    rv = query_db('select user_id from user where username = ?',
                  [username], one=True)
    return rv[0] if rv else None
def format_datetime(timestamp):
    
    return datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%d @ %H:%M')
def gravatar_url(email, size=80):
    
    return 'http://www.gravatar.com/avatar/%s?d=identicon&s=%d' % \
        (md5(email.strip().lower().encode('utf-8')).hexdigest(), size)
@app.before_request
def before_request():
    g.user = None
    if 'user_id' in session:
        g.user = query_db('select * from user where user_id = ?',
                          [session['user_id']], one=True)
@app.route('/')
def timeline():
    
    if not g.user:
        return redirect(url_for('public_timeline'))
    return render_template('timeline.html', messages=query_db('''
        select message.*, user.* from message, user
        where message.author_id = user.user_id and (
            user.user_id = ? or
            user.user_id in (select whom_id from follower
                                    where who_id = ?))
        order by message.pub_date desc limit ?''',
        [session['user_id'], session['user_id'], PER_PAGE]))
@app.route('/public')
def public_timeline():
    
    return render_template('timeline.html', messages=query_db('''
        select message.*, user.* from message, user
        where message.author_id = user.user_id
        order by message.pub_date desc limit ?''', [PER_PAGE]))
@app.route('/<username>')
def user_timeline(username):
    
    profile_user = query_db('select * from user where username = ?',
                            [username], one=True)
    if profile_user is None:
        abort(404)
    followed = False
    if g.user:
        followed = query_db('''select 1 from follower where
            follower.who_id = ? and follower.whom_id = ?''',
            [session['user_id'], profile_user['user_id']],
            one=True) is not None
    return render_template('timeline.html', messages=query_db('''
            select message.*, user.* from message, user where
            user.user_id = message.author_id and user.user_id = ?
            order by message.pub_date desc limit ?''',
            [profile_user['user_id'], PER_PAGE]), followed=followed,
            profile_user=profile_user)
@app.route('/<username>/follow')
def follow_user(username):
    
    if not g.user:
        abort(401)
    whom_id = get_user_id(username)
    if whom_id is None:
        abort(404)
    db = get_db()
    db.execute('insert into follower (who_id, whom_id) values (?, ?)',
              [session['user_id'], whom_id])
    db.commit()
    flash('You are now following "%s"' % username)
    return redirect(url_for('user_timeline', username=username))
@app.route('/<username>/unfollow')
def unfollow_user(username):
    
    if not g.user:
        abort(401)
    whom_id = get_user_id(username)
    if whom_id is None:
        abort(404)
    db = get_db()
    db.execute('delete from follower where who_id=? and whom_id=?',
              [session['user_id'], whom_id])
    db.commit()
    flash('You are no longer following "%s"' % username)
    return redirect(url_for('user_timeline', username=username))
@app.route('/add_message', methods=['POST'])
def add_message():
    
    if 'user_id' not in session:
        abort(401)
    if request.form['text']:
        db = get_db()
        db.execute('''insert into message (author_id, text, pub_date)
          values (?, ?, ?)''', (session['user_id'], request.form['text'],
                                int(time.time())))
        db.commit()
        flash('Your message was recorded')
    return redirect(url_for('timeline'))
@app.route('/login', methods=['GET', 'POST'])
def login():
    
    if g.user:
        return redirect(url_for('timeline'))
    error = None
    if request.method == 'POST':
        user = query_db('''select * from user where
            username = ?''', [request.form['username']], one=True)
        if user is None:
            error = 'Invalid username'
        elif not check_password_hash(user['pw_hash'],
                                     request.form['password']):
            error = 'Invalid password'
        else:
            flash('You were logged in')
            session['user_id'] = user['user_id']
            return redirect(url_for('timeline'))
    return render_template('login.html', error=error)
@app.route('/register', methods=['GET', 'POST'])
def register():
    
    if g.user:
        return redirect(url_for('timeline'))
    error = None
    if request.method == 'POST':
        if not request.form['username']:
            error = 'You have to enter a username'
        elif not request.form['email'] or \
                '@' not in request.form['email']:
            error = 'You have to enter a valid email address'
        elif not request.form['password']:
            error = 'You have to enter a password'
        elif request.form['password'] != request.form['password2']:
            error = 'The two passwords do not match'
        elif get_user_id(request.form['username']) is not None:
            error = 'The username is already taken'
        else:
            db = get_db()
            db.execute('''insert into user (
              username, email, pw_hash) values (?, ?, ?)''',
              [request.form['username'], request.form['email'],
               generate_password_hash(request.form['password'])])
            db.commit()
            flash('You were successfully registered and can login now')
            return redirect(url_for('login'))
    return render_template('register.html', error=error)
@app.route('/logout')
def logout():
    
    flash('You were logged out')
    session.pop('user_id', None)
    return redirect(url_for('public_timeline'))
app.jinja_env.filters['datetimeformat'] = format_datetime
app.jinja_env.filters['gravatar'] = gravatar_url
import os
import minitwit
import tempfile
import pytest
@pytest.fixture
def client(request):
    db_fd, minitwit.app.config['DATABASE'] = tempfile.mkstemp()
    client = minitwit.app.test_client()
    with minitwit.app.app_context():
        minitwit.init_db()
    def teardown():
        
        os.close(db_fd)
        os.unlink(minitwit.app.config['DATABASE'])
    request.addfinalizer(teardown)
    return client
def register(client, username, password, password2=None, email=None):
    
    if password2 is None:
        password2 = password
    if email is None:
        email = username + '@example.com'
    return client.post('/register', data={
        'username':     username,
        'password':     password,
        'password2':    password2,
        'email':        email,
    }, follow_redirects=True)
def login(client, username, password):
    
    return client.post('/login', data={
        'username': username,
        'password': password
    }, follow_redirects=True)
def register_and_login(client, username, password):
    
    register(client, username, password)
    return login(client, username, password)
def logout(client):
    
    return client.get('/logout', follow_redirects=True)
def add_message(client, text):
    
    rv = client.post('/add_message', data={'text': text},
                     follow_redirects=True)
    if text:
        assert b'Your message was recorded' in rv.data
    return rv
def test_register(client):
    
    rv = register(client, 'user1', 'default')
    assert b'You were successfully registered ' \
           b'and can login now' in rv.data
    rv = register(client, 'user1', 'default')
    assert b'The username is already taken' in rv.data
    rv = register(client, '', 'default')
    assert b'You have to enter a username' in rv.data
    rv = register(client, 'meh', '')
    assert b'You have to enter a password' in rv.data
    rv = register(client, 'meh', 'x', 'y')
    assert b'The two passwords do not match' in rv.data
    rv = register(client, 'meh', 'foo', email='broken')
    assert b'You have to enter a valid email address' in rv.data
def test_login_logout(client):
    
    rv = register_and_login(client, 'user1', 'default')
    assert b'You were logged in' in rv.data
    rv = logout(client)
    assert b'You were logged out' in rv.data
    rv = login(client, 'user1', 'wrongpassword')
    assert b'Invalid password' in rv.data
    rv = login(client, 'user2', 'wrongpassword')
    assert b'Invalid username' in rv.data
def test_message_recording(client):
    
    register_and_login(client, 'foo', 'default')
    add_message(client, 'test message 1')
    add_message(client, '<test message 2>')
    rv = client.get('/')
    assert b'test message 1' in rv.data
    assert b'&lt;test message 2&gt;' in rv.data
def test_timelines(client):
    
    register_and_login(client, 'foo', 'default')
    add_message(client, 'the message by foo')
    logout(client)
    register_and_login(client, 'bar', 'default')
    add_message(client, 'the message by bar')
    rv = client.get('/public')
    assert b'the message by foo' in rv.data
    assert b'the message by bar' in rv.data
    rv = client.get('/')
    assert b'the message by foo' not in rv.data
    assert b'the message by bar' in rv.data
    rv = client.get('/foo/follow', follow_redirects=True)
    assert b'You are now following &#34;foo&#34;' in rv.data
    rv = client.get('/')
    assert b'the message by foo' in rv.data
    assert b'the message by bar' in rv.data
    rv = client.get('/bar')
    assert b'the message by foo' not in rv.data
    assert b'the message by bar' in rv.data
    rv = client.get('/foo')
    assert b'the message by foo' in rv.data
    assert b'the message by bar' not in rv.data
    rv = client.get('/foo/unfollow', follow_redirects=True)
    assert b'You are no longer following &#34;foo&#34;' in rv.data
    rv = client.get('/')
    assert b'the message by foo' not in rv.data
    assert b'the message by bar' in rv.data
__version__ = '0.11.2-dev'
from werkzeug.exceptions import abort
from werkzeug.utils import redirect
from jinja2 import Markup, escape
from .app import Flask, Request, Response
from .config import Config
from .helpers import url_for, flash, send_file, send_from_directory, \
     get_flashed_messages, get_template_attribute, make_response, safe_join, \
     stream_with_context
from .globals import current_app, g, request, session, _request_ctx_stack, \
     _app_ctx_stack
from .ctx import has_request_context, has_app_context, \
     after_this_request, copy_current_request_context
from .blueprints import Blueprint
from .templating import render_template, render_template_string
from .signals import signals_available, template_rendered, request_started, \
     request_finished, got_request_exception, request_tearing_down, \
     appcontext_tearing_down, appcontext_pushed, \
     appcontext_popped, message_flashed, before_render_template
from . import json
jsonify = json.jsonify
from .sessions import SecureCookieSession as Session
json_available = True
if __name__ == '__main__':
    from .cli import main
    main(as_module=True)
import sys
PY2 = sys.version_info[0] == 2
_identity = lambda x: x
if not PY2:
    text_type = str
    string_types = (str,)
    integer_types = (int,)
    iterkeys = lambda d: iter(d.keys())
    itervalues = lambda d: iter(d.values())
    iteritems = lambda d: iter(d.items())
    from io import StringIO
    def reraise(tp, value, tb=None):
        if value.__traceback__ is not tb:
            raise value.with_traceback(tb)
        raise value
    implements_to_string = _identity
else:
    text_type = unicode
    string_types = (str, unicode)
    integer_types = (int, long)
    iterkeys = lambda d: d.iterkeys()
    itervalues = lambda d: d.itervalues()
    iteritems = lambda d: d.iteritems()
    from cStringIO import StringIO
    exec('def reraise(tp, value, tb=None):\n raise tp, value, tb')
    def implements_to_string(cls):
        cls.__unicode__ = cls.__str__
        cls.__str__ = lambda x: x.__unicode__().encode('utf-8')
        return cls
def with_metaclass(meta, *bases):
    
    class metaclass(type):
        def __new__(cls, name, this_bases, d):
            return meta(name, bases, d)
    return type.__new__(metaclass, 'temporary_class', (), {})
BROKEN_PYPY_CTXMGR_EXIT = False
if hasattr(sys, 'pypy_version_info'):
    class _Mgr(object):
        def __enter__(self):
            return self
        def __exit__(self, *args):
            if hasattr(sys, 'exc_clear'):
                sys.exc_clear()
    try:
        try:
            with _Mgr():
                raise AssertionError()
        except:
            raise
    except TypeError:
        BROKEN_PYPY_CTXMGR_EXIT = True
    except AssertionError:
        pass
import os
import sys
from threading import Lock
from datetime import timedelta
from itertools import chain
from functools import update_wrapper
from collections import deque
from werkzeug.datastructures import ImmutableDict
from werkzeug.routing import Map, Rule, RequestRedirect, BuildError
from werkzeug.exceptions import HTTPException, InternalServerError, \
     MethodNotAllowed, BadRequest, default_exceptions
from .helpers import _PackageBoundObject, url_for, get_flashed_messages, \
     locked_cached_property, _endpoint_from_view_func, find_package, \
     get_debug_flag
from . import json, cli
from .wrappers import Request, Response
from .config import ConfigAttribute, Config
from .ctx import RequestContext, AppContext, _AppCtxGlobals
from .globals import _request_ctx_stack, request, session, g
from .sessions import SecureCookieSessionInterface
from .templating import DispatchingJinjaLoader, Environment, \
     _default_template_ctx_processor
from .signals import request_started, request_finished, got_request_exception, \
     request_tearing_down, appcontext_tearing_down
from ._compat import reraise, string_types, text_type, integer_types
_logger_lock = Lock()
_sentinel = object()
def _make_timedelta(value):
    if not isinstance(value, timedelta):
        return timedelta(seconds=value)
    return value
def setupmethod(f):
    
    def wrapper_func(self, *args, **kwargs):
        if self.debug and self._got_first_request:
            raise AssertionError('A setup function was called after the '
                'first request was handled.  This usually indicates a bug '
                'in the application where a module was not imported '
                'and decorators or other functionality was called too late.\n'
                'To fix this make sure to import all your view modules, '
                'database models and everything related at a central place '
                'before the application starts serving requests.')
        return f(self, *args, **kwargs)
    return update_wrapper(wrapper_func, f)
class Flask(_PackageBoundObject):
    
    request_class = Request
    response_class = Response
    jinja_environment = Environment
    app_ctx_globals_class = _AppCtxGlobals
    def _get_request_globals_class(self):
        return self.app_ctx_globals_class
    def _set_request_globals_class(self, value):
        from warnings import warn
        warn(DeprecationWarning('request_globals_class attribute is now '
                                'called app_ctx_globals_class'))
        self.app_ctx_globals_class = value
    request_globals_class = property(_get_request_globals_class,
                                     _set_request_globals_class)
    del _get_request_globals_class, _set_request_globals_class
    config_class = Config
    debug = ConfigAttribute('DEBUG')
    testing = ConfigAttribute('TESTING')
    secret_key = ConfigAttribute('SECRET_KEY')
    session_cookie_name = ConfigAttribute('SESSION_COOKIE_NAME')
    permanent_session_lifetime = ConfigAttribute('PERMANENT_SESSION_LIFETIME',
        get_converter=_make_timedelta)
    send_file_max_age_default = ConfigAttribute('SEND_FILE_MAX_AGE_DEFAULT',
        get_converter=_make_timedelta)
    use_x_sendfile = ConfigAttribute('USE_X_SENDFILE')
    logger_name = ConfigAttribute('LOGGER_NAME')
    json_encoder = json.JSONEncoder
    json_decoder = json.JSONDecoder
    jinja_options = ImmutableDict(
        extensions=['jinja2.ext.autoescape', 'jinja2.ext.with_']
    )
    default_config = ImmutableDict({
        'DEBUG':                                get_debug_flag(default=False),
        'TESTING':                              False,
        'PROPAGATE_EXCEPTIONS':                 None,
        'PRESERVE_CONTEXT_ON_EXCEPTION':        None,
        'SECRET_KEY':                           None,
        'PERMANENT_SESSION_LIFETIME':           timedelta(days=31),
        'USE_X_SENDFILE':                       False,
        'LOGGER_NAME':                          None,
        'LOGGER_HANDLER_POLICY':               'always',
        'SERVER_NAME':                          None,
        'APPLICATION_ROOT':                     None,
        'SESSION_COOKIE_NAME':                  'session',
        'SESSION_COOKIE_DOMAIN':                None,
        'SESSION_COOKIE_PATH':                  None,
        'SESSION_COOKIE_HTTPONLY':              True,
        'SESSION_COOKIE_SECURE':                False,
        'SESSION_REFRESH_EACH_REQUEST':         True,
        'MAX_CONTENT_LENGTH':                   None,
        'SEND_FILE_MAX_AGE_DEFAULT':            timedelta(hours=12),
        'TRAP_BAD_REQUEST_ERRORS':              False,
        'TRAP_HTTP_EXCEPTIONS':                 False,
        'EXPLAIN_TEMPLATE_LOADING':             False,
        'PREFERRED_URL_SCHEME':                 'http',
        'JSON_AS_ASCII':                        True,
        'JSON_SORT_KEYS':                       True,
        'JSONIFY_PRETTYPRINT_REGULAR':          True,
        'JSONIFY_MIMETYPE':                     'application/json',
        'TEMPLATES_AUTO_RELOAD':                None,
    })
    url_rule_class = Rule
    test_client_class = None
    session_interface = SecureCookieSessionInterface()
    def __init__(self, import_name, static_path=None, static_url_path=None,
                 static_folder='static', template_folder='templates',
                 instance_path=None, instance_relative_config=False,
                 root_path=None):
        _PackageBoundObject.__init__(self, import_name,
                                     template_folder=template_folder,
                                     root_path=root_path)
        if static_path is not None:
            from warnings import warn
            warn(DeprecationWarning('static_path is now called '
                                    'static_url_path'), stacklevel=2)
            static_url_path = static_path
        if static_url_path is not None:
            self.static_url_path = static_url_path
        if static_folder is not None:
            self.static_folder = static_folder
        if instance_path is None:
            instance_path = self.auto_find_instance_path()
        elif not os.path.isabs(instance_path):
            raise ValueError('If an instance path is provided it must be '
                             'absolute.  A relative path was given instead.')
        self.instance_path = instance_path
        self.config = self.make_config(instance_relative_config)
        self._logger = None
        self.logger_name = self.import_name
        self.view_functions = {}
        self._error_handlers = {}
        self.error_handler_spec = {None: self._error_handlers}
        self.url_build_error_handlers = []
        self.before_request_funcs = {}
        self.before_first_request_funcs = []
        self.after_request_funcs = {}
        self.teardown_request_funcs = {}
        self.teardown_appcontext_funcs = []
        self.url_value_preprocessors = {}
        self.url_default_functions = {}
        self.template_context_processors = {
            None: [_default_template_ctx_processor]
        }
        self.shell_context_processors = []
        self.blueprints = {}
        self._blueprint_order = []
        self.extensions = {}
        self.url_map = Map()
        self._got_first_request = False
        self._before_request_lock = Lock()
        if self.has_static_folder:
            self.add_url_rule(self.static_url_path + '/<path:filename>',
                              endpoint='static',
                              view_func=self.send_static_file)
        self.cli = cli.AppGroup(self.name)
    def _get_error_handlers(self):
        from warnings import warn
        warn(DeprecationWarning('error_handlers is deprecated, use the '
            'new error_handler_spec attribute instead.'), stacklevel=1)
        return self._error_handlers
    def _set_error_handlers(self, value):
        self._error_handlers = value
        self.error_handler_spec[None] = value
    error_handlers = property(_get_error_handlers, _set_error_handlers)
    del _get_error_handlers, _set_error_handlers
    @locked_cached_property
    def name(self):
        
        if self.import_name == '__main__':
            fn = getattr(sys.modules['__main__'], '__file__', None)
            if fn is None:
                return '__main__'
            return os.path.splitext(os.path.basename(fn))[0]
        return self.import_name
    @property
    def propagate_exceptions(self):
        
        rv = self.config['PROPAGATE_EXCEPTIONS']
        if rv is not None:
            return rv
        return self.testing or self.debug
    @property
    def preserve_context_on_exception(self):
        
        rv = self.config['PRESERVE_CONTEXT_ON_EXCEPTION']
        if rv is not None:
            return rv
        return self.debug
    @property
    def logger(self):
        
        if self._logger and self._logger.name == self.logger_name:
            return self._logger
        with _logger_lock:
            if self._logger and self._logger.name == self.logger_name:
                return self._logger
            from flask.logging import create_logger
            self._logger = rv = create_logger(self)
            return rv
    @locked_cached_property
    def jinja_env(self):
        
        return self.create_jinja_environment()
    @property
    def got_first_request(self):
        
        return self._got_first_request
    def make_config(self, instance_relative=False):
        
        root_path = self.root_path
        if instance_relative:
            root_path = self.instance_path
        return self.config_class(root_path, self.default_config)
    def auto_find_instance_path(self):
        
        prefix, package_path = find_package(self.import_name)
        if prefix is None:
            return os.path.join(package_path, 'instance')
        return os.path.join(prefix, 'var', self.name + '-instance')
    def open_instance_resource(self, resource, mode='rb'):
        
        return open(os.path.join(self.instance_path, resource), mode)
    def create_jinja_environment(self):
        
        options = dict(self.jinja_options)
        if 'autoescape' not in options:
            options['autoescape'] = self.select_jinja_autoescape
        if 'auto_reload' not in options:
            if self.config['TEMPLATES_AUTO_RELOAD'] is not None:
                options['auto_reload'] = self.config['TEMPLATES_AUTO_RELOAD']
            else:
                options['auto_reload'] = self.debug
        rv = self.jinja_environment(self, **options)
        rv.globals.update(
            url_for=url_for,
            get_flashed_messages=get_flashed_messages,
            config=self.config,
            request=request,
            session=session,
            g=g
        )
        rv.filters['tojson'] = json.tojson_filter
        return rv
    def create_global_jinja_loader(self):
        
        return DispatchingJinjaLoader(self)
    def init_jinja_globals(self):
        
    def select_jinja_autoescape(self, filename):
        
        if filename is None:
            return True
        return filename.endswith(('.html', '.htm', '.xml', '.xhtml'))
    def update_template_context(self, context):
        
        funcs = self.template_context_processors[None]
        reqctx = _request_ctx_stack.top
        if reqctx is not None:
            bp = reqctx.request.blueprint
            if bp is not None and bp in self.template_context_processors:
                funcs = chain(funcs, self.template_context_processors[bp])
        orig_ctx = context.copy()
        for func in funcs:
            context.update(func())
        context.update(orig_ctx)
    def make_shell_context(self):
        
        rv = {'app': self, 'g': g}
        for processor in self.shell_context_processors:
            rv.update(processor())
        return rv
    def run(self, host=None, port=None, debug=None, **options):
        
        from werkzeug.serving import run_simple
        if host is None:
            host = '127.0.0.1'
        if port is None:
            server_name = self.config['SERVER_NAME']
            if server_name and ':' in server_name:
                port = int(server_name.rsplit(':', 1)[1])
            else:
                port = 5000
        if debug is not None:
            self.debug = bool(debug)
        options.setdefault('use_reloader', self.debug)
        options.setdefault('use_debugger', self.debug)
        options.setdefault('passthrough_errors', True)
        try:
            run_simple(host, port, self, **options)
        finally:
            self._got_first_request = False
    def test_client(self, use_cookies=True, **kwargs):
        
        cls = self.test_client_class
        if cls is None:
            from flask.testing import FlaskClient as cls
        return cls(self, self.response_class, use_cookies=use_cookies, **kwargs)
    def open_session(self, request):
        
        return self.session_interface.open_session(self, request)
    def save_session(self, session, response):
        
        return self.session_interface.save_session(self, session, response)
    def make_null_session(self):
        
        return self.session_interface.make_null_session(self)
    @setupmethod
    def register_blueprint(self, blueprint, **options):
        
        first_registration = False
        if blueprint.name in self.blueprints:
            assert self.blueprints[blueprint.name] is blueprint, \
                'A blueprint\'s name collision occurred between %r and ' \
                '%r.  Both share the same name "%s".  Blueprints that ' \
                'are created on the fly need unique names.' % \
                (blueprint, self.blueprints[blueprint.name], blueprint.name)
        else:
            self.blueprints[blueprint.name] = blueprint
            self._blueprint_order.append(blueprint)
            first_registration = True
        blueprint.register(self, options, first_registration)
    def iter_blueprints(self):
        
        return iter(self._blueprint_order)
    @setupmethod
    def add_url_rule(self, rule, endpoint=None, view_func=None, **options):
        
        if endpoint is None:
            endpoint = _endpoint_from_view_func(view_func)
        options['endpoint'] = endpoint
        methods = options.pop('methods', None)
        if methods is None:
            methods = getattr(view_func, 'methods', None) or ('GET',)
        if isinstance(methods, string_types):
            raise TypeError('Allowed methods have to be iterables of strings, '
                            'for example: @app.route(..., methods=["POST"])')
        methods = set(item.upper() for item in methods)
        required_methods = set(getattr(view_func, 'required_methods', ()))
        provide_automatic_options = getattr(view_func,
            'provide_automatic_options', None)
        if provide_automatic_options is None:
            if 'OPTIONS' not in methods:
                provide_automatic_options = True
                required_methods.add('OPTIONS')
            else:
                provide_automatic_options = False
        methods |= required_methods
        rule = self.url_rule_class(rule, methods=methods, **options)
        rule.provide_automatic_options = provide_automatic_options
        self.url_map.add(rule)
        if view_func is not None:
            old_func = self.view_functions.get(endpoint)
            if old_func is not None and old_func != view_func:
                raise AssertionError('View function mapping is overwriting an '
                                     'existing endpoint function: %s' % endpoint)
            self.view_functions[endpoint] = view_func
    def route(self, rule, **options):
        
        def decorator(f):
            endpoint = options.pop('endpoint', None)
            self.add_url_rule(rule, endpoint, f, **options)
            return f
        return decorator
    @setupmethod
    def endpoint(self, endpoint):
        
        def decorator(f):
            self.view_functions[endpoint] = f
            return f
        return decorator
    @staticmethod
    def _get_exc_class_and_code(exc_class_or_code):
        
        if isinstance(exc_class_or_code, integer_types):
            exc_class = default_exceptions[exc_class_or_code]
        else:
            exc_class = exc_class_or_code
        assert issubclass(exc_class, Exception)
        if issubclass(exc_class, HTTPException):
            return exc_class, exc_class.code
        else:
            return exc_class, None
    @setupmethod
    def errorhandler(self, code_or_exception):
        
        def decorator(f):
            self._register_error_handler(None, code_or_exception, f)
            return f
        return decorator
    def register_error_handler(self, code_or_exception, f):
        
        self._register_error_handler(None, code_or_exception, f)
    @setupmethod
    def _register_error_handler(self, key, code_or_exception, f):
        
        if isinstance(code_or_exception, HTTPException):  # old broken behavior
            raise ValueError(
                'Tried to register a handler for an exception instance {0!r}. '
                'Handlers can only be registered for exception classes or HTTP error codes.'
                .format(code_or_exception))
        exc_class, code = self._get_exc_class_and_code(code_or_exception)
        handlers = self.error_handler_spec.setdefault(key, {}).setdefault(code, {})
        handlers[exc_class] = f
    @setupmethod
    def template_filter(self, name=None):
        
        def decorator(f):
            self.add_template_filter(f, name=name)
            return f
        return decorator
    @setupmethod
    def add_template_filter(self, f, name=None):
        
        self.jinja_env.filters[name or f.__name__] = f
    @setupmethod
    def template_test(self, name=None):
        
        def decorator(f):
            self.add_template_test(f, name=name)
            return f
        return decorator
    @setupmethod
    def add_template_test(self, f, name=None):
        
        self.jinja_env.tests[name or f.__name__] = f
    @setupmethod
    def template_global(self, name=None):
        
        def decorator(f):
            self.add_template_global(f, name=name)
            return f
        return decorator
    @setupmethod
    def add_template_global(self, f, name=None):
        
        self.jinja_env.globals[name or f.__name__] = f
    @setupmethod
    def before_request(self, f):
        
        self.before_request_funcs.setdefault(None, []).append(f)
        return f
    @setupmethod
    def before_first_request(self, f):
        
        self.before_first_request_funcs.append(f)
        return f
    @setupmethod
    def after_request(self, f):
        
        self.after_request_funcs.setdefault(None, []).append(f)
        return f
    @setupmethod
    def teardown_request(self, f):
        
        self.teardown_request_funcs.setdefault(None, []).append(f)
        return f
    @setupmethod
    def teardown_appcontext(self, f):
        
        self.teardown_appcontext_funcs.append(f)
        return f
    @setupmethod
    def context_processor(self, f):
        
        self.template_context_processors[None].append(f)
        return f
    @setupmethod
    def shell_context_processor(self, f):
        
        self.shell_context_processors.append(f)
        return f
    @setupmethod
    def url_value_preprocessor(self, f):
        
        self.url_value_preprocessors.setdefault(None, []).append(f)
        return f
    @setupmethod
    def url_defaults(self, f):
        
        self.url_default_functions.setdefault(None, []).append(f)
        return f
    def _find_error_handler(self, e):
        
        exc_class, code = self._get_exc_class_and_code(type(e))
        def find_handler(handler_map):
            if not handler_map:
                return
            queue = deque(exc_class.__mro__)
            done = set()
            while queue:
                cls = queue.popleft()
                if cls in done:
                    continue
                done.add(cls)
                handler = handler_map.get(cls)
                if handler is not None:
                    handler_map[exc_class] = handler
                    return handler
                queue.extend(cls.__mro__)
        handler = find_handler(self.error_handler_spec
                               .get(request.blueprint, {})
                               .get(code))
        if handler is not None:
            return handler
        return find_handler(self.error_handler_spec[None].get(code))
    def handle_http_exception(self, e):
        
        if e.code is None:
            return e
        handler = self._find_error_handler(e)
        if handler is None:
            return e
        return handler(e)
    def trap_http_exception(self, e):
        
        if self.config['TRAP_HTTP_EXCEPTIONS']:
            return True
        if self.config['TRAP_BAD_REQUEST_ERRORS']:
            return isinstance(e, BadRequest)
        return False
    def handle_user_exception(self, e):
        
        exc_type, exc_value, tb = sys.exc_info()
        assert exc_value is e
        if isinstance(e, HTTPException) and not self.trap_http_exception(e):
            return self.handle_http_exception(e)
        handler = self._find_error_handler(e)
        if handler is None:
            reraise(exc_type, exc_value, tb)
        return handler(e)
    def handle_exception(self, e):
        
        exc_type, exc_value, tb = sys.exc_info()
        got_request_exception.send(self, exception=e)
        handler = self._find_error_handler(InternalServerError())
        if self.propagate_exceptions:
            if exc_value is e:
                reraise(exc_type, exc_value, tb)
            else:
                raise e
        self.log_exception((exc_type, exc_value, tb))
        if handler is None:
            return InternalServerError()
        return handler(e)
    def log_exception(self, exc_info):
        
        self.logger.error('Exception on %s [%s]' % (
            request.path,
            request.method
        ), exc_info=exc_info)
    def raise_routing_exception(self, request):
        
        if not self.debug \
           or not isinstance(request.routing_exception, RequestRedirect) \
           or request.method in ('GET', 'HEAD', 'OPTIONS'):
            raise request.routing_exception
        from .debughelpers import FormDataRoutingRedirect
        raise FormDataRoutingRedirect(request)
    def dispatch_request(self):
        
        req = _request_ctx_stack.top.request
        if req.routing_exception is not None:
            self.raise_routing_exception(req)
        rule = req.url_rule
        if getattr(rule, 'provide_automatic_options', False) \
           and req.method == 'OPTIONS':
            return self.make_default_options_response()
        return self.view_functions[rule.endpoint](**req.view_args)
    def full_dispatch_request(self):
        
        self.try_trigger_before_first_request_functions()
        try:
            request_started.send(self)
            rv = self.preprocess_request()
            if rv is None:
                rv = self.dispatch_request()
        except Exception as e:
            rv = self.handle_user_exception(e)
        response = self.make_response(rv)
        response = self.process_response(response)
        request_finished.send(self, response=response)
        return response
    def try_trigger_before_first_request_functions(self):
        
        if self._got_first_request:
            return
        with self._before_request_lock:
            if self._got_first_request:
                return
            for func in self.before_first_request_funcs:
                func()
            self._got_first_request = True
    def make_default_options_response(self):
        
        adapter = _request_ctx_stack.top.url_adapter
        if hasattr(adapter, 'allowed_methods'):
            methods = adapter.allowed_methods()
        else:
            methods = []
            try:
                adapter.match(method='--')
            except MethodNotAllowed as e:
                methods = e.valid_methods
            except HTTPException as e:
                pass
        rv = self.response_class()
        rv.allow.update(methods)
        return rv
    def should_ignore_error(self, error):
        
        return False
    def make_response(self, rv):
        
        status_or_headers = headers = None
        if isinstance(rv, tuple):
            rv, status_or_headers, headers = rv + (None,) * (3 - len(rv))
        if rv is None:
            raise ValueError('View function did not return a response')
        if isinstance(status_or_headers, (dict, list)):
            headers, status_or_headers = status_or_headers, None
        if not isinstance(rv, self.response_class):
            if isinstance(rv, (text_type, bytes, bytearray)):
                rv = self.response_class(rv, headers=headers,
                                         status=status_or_headers)
                headers = status_or_headers = None
            else:
                rv = self.response_class.force_type(rv, request.environ)
        if status_or_headers is not None:
            if isinstance(status_or_headers, string_types):
                rv.status = status_or_headers
            else:
                rv.status_code = status_or_headers
        if headers:
            rv.headers.extend(headers)
        return rv
    def create_url_adapter(self, request):
        
        if request is not None:
            return self.url_map.bind_to_environ(request.environ,
                server_name=self.config['SERVER_NAME'])
        if self.config['SERVER_NAME'] is not None:
            return self.url_map.bind(
                self.config['SERVER_NAME'],
                script_name=self.config['APPLICATION_ROOT'] or '/',
                url_scheme=self.config['PREFERRED_URL_SCHEME'])
    def inject_url_defaults(self, endpoint, values):
        
        funcs = self.url_default_functions.get(None, ())
        if '.' in endpoint:
            bp = endpoint.rsplit('.', 1)[0]
            funcs = chain(funcs, self.url_default_functions.get(bp, ()))
        for func in funcs:
            func(endpoint, values)
    def handle_url_build_error(self, error, endpoint, values):
        
        exc_type, exc_value, tb = sys.exc_info()
        for handler in self.url_build_error_handlers:
            try:
                rv = handler(error, endpoint, values)
                if rv is not None:
                    return rv
            except BuildError as e:
                error = e
        if error is exc_value:
            reraise(exc_type, exc_value, tb)
        raise error
    def preprocess_request(self):
        
        bp = _request_ctx_stack.top.request.blueprint
        funcs = self.url_value_preprocessors.get(None, ())
        if bp is not None and bp in self.url_value_preprocessors:
            funcs = chain(funcs, self.url_value_preprocessors[bp])
        for func in funcs:
            func(request.endpoint, request.view_args)
        funcs = self.before_request_funcs.get(None, ())
        if bp is not None and bp in self.before_request_funcs:
            funcs = chain(funcs, self.before_request_funcs[bp])
        for func in funcs:
            rv = func()
            if rv is not None:
                return rv
    def process_response(self, response):
        
        ctx = _request_ctx_stack.top
        bp = ctx.request.blueprint
        funcs = ctx._after_request_functions
        if bp is not None and bp in self.after_request_funcs:
            funcs = chain(funcs, reversed(self.after_request_funcs[bp]))
        if None in self.after_request_funcs:
            funcs = chain(funcs, reversed(self.after_request_funcs[None]))
        for handler in funcs:
            response = handler(response)
        if not self.session_interface.is_null_session(ctx.session):
            self.save_session(ctx.session, response)
        return response
    def do_teardown_request(self, exc=_sentinel):
        
        if exc is _sentinel:
            exc = sys.exc_info()[1]
        funcs = reversed(self.teardown_request_funcs.get(None, ()))
        bp = _request_ctx_stack.top.request.blueprint
        if bp is not None and bp in self.teardown_request_funcs:
            funcs = chain(funcs, reversed(self.teardown_request_funcs[bp]))
        for func in funcs:
            func(exc)
        request_tearing_down.send(self, exc=exc)
    def do_teardown_appcontext(self, exc=_sentinel):
        
        if exc is _sentinel:
            exc = sys.exc_info()[1]
        for func in reversed(self.teardown_appcontext_funcs):
            func(exc)
        appcontext_tearing_down.send(self, exc=exc)
    def app_context(self):
        
        return AppContext(self)
    def request_context(self, environ):
        
        return RequestContext(self, environ)
    def test_request_context(self, *args, **kwargs):
        
        from flask.testing import make_test_environ_builder
        builder = make_test_environ_builder(self, *args, **kwargs)
        try:
            return self.request_context(builder.get_environ())
        finally:
            builder.close()
    def wsgi_app(self, environ, start_response):
        
        ctx = self.request_context(environ)
        ctx.push()
        error = None
        try:
            try:
                response = self.full_dispatch_request()
            except Exception as e:
                error = e
                response = self.make_response(self.handle_exception(e))
            return response(environ, start_response)
        finally:
            if self.should_ignore_error(error):
                error = None
            ctx.auto_pop(error)
    def __call__(self, environ, start_response):
        
        return self.wsgi_app(environ, start_response)
    def __repr__(self):
        return '<%s %r>' % (
            self.__class__.__name__,
            self.name,
        )
from functools import update_wrapper
from .helpers import _PackageBoundObject, _endpoint_from_view_func
class BlueprintSetupState(object):
    
    def __init__(self, blueprint, app, options, first_registration):
        self.app = app
        self.blueprint = blueprint
        self.options = options
        self.first_registration = first_registration
        subdomain = self.options.get('subdomain')
        if subdomain is None:
            subdomain = self.blueprint.subdomain
        self.subdomain = subdomain
        url_prefix = self.options.get('url_prefix')
        if url_prefix is None:
            url_prefix = self.blueprint.url_prefix
        self.url_prefix = url_prefix
        self.url_defaults = dict(self.blueprint.url_values_defaults)
        self.url_defaults.update(self.options.get('url_defaults', ()))
    def add_url_rule(self, rule, endpoint=None, view_func=None, **options):
        
        if self.url_prefix:
            rule = self.url_prefix + rule
        options.setdefault('subdomain', self.subdomain)
        if endpoint is None:
            endpoint = _endpoint_from_view_func(view_func)
        defaults = self.url_defaults
        if 'defaults' in options:
            defaults = dict(defaults, **options.pop('defaults'))
        self.app.add_url_rule(rule, '%s.%s' % (self.blueprint.name, endpoint),
                              view_func, defaults=defaults, **options)
class Blueprint(_PackageBoundObject):
    
    warn_on_modifications = False
    _got_registered_once = False
    def __init__(self, name, import_name, static_folder=None,
                 static_url_path=None, template_folder=None,
                 url_prefix=None, subdomain=None, url_defaults=None,
                 root_path=None):
        _PackageBoundObject.__init__(self, import_name, template_folder,
                                     root_path=root_path)
        self.name = name
        self.url_prefix = url_prefix
        self.subdomain = subdomain
        self.static_folder = static_folder
        self.static_url_path = static_url_path
        self.deferred_functions = []
        if url_defaults is None:
            url_defaults = {}
        self.url_values_defaults = url_defaults
    def record(self, func):
        
        if self._got_registered_once and self.warn_on_modifications:
            from warnings import warn
            warn(Warning('The blueprint was already registered once '
                         'but is getting modified now.  These changes '
                         'will not show up.'))
        self.deferred_functions.append(func)
    def record_once(self, func):
        
        def wrapper(state):
            if state.first_registration:
                func(state)
        return self.record(update_wrapper(wrapper, func))
    def make_setup_state(self, app, options, first_registration=False):
        
        return BlueprintSetupState(self, app, options, first_registration)
    def register(self, app, options, first_registration=False):
        
        self._got_registered_once = True
        state = self.make_setup_state(app, options, first_registration)
        if self.has_static_folder:
            state.add_url_rule(self.static_url_path + '/<path:filename>',
                               view_func=self.send_static_file,
                               endpoint='static')
        for deferred in self.deferred_functions:
            deferred(state)
    def route(self, rule, **options):
        
        def decorator(f):
            endpoint = options.pop("endpoint", f.__name__)
            self.add_url_rule(rule, endpoint, f, **options)
            return f
        return decorator
    def add_url_rule(self, rule, endpoint=None, view_func=None, **options):
        
        if endpoint:
            assert '.' not in endpoint, "Blueprint endpoints should not contain dots"
        self.record(lambda s:
            s.add_url_rule(rule, endpoint, view_func, **options))
    def endpoint(self, endpoint):
        
        def decorator(f):
            def register_endpoint(state):
                state.app.view_functions[endpoint] = f
            self.record_once(register_endpoint)
            return f
        return decorator
    def app_template_filter(self, name=None):
        
        def decorator(f):
            self.add_app_template_filter(f, name=name)
            return f
        return decorator
    def add_app_template_filter(self, f, name=None):
        
        def register_template(state):
            state.app.jinja_env.filters[name or f.__name__] = f
        self.record_once(register_template)
    def app_template_test(self, name=None):
        
        def decorator(f):
            self.add_app_template_test(f, name=name)
            return f
        return decorator
    def add_app_template_test(self, f, name=None):
        
        def register_template(state):
            state.app.jinja_env.tests[name or f.__name__] = f
        self.record_once(register_template)
    def app_template_global(self, name=None):
        
        def decorator(f):
            self.add_app_template_global(f, name=name)
            return f
        return decorator
    def add_app_template_global(self, f, name=None):
        
        def register_template(state):
            state.app.jinja_env.globals[name or f.__name__] = f
        self.record_once(register_template)
    def before_request(self, f):
        
        self.record_once(lambda s: s.app.before_request_funcs
            .setdefault(self.name, []).append(f))
        return f
    def before_app_request(self, f):
        
        self.record_once(lambda s: s.app.before_request_funcs
            .setdefault(None, []).append(f))
        return f
    def before_app_first_request(self, f):
        
        self.record_once(lambda s: s.app.before_first_request_funcs.append(f))
        return f
    def after_request(self, f):
        
        self.record_once(lambda s: s.app.after_request_funcs
            .setdefault(self.name, []).append(f))
        return f
    def after_app_request(self, f):
        
        self.record_once(lambda s: s.app.after_request_funcs
            .setdefault(None, []).append(f))
        return f
    def teardown_request(self, f):
        
        self.record_once(lambda s: s.app.teardown_request_funcs
            .setdefault(self.name, []).append(f))
        return f
    def teardown_app_request(self, f):
        
        self.record_once(lambda s: s.app.teardown_request_funcs
            .setdefault(None, []).append(f))
        return f
    def context_processor(self, f):
        
        self.record_once(lambda s: s.app.template_context_processors
            .setdefault(self.name, []).append(f))
        return f
    def app_context_processor(self, f):
        
        self.record_once(lambda s: s.app.template_context_processors
            .setdefault(None, []).append(f))
        return f
    def app_errorhandler(self, code):
        
        def decorator(f):
            self.record_once(lambda s: s.app.errorhandler(code)(f))
            return f
        return decorator
    def url_value_preprocessor(self, f):
        
        self.record_once(lambda s: s.app.url_value_preprocessors
            .setdefault(self.name, []).append(f))
        return f
    def url_defaults(self, f):
        
        self.record_once(lambda s: s.app.url_default_functions
            .setdefault(self.name, []).append(f))
        return f
    def app_url_value_preprocessor(self, f):
        
        self.record_once(lambda s: s.app.url_value_preprocessors
            .setdefault(None, []).append(f))
        return f
    def app_url_defaults(self, f):
        
        self.record_once(lambda s: s.app.url_default_functions
            .setdefault(None, []).append(f))
        return f
    def errorhandler(self, code_or_exception):
        
        def decorator(f):
            self.record_once(lambda s: s.app._register_error_handler(
                self.name, code_or_exception, f))
            return f
        return decorator
    def register_error_handler(self, code_or_exception, f):
        
        self.record_once(lambda s: s.app._register_error_handler(
            self.name, code_or_exception, f))
import os
import sys
from threading import Lock, Thread
from functools import update_wrapper
import click
from ._compat import iteritems, reraise
from .helpers import get_debug_flag
from . import __version__
class NoAppException(click.UsageError):
    
def find_best_app(module):
    
    from . import Flask
    for attr_name in 'app', 'application':
        app = getattr(module, attr_name, None)
        if app is not None and isinstance(app, Flask):
            return app
    matches = [v for k, v in iteritems(module.__dict__)
               if isinstance(v, Flask)]
    if len(matches) == 1:
        return matches[0]
    raise NoAppException('Failed to find application in module "%s".  Are '
                         'you sure it contains a Flask application?  Maybe '
                         'you wrapped it in a WSGI middleware or you are '
                         'using a factory function.' % module.__name__)
def prepare_exec_for_file(filename):
    
    module = []
    if os.path.split(filename)[1] == '__init__.py':
        filename = os.path.dirname(filename)
    elif filename.endswith('.py'):
        filename = filename[:-3]
    else:
        raise NoAppException('The file provided (%s) does exist but is not a '
                             'valid Python file.  This means that it cannot '
                             'be used as application.  Please change the '
                             'extension to .py' % filename)
    filename = os.path.realpath(filename)
    dirpath = filename
    while 1:
        dirpath, extra = os.path.split(dirpath)
        module.append(extra)
        if not os.path.isfile(os.path.join(dirpath, '__init__.py')):
            break
    sys.path.insert(0, dirpath)
    return '.'.join(module[::-1])
def locate_app(app_id):
    
    __traceback_hide__ = True
    if ':' in app_id:
        module, app_obj = app_id.split(':', 1)
    else:
        module = app_id
        app_obj = None
    __import__(module)
    mod = sys.modules[module]
    if app_obj is None:
        app = find_best_app(mod)
    else:
        app = getattr(mod, app_obj, None)
        if app is None:
            raise RuntimeError('Failed to find application in module "%s"'
                               % module)
    return app
def find_default_import_path():
    app = os.environ.get('FLASK_APP')
    if app is None:
        return
    if os.path.isfile(app):
        return prepare_exec_for_file(app)
    return app
def get_version(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    message = 'Flask %(version)s\nPython %(python_version)s'
    click.echo(message % {
        'version': __version__,
        'python_version': sys.version,
    }, color=ctx.color)
    ctx.exit()
version_option = click.Option(['--version'],
                              help='Show the flask version',
                              expose_value=False,
                              callback=get_version,
                              is_flag=True, is_eager=True)
class DispatchingApp(object):
    
    def __init__(self, loader, use_eager_loading=False):
        self.loader = loader
        self._app = None
        self._lock = Lock()
        self._bg_loading_exc_info = None
        if use_eager_loading:
            self._load_unlocked()
        else:
            self._load_in_background()
    def _load_in_background(self):
        def _load_app():
            __traceback_hide__ = True
            with self._lock:
                try:
                    self._load_unlocked()
                except Exception:
                    self._bg_loading_exc_info = sys.exc_info()
        t = Thread(target=_load_app, args=())
        t.start()
    def _flush_bg_loading_exception(self):
        __traceback_hide__ = True
        exc_info = self._bg_loading_exc_info
        if exc_info is not None:
            self._bg_loading_exc_info = None
            reraise(*exc_info)
    def _load_unlocked(self):
        __traceback_hide__ = True
        self._app = rv = self.loader()
        self._bg_loading_exc_info = None
        return rv
    def __call__(self, environ, start_response):
        __traceback_hide__ = True
        if self._app is not None:
            return self._app(environ, start_response)
        self._flush_bg_loading_exception()
        with self._lock:
            if self._app is not None:
                rv = self._app
            else:
                rv = self._load_unlocked()
            return rv(environ, start_response)
class ScriptInfo(object):
    
    def __init__(self, app_import_path=None, create_app=None):
        if create_app is None:
            if app_import_path is None:
                app_import_path = find_default_import_path()
            self.app_import_path = app_import_path
        else:
            app_import_path = None
        self.app_import_path = app_import_path
        self.create_app = create_app
        self.data = {}
        self._loaded_app = None
    def load_app(self):
        
        __traceback_hide__ = True
        if self._loaded_app is not None:
            return self._loaded_app
        if self.create_app is not None:
            rv = self.create_app(self)
        else:
            if not self.app_import_path:
                raise NoAppException(
                    'Could not locate Flask application. You did not provide '
                    'the FLASK_APP environment variable.\n\nFor more '
                    'information see '
                    'http://flask.pocoo.org/docs/latest/quickstart/')
            rv = locate_app(self.app_import_path)
        debug = get_debug_flag()
        if debug is not None:
            rv.debug = debug
        self._loaded_app = rv
        return rv
pass_script_info = click.make_pass_decorator(ScriptInfo, ensure=True)
def with_appcontext(f):
    
    @click.pass_context
    def decorator(__ctx, *args, **kwargs):
        with __ctx.ensure_object(ScriptInfo).load_app().app_context():
            return __ctx.invoke(f, *args, **kwargs)
    return update_wrapper(decorator, f)
class AppGroup(click.Group):
    
    def command(self, *args, **kwargs):
        
        wrap_for_ctx = kwargs.pop('with_appcontext', True)
        def decorator(f):
            if wrap_for_ctx:
                f = with_appcontext(f)
            return click.Group.command(self, *args, **kwargs)(f)
        return decorator
    def group(self, *args, **kwargs):
        
        kwargs.setdefault('cls', AppGroup)
        return click.Group.group(self, *args, **kwargs)
class FlaskGroup(AppGroup):
    
    def __init__(self, add_default_commands=True, create_app=None,
                 add_version_option=True, **extra):
        params = list(extra.pop('params', None) or ())
        if add_version_option:
            params.append(version_option)
        AppGroup.__init__(self, params=params, **extra)
        self.create_app = create_app
        if add_default_commands:
            self.add_command(run_command)
            self.add_command(shell_command)
        self._loaded_plugin_commands = False
    def _load_plugin_commands(self):
        if self._loaded_plugin_commands:
            return
        try:
            import pkg_resources
        except ImportError:
            self._loaded_plugin_commands = True
            return
        for ep in pkg_resources.iter_entry_points('flask.commands'):
            self.add_command(ep.load(), ep.name)
        self._loaded_plugin_commands = True
    def get_command(self, ctx, name):
        self._load_plugin_commands()
        rv = AppGroup.get_command(self, ctx, name)
        if rv is not None:
            return rv
        info = ctx.ensure_object(ScriptInfo)
        try:
            rv = info.load_app().cli.get_command(ctx, name)
            if rv is not None:
                return rv
        except NoAppException:
            pass
    def list_commands(self, ctx):
        self._load_plugin_commands()
        rv = set(click.Group.list_commands(self, ctx))
        info = ctx.ensure_object(ScriptInfo)
        try:
            rv.update(info.load_app().cli.list_commands(ctx))
        except Exception:
            pass
        return sorted(rv)
    def main(self, *args, **kwargs):
        obj = kwargs.get('obj')
        if obj is None:
            obj = ScriptInfo(create_app=self.create_app)
        kwargs['obj'] = obj
        kwargs.setdefault('auto_envvar_prefix', 'FLASK')
        return AppGroup.main(self, *args, **kwargs)
@click.command('run', short_help='Runs a development server.')
@click.option('--host', '-h', default='127.0.0.1',
              help='The interface to bind to.')
@click.option('--port', '-p', default=5000,
              help='The port to bind to.')
@click.option('--reload/--no-reload', default=None,
              help='Enable or disable the reloader.  By default the reloader '
              'is active if debug is enabled.')
@click.option('--debugger/--no-debugger', default=None,
              help='Enable or disable the debugger.  By default the debugger '
              'is active if debug is enabled.')
@click.option('--eager-loading/--lazy-loader', default=None,
              help='Enable or disable eager loading.  By default eager '
              'loading is enabled if the reloader is disabled.')
@click.option('--with-threads/--without-threads', default=False,
              help='Enable or disable multithreading.')
@pass_script_info
def run_command(info, host, port, reload, debugger, eager_loading,
                with_threads):
    
    from werkzeug.serving import run_simple
    debug = get_debug_flag()
    if reload is None:
        reload = bool(debug)
    if debugger is None:
        debugger = bool(debug)
    if eager_loading is None:
        eager_loading = not reload
    app = DispatchingApp(info.load_app, use_eager_loading=eager_loading)
    if os.environ.get('WERKZEUG_RUN_MAIN') != 'true':
        if info.app_import_path is not None:
            print(' * Serving Flask app "%s"' % info.app_import_path)
        if debug is not None:
            print(' * Forcing debug mode %s' % (debug and 'on' or 'off'))
    run_simple(host, port, app, use_reloader=reload,
               use_debugger=debugger, threaded=with_threads,
               passthrough_errors=True)
@click.command('shell', short_help='Runs a shell in the app context.')
@with_appcontext
def shell_command():
    
    import code
    from flask.globals import _app_ctx_stack
    app = _app_ctx_stack.top.app
    banner = 'Python %s on %s\nApp: %s%s\nInstance: %s' % (
        sys.version,
        sys.platform,
        app.import_name,
        app.debug and ' [debug]' or '',
        app.instance_path,
    )
    ctx = {}
    startup = os.environ.get('PYTHONSTARTUP')
    if startup and os.path.isfile(startup):
        with open(startup, 'r') as f:
            eval(compile(f.read(), startup, 'exec'), ctx)
    ctx.update(app.make_shell_context())
    code.interact(banner=banner, local=ctx)
cli = FlaskGroup(help= % {
    'cmd': os.name == 'posix' and 'export' or 'set',
    'prefix': os.name == 'posix' and '$ ' or '',
})
def main(as_module=False):
    this_module = __package__ + '.cli'
    args = sys.argv[1:]
    if as_module:
        if sys.version_info >= (2, 7):
            name = 'python -m ' + this_module.rsplit('.', 1)[0]
        else:
            name = 'python -m ' + this_module
        sys.argv = ['-m', this_module] + sys.argv[1:]
    else:
        name = None
    cli.main(args=args, prog_name=name)
if __name__ == '__main__':
    main(as_module=True)
import os
import types
import errno
from werkzeug.utils import import_string
from ._compat import string_types, iteritems
from . import json
class ConfigAttribute(object):
    
    def __init__(self, name, get_converter=None):
        self.__name__ = name
        self.get_converter = get_converter
    def __get__(self, obj, type=None):
        if obj is None:
            return self
        rv = obj.config[self.__name__]
        if self.get_converter is not None:
            rv = self.get_converter(rv)
        return rv
    def __set__(self, obj, value):
        obj.config[self.__name__] = value
class Config(dict):
    
    def __init__(self, root_path, defaults=None):
        dict.__init__(self, defaults or {})
        self.root_path = root_path
    def from_envvar(self, variable_name, silent=False):
        
        rv = os.environ.get(variable_name)
        if not rv:
            if silent:
                return False
            raise RuntimeError('The environment variable %r is not set '
                               'and as such configuration could not be '
                               'loaded.  Set this variable and make it '
                               'point to a configuration file' %
                               variable_name)
        return self.from_pyfile(rv, silent=silent)
    def from_pyfile(self, filename, silent=False):
        
        filename = os.path.join(self.root_path, filename)
        d = types.ModuleType('config')
        d.__file__ = filename
        try:
            with open(filename) as config_file:
                exec(compile(config_file.read(), filename, 'exec'), d.__dict__)
        except IOError as e:
            if silent and e.errno in (errno.ENOENT, errno.EISDIR):
                return False
            e.strerror = 'Unable to load configuration file (%s)' % e.strerror
            raise
        self.from_object(d)
        return True
    def from_object(self, obj):
        
        if isinstance(obj, string_types):
            obj = import_string(obj)
        for key in dir(obj):
            if key.isupper():
                self[key] = getattr(obj, key)
    def from_json(self, filename, silent=False):
        
        filename = os.path.join(self.root_path, filename)
        try:
            with open(filename) as json_file:
                obj = json.loads(json_file.read())
        except IOError as e:
            if silent and e.errno in (errno.ENOENT, errno.EISDIR):
                return False
            e.strerror = 'Unable to load configuration file (%s)' % e.strerror
            raise
        return self.from_mapping(obj)
    def from_mapping(self, *mapping, **kwargs):
        
        mappings = []
        if len(mapping) == 1:
            if hasattr(mapping[0], 'items'):
                mappings.append(mapping[0].items())
            else:
                mappings.append(mapping[0])
        elif len(mapping) > 1:
            raise TypeError(
                'expected at most 1 positional argument, got %d' % len(mapping)
            )
        mappings.append(kwargs.items())
        for mapping in mappings:
            for (key, value) in mapping:
                if key.isupper():
                    self[key] = value
        return True
    def get_namespace(self, namespace, lowercase=True, trim_namespace=True):
        
        rv = {}
        for k, v in iteritems(self):
            if not k.startswith(namespace):
                continue
            if trim_namespace:
                key = k[len(namespace):]
            else:
                key = k
            if lowercase:
                key = key.lower()
            rv[key] = v
        return rv
    def __repr__(self):
        return '<%s %s>' % (self.__class__.__name__, dict.__repr__(self))
import sys
from functools import update_wrapper
from werkzeug.exceptions import HTTPException
from .globals import _request_ctx_stack, _app_ctx_stack
from .signals import appcontext_pushed, appcontext_popped
from ._compat import BROKEN_PYPY_CTXMGR_EXIT, reraise
_sentinel = object()
class _AppCtxGlobals(object):
    
    def get(self, name, default=None):
        return self.__dict__.get(name, default)
    def pop(self, name, default=_sentinel):
        if default is _sentinel:
            return self.__dict__.pop(name)
        else:
            return self.__dict__.pop(name, default)
    def setdefault(self, name, default=None):
        return self.__dict__.setdefault(name, default)
    def __contains__(self, item):
        return item in self.__dict__
    def __iter__(self):
        return iter(self.__dict__)
    def __repr__(self):
        top = _app_ctx_stack.top
        if top is not None:
            return '<flask.g of %r>' % top.app.name
        return object.__repr__(self)
def after_this_request(f):
    
    _request_ctx_stack.top._after_request_functions.append(f)
    return f
def copy_current_request_context(f):
    
    top = _request_ctx_stack.top
    if top is None:
        raise RuntimeError('This decorator can only be used at local scopes '
            'when a request context is on the stack.  For instance within '
            'view functions.')
    reqctx = top.copy()
    def wrapper(*args, **kwargs):
        with reqctx:
            return f(*args, **kwargs)
    return update_wrapper(wrapper, f)
def has_request_context():
    
    return _request_ctx_stack.top is not None
def has_app_context():
    
    return _app_ctx_stack.top is not None
class AppContext(object):
    
    def __init__(self, app):
        self.app = app
        self.url_adapter = app.create_url_adapter(None)
        self.g = app.app_ctx_globals_class()
        self._refcnt = 0
    def push(self):
        
        self._refcnt += 1
        if hasattr(sys, 'exc_clear'):
            sys.exc_clear()
        _app_ctx_stack.push(self)
        appcontext_pushed.send(self.app)
    def pop(self, exc=_sentinel):
        
        try:
            self._refcnt -= 1
            if self._refcnt <= 0:
                if exc is _sentinel:
                    exc = sys.exc_info()[1]
                self.app.do_teardown_appcontext(exc)
        finally:
            rv = _app_ctx_stack.pop()
        assert rv is self, 'Popped wrong app context.  (%r instead of %r)' \
            % (rv, self)
        appcontext_popped.send(self.app)
    def __enter__(self):
        self.push()
        return self
    def __exit__(self, exc_type, exc_value, tb):
        self.pop(exc_value)
        if BROKEN_PYPY_CTXMGR_EXIT and exc_type is not None:
            reraise(exc_type, exc_value, tb)
class RequestContext(object):
    
    def __init__(self, app, environ, request=None):
        self.app = app
        if request is None:
            request = app.request_class(environ)
        self.request = request
        self.url_adapter = app.create_url_adapter(self.request)
        self.flashes = None
        self.session = None
        self._implicit_app_ctx_stack = []
        self.preserved = False
        self._preserved_exc = None
        self._after_request_functions = []
        self.match_request()
    def _get_g(self):
        return _app_ctx_stack.top.g
    def _set_g(self, value):
        _app_ctx_stack.top.g = value
    g = property(_get_g, _set_g)
    del _get_g, _set_g
    def copy(self):
        
        return self.__class__(self.app,
            environ=self.request.environ,
            request=self.request
        )
    def match_request(self):
        
        try:
            url_rule, self.request.view_args = \
                self.url_adapter.match(return_rule=True)
            self.request.url_rule = url_rule
        except HTTPException as e:
            self.request.routing_exception = e
    def push(self):
        
        top = _request_ctx_stack.top
        if top is not None and top.preserved:
            top.pop(top._preserved_exc)
        app_ctx = _app_ctx_stack.top
        if app_ctx is None or app_ctx.app != self.app:
            app_ctx = self.app.app_context()
            app_ctx.push()
            self._implicit_app_ctx_stack.append(app_ctx)
        else:
            self._implicit_app_ctx_stack.append(None)
        if hasattr(sys, 'exc_clear'):
            sys.exc_clear()
        _request_ctx_stack.push(self)
        self.session = self.app.open_session(self.request)
        if self.session is None:
            self.session = self.app.make_null_session()
    def pop(self, exc=_sentinel):
        
        app_ctx = self._implicit_app_ctx_stack.pop()
        try:
            clear_request = False
            if not self._implicit_app_ctx_stack:
                self.preserved = False
                self._preserved_exc = None
                if exc is _sentinel:
                    exc = sys.exc_info()[1]
                self.app.do_teardown_request(exc)
                if hasattr(sys, 'exc_clear'):
                    sys.exc_clear()
                request_close = getattr(self.request, 'close', None)
                if request_close is not None:
                    request_close()
                clear_request = True
        finally:
            rv = _request_ctx_stack.pop()
            if clear_request:
                rv.request.environ['werkzeug.request'] = None
            if app_ctx is not None:
                app_ctx.pop(exc)
            assert rv is self, 'Popped wrong request context.  ' \
                '(%r instead of %r)' % (rv, self)
    def auto_pop(self, exc):
        if self.request.environ.get('flask._preserve_context') or \
           (exc is not None and self.app.preserve_context_on_exception):
            self.preserved = True
            self._preserved_exc = exc
        else:
            self.pop(exc)
    def __enter__(self):
        self.push()
        return self
    def __exit__(self, exc_type, exc_value, tb):
        self.auto_pop(exc_value)
        if BROKEN_PYPY_CTXMGR_EXIT and exc_type is not None:
            reraise(exc_type, exc_value, tb)
    def __repr__(self):
        return '<%s \'%s\' [%s] of %s>' % (
            self.__class__.__name__,
            self.request.url,
            self.request.method,
            self.app.name,
        )
from ._compat import implements_to_string, text_type
from .app import Flask
from .blueprints import Blueprint
from .globals import _request_ctx_stack
class UnexpectedUnicodeError(AssertionError, UnicodeError):
    
@implements_to_string
class DebugFilesKeyError(KeyError, AssertionError):
    
    def __init__(self, request, key):
        form_matches = request.form.getlist(key)
        buf = ['You tried to access the file "%s" in the request.files '
               'dictionary but it does not exist.  The mimetype for the request '
               'is "%s" instead of "multipart/form-data" which means that no '
               'file contents were transmitted.  To fix this error you should '
               'provide enctype="multipart/form-data" in your form.' %
               (key, request.mimetype)]
        if form_matches:
            buf.append('\n\nThe browser instead transmitted some file names. '
                       'This was submitted: %s' % ', '.join('"%s"' % x
                            for x in form_matches))
        self.msg = ''.join(buf)
    def __str__(self):
        return self.msg
class FormDataRoutingRedirect(AssertionError):
    
    def __init__(self, request):
        exc = request.routing_exception
        buf = ['A request was sent to this URL (%s) but a redirect was '
               'issued automatically by the routing system to "%s".'
               % (request.url, exc.new_url)]
        if request.base_url + '/' == exc.new_url.split('?')[0]:
            buf.append('  The URL was defined with a trailing slash so '
                       'Flask will automatically redirect to the URL '
                       'with the trailing slash if it was accessed '
                       'without one.')
        buf.append('  Make sure to directly send your %s-request to this URL '
                   'since we can\'t make browsers or HTTP clients redirect '
                   'with form data reliably or without user interaction.' %
                   request.method)
        buf.append('\n\nNote: this exception is only raised in debug mode')
        AssertionError.__init__(self, ''.join(buf).encode('utf-8'))
def attach_enctype_error_multidict(request):
    
    oldcls = request.files.__class__
    class newcls(oldcls):
        def __getitem__(self, key):
            try:
                return oldcls.__getitem__(self, key)
            except KeyError:
                if key not in request.form:
                    raise
                raise DebugFilesKeyError(request, key)
    newcls.__name__ = oldcls.__name__
    newcls.__module__ = oldcls.__module__
    request.files.__class__ = newcls
def _dump_loader_info(loader):
    yield 'class: %s.%s' % (type(loader).__module__, type(loader).__name__)
    for key, value in sorted(loader.__dict__.items()):
        if key.startswith('_'):
            continue
        if isinstance(value, (tuple, list)):
            if not all(isinstance(x, (str, text_type)) for x in value):
                continue
            yield '%s:' % key
            for item in value:
                yield '  - %s' % item
            continue
        elif not isinstance(value, (str, text_type, int, float, bool)):
            continue
        yield '%s: %r' % (key, value)
def explain_template_loading_attempts(app, template, attempts):
    
    info = ['Locating template "%s":' % template]
    total_found = 0
    blueprint = None
    reqctx = _request_ctx_stack.top
    if reqctx is not None and reqctx.request.blueprint is not None:
        blueprint = reqctx.request.blueprint
    for idx, (loader, srcobj, triple) in enumerate(attempts):
        if isinstance(srcobj, Flask):
            src_info = 'application "%s"' % srcobj.import_name
        elif isinstance(srcobj, Blueprint):
            src_info = 'blueprint "%s" (%s)' % (srcobj.name,
                                                srcobj.import_name)
        else:
            src_info = repr(srcobj)
        info.append('% 5d: trying loader of %s' % (
            idx + 1, src_info))
        for line in _dump_loader_info(loader):
            info.append('       %s' % line)
        if triple is None:
            detail = 'no match'
        else:
            detail = 'found (%r)' % (triple[1] or '<string>')
            total_found += 1
        info.append('       -> %s' % detail)
    seems_fishy = False
    if total_found == 0:
        info.append('Error: the template could not be found.')
        seems_fishy = True
    elif total_found > 1:
        info.append('Warning: multiple loaders returned a match for the template.')
        seems_fishy = True
    if blueprint is not None and seems_fishy:
        info.append('  The template was looked up from an endpoint that '
                    'belongs to the blueprint "%s".' % blueprint)
        info.append('  Maybe you did not place a template in the right folder?')
        info.append('  See http://flask.pocoo.org/docs/blueprints/#templates')
    app.logger.info('\n'.join(info))
import sys
import os
import warnings
from ._compat import reraise
class ExtDeprecationWarning(DeprecationWarning):
    pass
warnings.simplefilter('always', ExtDeprecationWarning)
class ExtensionImporter(object):
    
    def __init__(self, module_choices, wrapper_module):
        self.module_choices = module_choices
        self.wrapper_module = wrapper_module
        self.prefix = wrapper_module + '.'
        self.prefix_cutoff = wrapper_module.count('.') + 1
    def __eq__(self, other):
        return self.__class__.__module__ == other.__class__.__module__ and \
               self.__class__.__name__ == other.__class__.__name__ and \
               self.wrapper_module == other.wrapper_module and \
               self.module_choices == other.module_choices
    def __ne__(self, other):
        return not self.__eq__(other)
    def install(self):
        sys.meta_path[:] = [x for x in sys.meta_path if self != x] + [self]
    def find_module(self, fullname, path=None):
        if fullname.startswith(self.prefix) and \
           fullname != 'flask.ext.ExtDeprecationWarning':
            return self
    def load_module(self, fullname):
        if fullname in sys.modules:
            return sys.modules[fullname]
        modname = fullname.split('.', self.prefix_cutoff)[self.prefix_cutoff]
        warnings.warn(
            "Importing flask.ext.{x} is deprecated, use flask_{x} instead."
            .format(x=modname), ExtDeprecationWarning, stacklevel=2
        )
        for path in self.module_choices:
            realname = path % modname
            try:
                __import__(realname)
            except ImportError:
                exc_type, exc_value, tb = sys.exc_info()
                sys.modules.pop(fullname, None)
                if self.is_important_traceback(realname, tb):
                    reraise(exc_type, exc_value, tb.tb_next)
                continue
            module = sys.modules[fullname] = sys.modules[realname]
            if '.' not in modname:
                setattr(sys.modules[self.wrapper_module], modname, module)
            if realname.startswith('flaskext.'):
                warnings.warn(
                    "Detected extension named flaskext.{x}, please rename it "
                    "to flask_{x}. The old form is deprecated."
                    .format(x=modname), ExtDeprecationWarning
                )
            return module
        raise ImportError('No module named %s' % fullname)
    def is_important_traceback(self, important_module, tb):
        
        while tb is not None:
            if self.is_important_frame(important_module, tb):
                return True
            tb = tb.tb_next
        return False
    def is_important_frame(self, important_module, tb):
        
        g = tb.tb_frame.f_globals
        if '__name__' not in g:
            return False
        module_name = g['__name__']
        if module_name == important_module:
            return True
        filename = os.path.abspath(tb.tb_frame.f_code.co_filename)
        test_string = os.path.sep + important_module.replace('.', os.path.sep)
        return test_string + '.py' in filename or \
               test_string + os.path.sep + '__init__.py' in filename
from functools import partial
from werkzeug.local import LocalStack, LocalProxy
_request_ctx_err_msg = '''\
Working outside of request context.
This typically means that you attempted to use functionality that needed
an active HTTP request.  Consult the documentation on testing for
information about how to avoid this problem.\
'''
_app_ctx_err_msg = '''\
Working outside of application context.
This typically means that you attempted to use functionality that needed
to interface with the current application object in a way.  To solve
this set up an application context with app.app_context().  See the
documentation for more information.\
'''
def _lookup_req_object(name):
    top = _request_ctx_stack.top
    if top is None:
        raise RuntimeError(_request_ctx_err_msg)
    return getattr(top, name)
def _lookup_app_object(name):
    top = _app_ctx_stack.top
    if top is None:
        raise RuntimeError(_app_ctx_err_msg)
    return getattr(top, name)
def _find_app():
    top = _app_ctx_stack.top
    if top is None:
        raise RuntimeError(_app_ctx_err_msg)
    return top.app
_request_ctx_stack = LocalStack()
_app_ctx_stack = LocalStack()
current_app = LocalProxy(_find_app)
request = LocalProxy(partial(_lookup_req_object, 'request'))
session = LocalProxy(partial(_lookup_req_object, 'session'))
g = LocalProxy(partial(_lookup_app_object, 'g'))
import os
import sys
import pkgutil
import posixpath
import mimetypes
from time import time
from zlib import adler32
from threading import RLock
from werkzeug.routing import BuildError
from functools import update_wrapper
try:
    from werkzeug.urls import url_quote
except ImportError:
    from urlparse import quote as url_quote
from werkzeug.datastructures import Headers
from werkzeug.exceptions import BadRequest, NotFound
try:
    from werkzeug.wsgi import wrap_file
except ImportError:
    from werkzeug.utils import wrap_file
from jinja2 import FileSystemLoader
from .signals import message_flashed
from .globals import session, _request_ctx_stack, _app_ctx_stack, \
     current_app, request
from ._compat import string_types, text_type, PY2
_missing = object()
_os_alt_seps = list(sep for sep in [os.path.sep, os.path.altsep]
                    if sep not in (None, '/'))
def get_debug_flag(default=None):
    val = os.environ.get('FLASK_DEBUG')
    if not val:
        return default
    return val not in ('0', 'false', 'no')
def _endpoint_from_view_func(view_func):
    
    assert view_func is not None, 'expected view func if endpoint ' \
                                  'is not provided.'
    return view_func.__name__
def stream_with_context(generator_or_function):
    
    try:
        gen = iter(generator_or_function)
    except TypeError:
        def decorator(*args, **kwargs):
            gen = generator_or_function(*args, **kwargs)
            return stream_with_context(gen)
        return update_wrapper(decorator, generator_or_function)
    def generator():
        ctx = _request_ctx_stack.top
        if ctx is None:
            raise RuntimeError('Attempted to stream with context but '
                'there was no context in the first place to keep around.')
        with ctx:
            yield None
            try:
                for item in gen:
                    yield item
            finally:
                if hasattr(gen, 'close'):
                    gen.close()
    wrapped_g = generator()
    next(wrapped_g)
    return wrapped_g
def make_response(*args):
    
    if not args:
        return current_app.response_class()
    if len(args) == 1:
        args = args[0]
    return current_app.make_response(args)
def url_for(endpoint, **values):
    
    appctx = _app_ctx_stack.top
    reqctx = _request_ctx_stack.top
    if appctx is None:
        raise RuntimeError('Attempted to generate a URL without the '
                           'application context being pushed. This has to be '
                           'executed when application context is available.')
    if reqctx is not None:
        url_adapter = reqctx.url_adapter
        blueprint_name = request.blueprint
        if not reqctx.request._is_old_module:
            if endpoint[:1] == '.':
                if blueprint_name is not None:
                    endpoint = blueprint_name + endpoint
                else:
                    endpoint = endpoint[1:]
        else:
            if '.' not in endpoint:
                if blueprint_name is not None:
                    endpoint = blueprint_name + '.' + endpoint
            elif endpoint.startswith('.'):
                endpoint = endpoint[1:]
        external = values.pop('_external', False)
    else:
        url_adapter = appctx.url_adapter
        if url_adapter is None:
            raise RuntimeError('Application was not able to create a URL '
                               'adapter for request independent URL generation. '
                               'You might be able to fix this by setting '
                               'the SERVER_NAME config variable.')
        external = values.pop('_external', True)
    anchor = values.pop('_anchor', None)
    method = values.pop('_method', None)
    scheme = values.pop('_scheme', None)
    appctx.app.inject_url_defaults(endpoint, values)
    old_scheme = None
    if scheme is not None:
        if not external:
            raise ValueError('When specifying _scheme, _external must be True')
        old_scheme = url_adapter.url_scheme
        url_adapter.url_scheme = scheme
    try:
        try:
            rv = url_adapter.build(endpoint, values, method=method,
                                   force_external=external)
        finally:
            if old_scheme is not None:
                url_adapter.url_scheme = old_scheme
    except BuildError as error:
        values['_external'] = external
        values['_anchor'] = anchor
        values['_method'] = method
        return appctx.app.handle_url_build_error(error, endpoint, values)
    if anchor is not None:
        rv += '#' + url_quote(anchor)
    return rv
def get_template_attribute(template_name, attribute):
    
    return getattr(current_app.jinja_env.get_template(template_name).module,
                   attribute)
def flash(message, category='message'):
    
    flashes = session.get('_flashes', [])
    flashes.append((category, message))
    session['_flashes'] = flashes
    message_flashed.send(current_app._get_current_object(),
                         message=message, category=category)
def get_flashed_messages(with_categories=False, category_filter=[]):
    
    flashes = _request_ctx_stack.top.flashes
    if flashes is None:
        _request_ctx_stack.top.flashes = flashes = session.pop('_flashes') \
            if '_flashes' in session else []
    if category_filter:
        flashes = list(filter(lambda f: f[0] in category_filter, flashes))
    if not with_categories:
        return [x[1] for x in flashes]
    return flashes
def send_file(filename_or_fp, mimetype=None, as_attachment=False,
              attachment_filename=None, add_etags=True,
              cache_timeout=None, conditional=False, last_modified=None):
    
    mtime = None
    if isinstance(filename_or_fp, string_types):
        filename = filename_or_fp
        file = None
    else:
        file = filename_or_fp
        filename = getattr(file, 'name', None)
    if filename is not None:
        if not os.path.isabs(filename):
            filename = os.path.join(current_app.root_path, filename)
    if mimetype is None and (filename or attachment_filename):
        mimetype = mimetypes.guess_type(filename or attachment_filename)[0]
    if mimetype is None:
        mimetype = 'application/octet-stream'
    headers = Headers()
    if as_attachment:
        if attachment_filename is None:
            if filename is None:
                raise TypeError('filename unavailable, required for '
                                'sending as attachment')
            attachment_filename = os.path.basename(filename)
        headers.add('Content-Disposition', 'attachment',
                    filename=attachment_filename)
    if current_app.use_x_sendfile and filename:
        if file is not None:
            file.close()
        headers['X-Sendfile'] = filename
        headers['Content-Length'] = os.path.getsize(filename)
        data = None
    else:
        if file is None:
            file = open(filename, 'rb')
            mtime = os.path.getmtime(filename)
            headers['Content-Length'] = os.path.getsize(filename)
        data = wrap_file(request.environ, file)
    rv = current_app.response_class(data, mimetype=mimetype, headers=headers,
                                    direct_passthrough=True)
    if last_modified is not None:
        rv.last_modified = last_modified
    elif mtime is not None:
        rv.last_modified = mtime
    rv.cache_control.public = True
    if cache_timeout is None:
        cache_timeout = current_app.get_send_file_max_age(filename)
    if cache_timeout is not None:
        rv.cache_control.max_age = cache_timeout
        rv.expires = int(time() + cache_timeout)
    if add_etags and filename is not None and file is None:
        from warnings import warn
        try:
            rv.set_etag('%s-%s-%s' % (
                os.path.getmtime(filename),
                os.path.getsize(filename),
                adler32(
                    filename.encode('utf-8') if isinstance(filename, text_type)
                    else filename
                ) & 0xffffffff
            ))
        except OSError:
            warn('Access %s failed, maybe it does not exist, so ignore etags in '
                 'headers' % filename, stacklevel=2)
        if conditional:
            rv = rv.make_conditional(request)
            if rv.status_code == 304:
                rv.headers.pop('x-sendfile', None)
    return rv
def safe_join(directory, *pathnames):
    
    for filename in pathnames:
        if filename != '':
            filename = posixpath.normpath(filename)
        for sep in _os_alt_seps:
            if sep in filename:
                raise NotFound()
        if os.path.isabs(filename) or \
           filename == '..' or \
           filename.startswith('../'):
            raise NotFound()
        directory = os.path.join(directory, filename)
    return directory
def send_from_directory(directory, filename, **options):
    
    filename = safe_join(directory, filename)
    if not os.path.isabs(filename):
        filename = os.path.join(current_app.root_path, filename)
    try:
        if not os.path.isfile(filename):
            raise NotFound()
    except (TypeError, ValueError):
        raise BadRequest()
    options.setdefault('conditional', True)
    return send_file(filename, **options)
def get_root_path(import_name):
    
    mod = sys.modules.get(import_name)
    if mod is not None and hasattr(mod, '__file__'):
        return os.path.dirname(os.path.abspath(mod.__file__))
    loader = pkgutil.get_loader(import_name)
    if loader is None or import_name == '__main__':
        return os.getcwd()
    if hasattr(loader, 'get_filename'):
        filepath = loader.get_filename(import_name)
    else:
        __import__(import_name)
        mod = sys.modules[import_name]
        filepath = getattr(mod, '__file__', None)
        if filepath is None:
            raise RuntimeError('No root path can be found for the provided '
                               'module "%s".  This can happen because the '
                               'module came from an import hook that does '
                               'not provide file name information or because '
                               'it\'s a namespace package.  In this case '
                               'the root path needs to be explicitly '
                               'provided.' % import_name)
    return os.path.dirname(os.path.abspath(filepath))
def _matching_loader_thinks_module_is_package(loader, mod_name):
    
    if hasattr(loader, 'is_package'):
        return loader.is_package(mod_name)
    elif (loader.__class__.__module__ == '_frozen_importlib' and
          loader.__class__.__name__ == 'NamespaceLoader'):
        return True
    raise AttributeError(
        ('%s.is_package() method is missing but is required by Flask of '
         'PEP 302 import hooks.  If you do not use import hooks and '
         'you encounter this error please file a bug against Flask.') %
        loader.__class__.__name__)
def find_package(import_name):
    
    root_mod_name = import_name.split('.')[0]
    loader = pkgutil.get_loader(root_mod_name)
    if loader is None or import_name == '__main__':
        package_path = os.getcwd()
    else:
        if hasattr(loader, 'get_filename'):
            filename = loader.get_filename(root_mod_name)
        elif hasattr(loader, 'archive'):
            filename = loader.archive
        else:
            __import__(import_name)
            filename = sys.modules[import_name].__file__
        package_path = os.path.abspath(os.path.dirname(filename))
        if _matching_loader_thinks_module_is_package(
                loader, root_mod_name):
            package_path = os.path.dirname(package_path)
    site_parent, site_folder = os.path.split(package_path)
    py_prefix = os.path.abspath(sys.prefix)
    if package_path.startswith(py_prefix):
        return py_prefix, package_path
    elif site_folder.lower() == 'site-packages':
        parent, folder = os.path.split(site_parent)
        if folder.lower() == 'lib':
            base_dir = parent
        elif os.path.basename(parent).lower() == 'lib':
            base_dir = os.path.dirname(parent)
        else:
            base_dir = site_parent
        return base_dir, package_path
    return None, package_path
class locked_cached_property(object):
    
    def __init__(self, func, name=None, doc=None):
        self.__name__ = name or func.__name__
        self.__module__ = func.__module__
        self.__doc__ = doc or func.__doc__
        self.func = func
        self.lock = RLock()
    def __get__(self, obj, type=None):
        if obj is None:
            return self
        with self.lock:
            value = obj.__dict__.get(self.__name__, _missing)
            if value is _missing:
                value = self.func(obj)
                obj.__dict__[self.__name__] = value
            return value
class _PackageBoundObject(object):
    def __init__(self, import_name, template_folder=None, root_path=None):
        self.import_name = import_name
        self.template_folder = template_folder
        if root_path is None:
            root_path = get_root_path(self.import_name)
        self.root_path = root_path
        self._static_folder = None
        self._static_url_path = None
    def _get_static_folder(self):
        if self._static_folder is not None:
            return os.path.join(self.root_path, self._static_folder)
    def _set_static_folder(self, value):
        self._static_folder = value
    static_folder = property(_get_static_folder, _set_static_folder, doc='''
    The absolute path to the configured static folder.
    ''')
    del _get_static_folder, _set_static_folder
    def _get_static_url_path(self):
        if self._static_url_path is not None:
            return self._static_url_path
        if self.static_folder is not None:
            return '/' + os.path.basename(self.static_folder)
    def _set_static_url_path(self, value):
        self._static_url_path = value
    static_url_path = property(_get_static_url_path, _set_static_url_path)
    del _get_static_url_path, _set_static_url_path
    @property
    def has_static_folder(self):
        
        return self.static_folder is not None
    @locked_cached_property
    def jinja_loader(self):
        
        if self.template_folder is not None:
            return FileSystemLoader(os.path.join(self.root_path,
                                                 self.template_folder))
    def get_send_file_max_age(self, filename):
        
        return total_seconds(current_app.send_file_max_age_default)
    def send_static_file(self, filename):
        
        if not self.has_static_folder:
            raise RuntimeError('No static folder for this object')
        cache_timeout = self.get_send_file_max_age(filename)
        return send_from_directory(self.static_folder, filename,
                                   cache_timeout=cache_timeout)
    def open_resource(self, resource, mode='rb'):
        
        if mode not in ('r', 'rb'):
            raise ValueError('Resources can only be opened for reading')
        return open(os.path.join(self.root_path, resource), mode)
def total_seconds(td):
    
    return td.days * 60 * 60 * 24 + td.seconds
import io
import uuid
from datetime import date
from .globals import current_app, request
from ._compat import text_type, PY2
from werkzeug.http import http_date
from jinja2 import Markup
from itsdangerous import json as _json
_slash_escape = '\\/' not in _json.dumps('/')
__all__ = ['dump', 'dumps', 'load', 'loads', 'htmlsafe_dump',
           'htmlsafe_dumps', 'JSONDecoder', 'JSONEncoder',
           'jsonify']
def _wrap_reader_for_text(fp, encoding):
    if isinstance(fp.read(0), bytes):
        fp = io.TextIOWrapper(io.BufferedReader(fp), encoding)
    return fp
def _wrap_writer_for_text(fp, encoding):
    try:
        fp.write('')
    except TypeError:
        fp = io.TextIOWrapper(fp, encoding)
    return fp
class JSONEncoder(_json.JSONEncoder):
    
    def default(self, o):
        
        if isinstance(o, date):
            return http_date(o.timetuple())
        if isinstance(o, uuid.UUID):
            return str(o)
        if hasattr(o, '__html__'):
            return text_type(o.__html__())
        return _json.JSONEncoder.default(self, o)
class JSONDecoder(_json.JSONDecoder):
    
def _dump_arg_defaults(kwargs):
    
    if current_app:
        kwargs.setdefault('cls', current_app.json_encoder)
        if not current_app.config['JSON_AS_ASCII']:
            kwargs.setdefault('ensure_ascii', False)
        kwargs.setdefault('sort_keys', current_app.config['JSON_SORT_KEYS'])
    else:
        kwargs.setdefault('sort_keys', True)
        kwargs.setdefault('cls', JSONEncoder)
def _load_arg_defaults(kwargs):
    
    if current_app:
        kwargs.setdefault('cls', current_app.json_decoder)
    else:
        kwargs.setdefault('cls', JSONDecoder)
def dumps(obj, **kwargs):
    
    _dump_arg_defaults(kwargs)
    encoding = kwargs.pop('encoding', None)
    rv = _json.dumps(obj, **kwargs)
    if encoding is not None and isinstance(rv, text_type):
        rv = rv.encode(encoding)
    return rv
def dump(obj, fp, **kwargs):
    
    _dump_arg_defaults(kwargs)
    encoding = kwargs.pop('encoding', None)
    if encoding is not None:
        fp = _wrap_writer_for_text(fp, encoding)
    _json.dump(obj, fp, **kwargs)
def loads(s, **kwargs):
    
    _load_arg_defaults(kwargs)
    if isinstance(s, bytes):
        s = s.decode(kwargs.pop('encoding', None) or 'utf-8')
    return _json.loads(s, **kwargs)
def load(fp, **kwargs):
    
    _load_arg_defaults(kwargs)
    if not PY2:
        fp = _wrap_reader_for_text(fp, kwargs.pop('encoding', None) or 'utf-8')
    return _json.load(fp, **kwargs)
def htmlsafe_dumps(obj, **kwargs):
    
    rv = dumps(obj, **kwargs) \
        .replace(u'<', u'\\u003c') \
        .replace(u'>', u'\\u003e') \
        .replace(u'&', u'\\u0026') \
        .replace(u"'", u'\\u0027')
    if not _slash_escape:
        rv = rv.replace('\\/', '/')
    return rv
def htmlsafe_dump(obj, fp, **kwargs):
    
    fp.write(text_type(htmlsafe_dumps(obj, **kwargs)))
def jsonify(*args, **kwargs):
    
    indent = None
    separators = (',', ':')
    if current_app.config['JSONIFY_PRETTYPRINT_REGULAR'] and not request.is_xhr:
        indent = 2
        separators = (', ', ': ')
    if args and kwargs:
        raise TypeError('jsonify() behavior undefined when passed both args and kwargs')
    elif len(args) == 1:  # single args are passed directly to dumps()
        data = args[0]
    else:
        data = args or kwargs
    return current_app.response_class(
        (dumps(data, indent=indent, separators=separators), '\n'),
        mimetype=current_app.config['JSONIFY_MIMETYPE']
    )
def tojson_filter(obj, **kwargs):
    return Markup(htmlsafe_dumps(obj, **kwargs))
from __future__ import absolute_import
import sys
from werkzeug.local import LocalProxy
from logging import getLogger, StreamHandler, Formatter, getLoggerClass, \
     DEBUG, ERROR
from .globals import _request_ctx_stack
PROD_LOG_FORMAT = '[%(asctime)s] %(levelname)s in %(module)s: %(message)s'
DEBUG_LOG_FORMAT = (
    '-' * 80 + '\n' +
    '%(levelname)s in %(module)s [%(pathname)s:%(lineno)d]:\n' +
    '%(message)s\n' +
    '-' * 80
)
@LocalProxy
def _proxy_stream():
    
    ctx = _request_ctx_stack.top
    if ctx is not None:
        return ctx.request.environ['wsgi.errors']
    return sys.stderr
def _should_log_for(app, mode):
    policy = app.config['LOGGER_HANDLER_POLICY']
    if policy == mode or policy == 'always':
        return True
    return False
def create_logger(app):
    
    Logger = getLoggerClass()
    class DebugLogger(Logger):
        def getEffectiveLevel(self):
            if self.level == 0 and app.debug:
                return DEBUG
            return Logger.getEffectiveLevel(self)
    class DebugHandler(StreamHandler):
        def emit(self, record):
            if app.debug and _should_log_for(app, 'debug'):
                StreamHandler.emit(self, record)
    class ProductionHandler(StreamHandler):
        def emit(self, record):
            if not app.debug and _should_log_for(app, 'production'):
                StreamHandler.emit(self, record)
    debug_handler = DebugHandler()
    debug_handler.setLevel(DEBUG)
    debug_handler.setFormatter(Formatter(DEBUG_LOG_FORMAT))
    prod_handler = ProductionHandler(_proxy_stream)
    prod_handler.setLevel(ERROR)
    prod_handler.setFormatter(Formatter(PROD_LOG_FORMAT))
    logger = getLogger(app.logger_name)
    del logger.handlers[:]
    logger.__class__ = DebugLogger
    logger.addHandler(debug_handler)
    logger.addHandler(prod_handler)
    return logger
import uuid
import hashlib
from base64 import b64encode, b64decode
from datetime import datetime
from werkzeug.http import http_date, parse_date
from werkzeug.datastructures import CallbackDict
from . import Markup, json
from ._compat import iteritems, text_type
from .helpers import total_seconds
from itsdangerous import URLSafeTimedSerializer, BadSignature
class SessionMixin(object):
    
    def _get_permanent(self):
        return self.get('_permanent', False)
    def _set_permanent(self, value):
        self['_permanent'] = bool(value)
    permanent = property(_get_permanent, _set_permanent)
    del _get_permanent, _set_permanent
    new = False
    modified = True
def _tag(value):
    if isinstance(value, tuple):
        return {' t': [_tag(x) for x in value]}
    elif isinstance(value, uuid.UUID):
        return {' u': value.hex}
    elif isinstance(value, bytes):
        return {' b': b64encode(value).decode('ascii')}
    elif callable(getattr(value, '__html__', None)):
        return {' m': text_type(value.__html__())}
    elif isinstance(value, list):
        return [_tag(x) for x in value]
    elif isinstance(value, datetime):
        return {' d': http_date(value)}
    elif isinstance(value, dict):
        return dict((k, _tag(v)) for k, v in iteritems(value))
    elif isinstance(value, str):
        try:
            return text_type(value)
        except UnicodeError:
            from flask.debughelpers import UnexpectedUnicodeError
            raise UnexpectedUnicodeError(u'A byte string with '
                u'non-ASCII data was passed to the session system '
                u'which can only store unicode strings.  Consider '
                u'base64 encoding your string (String was %r)' % value)
    return value
class TaggedJSONSerializer(object):
    
    def dumps(self, value):
        return json.dumps(_tag(value), separators=(',', ':'))
    def loads(self, value):
        def object_hook(obj):
            if len(obj) != 1:
                return obj
            the_key, the_value = next(iteritems(obj))
            if the_key == ' t':
                return tuple(the_value)
            elif the_key == ' u':
                return uuid.UUID(the_value)
            elif the_key == ' b':
                return b64decode(the_value)
            elif the_key == ' m':
                return Markup(the_value)
            elif the_key == ' d':
                return parse_date(the_value)
            return obj
        return json.loads(value, object_hook=object_hook)
session_json_serializer = TaggedJSONSerializer()
class SecureCookieSession(CallbackDict, SessionMixin):
    
    def __init__(self, initial=None):
        def on_update(self):
            self.modified = True
        CallbackDict.__init__(self, initial, on_update)
        self.modified = False
class NullSession(SecureCookieSession):
    
    def _fail(self, *args, **kwargs):
        raise RuntimeError('The session is unavailable because no secret '
                           'key was set.  Set the secret_key on the '
                           'application to something unique and secret.')
    __setitem__ = __delitem__ = clear = pop = popitem = \
        update = setdefault = _fail
    del _fail
class SessionInterface(object):
    
    null_session_class = NullSession
    pickle_based = False
    def make_null_session(self, app):
        
        return self.null_session_class()
    def is_null_session(self, obj):
        
        return isinstance(obj, self.null_session_class)
    def get_cookie_domain(self, app):
        
        if app.config['SESSION_COOKIE_DOMAIN'] is not None:
            return app.config['SESSION_COOKIE_DOMAIN']
        if app.config['SERVER_NAME'] is not None:
            rv = '.' + app.config['SERVER_NAME'].rsplit(':', 1)[0]
            if rv == '.localhost':
                rv = None
            if rv is not None:
                path = self.get_cookie_path(app)
                if path != '/':
                    rv = rv.lstrip('.')
            return rv
    def get_cookie_path(self, app):
        
        return app.config['SESSION_COOKIE_PATH'] or \
               app.config['APPLICATION_ROOT'] or '/'
    def get_cookie_httponly(self, app):
        
        return app.config['SESSION_COOKIE_HTTPONLY']
    def get_cookie_secure(self, app):
        
        return app.config['SESSION_COOKIE_SECURE']
    def get_expiration_time(self, app, session):
        
        if session.permanent:
            return datetime.utcnow() + app.permanent_session_lifetime
    def should_set_cookie(self, app, session):
        
        if session.modified:
            return True
        save_each = app.config['SESSION_REFRESH_EACH_REQUEST']
        return save_each and session.permanent
    def open_session(self, app, request):
        
        raise NotImplementedError()
    def save_session(self, app, session, response):
        
        raise NotImplementedError()
class SecureCookieSessionInterface(SessionInterface):
    
    salt = 'cookie-session'
    digest_method = staticmethod(hashlib.sha1)
    key_derivation = 'hmac'
    serializer = session_json_serializer
    session_class = SecureCookieSession
    def get_signing_serializer(self, app):
        if not app.secret_key:
            return None
        signer_kwargs = dict(
            key_derivation=self.key_derivation,
            digest_method=self.digest_method
        )
        return URLSafeTimedSerializer(app.secret_key, salt=self.salt,
                                      serializer=self.serializer,
                                      signer_kwargs=signer_kwargs)
    def open_session(self, app, request):
        s = self.get_signing_serializer(app)
        if s is None:
            return None
        val = request.cookies.get(app.session_cookie_name)
        if not val:
            return self.session_class()
        max_age = total_seconds(app.permanent_session_lifetime)
        try:
            data = s.loads(val, max_age=max_age)
            return self.session_class(data)
        except BadSignature:
            return self.session_class()
    def save_session(self, app, session, response):
        domain = self.get_cookie_domain(app)
        path = self.get_cookie_path(app)
        if not session:
            if session.modified:
                response.delete_cookie(app.session_cookie_name,
                                       domain=domain, path=path)
            return
        if not self.should_set_cookie(app, session):
            return
        httponly = self.get_cookie_httponly(app)
        secure = self.get_cookie_secure(app)
        expires = self.get_expiration_time(app, session)
        val = self.get_signing_serializer(app).dumps(dict(session))
        response.set_cookie(app.session_cookie_name, val,
                            expires=expires, httponly=httponly,
                            domain=domain, path=path, secure=secure)
signals_available = False
try:
    from blinker import Namespace
    signals_available = True
except ImportError:
    class Namespace(object):
        def signal(self, name, doc=None):
            return _FakeSignal(name, doc)
    class _FakeSignal(object):
        
        def __init__(self, name, doc=None):
            self.name = name
            self.__doc__ = doc
        def _fail(self, *args, **kwargs):
            raise RuntimeError('signalling support is unavailable '
                               'because the blinker library is '
                               'not installed.')
        send = lambda *a, **kw: None
        connect = disconnect = has_receivers_for = receivers_for = \
            temporarily_connected_to = connected_to = _fail
        del _fail
_signals = Namespace()
template_rendered = _signals.signal('template-rendered')
before_render_template = _signals.signal('before-render-template')
request_started = _signals.signal('request-started')
request_finished = _signals.signal('request-finished')
request_tearing_down = _signals.signal('request-tearing-down')
got_request_exception = _signals.signal('got-request-exception')
appcontext_tearing_down = _signals.signal('appcontext-tearing-down')
appcontext_pushed = _signals.signal('appcontext-pushed')
appcontext_popped = _signals.signal('appcontext-popped')
message_flashed = _signals.signal('message-flashed')
from jinja2 import BaseLoader, Environment as BaseEnvironment, \
     TemplateNotFound
from .globals import _request_ctx_stack, _app_ctx_stack
from .signals import template_rendered, before_render_template
def _default_template_ctx_processor():
    
    reqctx = _request_ctx_stack.top
    appctx = _app_ctx_stack.top
    rv = {}
    if appctx is not None:
        rv['g'] = appctx.g
    if reqctx is not None:
        rv['request'] = reqctx.request
        rv['session'] = reqctx.session
    return rv
class Environment(BaseEnvironment):
    
    def __init__(self, app, **options):
        if 'loader' not in options:
            options['loader'] = app.create_global_jinja_loader()
        BaseEnvironment.__init__(self, **options)
        self.app = app
class DispatchingJinjaLoader(BaseLoader):
    
    def __init__(self, app):
        self.app = app
    def get_source(self, environment, template):
        if self.app.config['EXPLAIN_TEMPLATE_LOADING']:
            return self._get_source_explained(environment, template)
        return self._get_source_fast(environment, template)
    def _get_source_explained(self, environment, template):
        attempts = []
        trv = None
        for srcobj, loader in self._iter_loaders(template):
            try:
                rv = loader.get_source(environment, template)
                if trv is None:
                    trv = rv
            except TemplateNotFound:
                rv = None
            attempts.append((loader, srcobj, rv))
        from .debughelpers import explain_template_loading_attempts
        explain_template_loading_attempts(self.app, template, attempts)
        if trv is not None:
            return trv
        raise TemplateNotFound(template)
    def _get_source_fast(self, environment, template):
        for srcobj, loader in self._iter_loaders(template):
            try:
                return loader.get_source(environment, template)
            except TemplateNotFound:
                continue
        raise TemplateNotFound(template)
    def _iter_loaders(self, template):
        loader = self.app.jinja_loader
        if loader is not None:
            yield self.app, loader
        for blueprint in self.app.iter_blueprints():
            loader = blueprint.jinja_loader
            if loader is not None:
                yield blueprint, loader
    def list_templates(self):
        result = set()
        loader = self.app.jinja_loader
        if loader is not None:
            result.update(loader.list_templates())
        for blueprint in self.app.iter_blueprints():
            loader = blueprint.jinja_loader
            if loader is not None:
                for template in loader.list_templates():
                    result.add(template)
        return list(result)
def _render(template, context, app):
    
    before_render_template.send(app, template=template, context=context)
    rv = template.render(context)
    template_rendered.send(app, template=template, context=context)
    return rv
def render_template(template_name_or_list, **context):
    
    ctx = _app_ctx_stack.top
    ctx.app.update_template_context(context)
    return _render(ctx.app.jinja_env.get_or_select_template(template_name_or_list),
                   context, ctx.app)
def render_template_string(source, **context):
    
    ctx = _app_ctx_stack.top
    ctx.app.update_template_context(context)
    return _render(ctx.app.jinja_env.from_string(source),
                   context, ctx.app)
from contextlib import contextmanager
from werkzeug.test import Client, EnvironBuilder
from flask import _request_ctx_stack
try:
    from werkzeug.urls import url_parse
except ImportError:
    from urlparse import urlsplit as url_parse
def make_test_environ_builder(app, path='/', base_url=None, *args, **kwargs):
    
    http_host = app.config.get('SERVER_NAME')
    app_root = app.config.get('APPLICATION_ROOT')
    if base_url is None:
        url = url_parse(path)
        base_url = 'http://%s/' % (url.netloc or http_host or 'localhost')
        if app_root:
            base_url += app_root.lstrip('/')
        if url.netloc:
            path = url.path
            if url.query:
                path += '?' + url.query
    return EnvironBuilder(path, base_url, *args, **kwargs)
class FlaskClient(Client):
    
    preserve_context = False
    @contextmanager
    def session_transaction(self, *args, **kwargs):
        
        if self.cookie_jar is None:
            raise RuntimeError('Session transactions only make sense '
                               'with cookies enabled.')
        app = self.application
        environ_overrides = kwargs.setdefault('environ_overrides', {})
        self.cookie_jar.inject_wsgi(environ_overrides)
        outer_reqctx = _request_ctx_stack.top
        with app.test_request_context(*args, **kwargs) as c:
            sess = app.open_session(c.request)
            if sess is None:
                raise RuntimeError('Session backend did not open a session. '
                                   'Check the configuration')
            _request_ctx_stack.push(outer_reqctx)
            try:
                yield sess
            finally:
                _request_ctx_stack.pop()
            resp = app.response_class()
            if not app.session_interface.is_null_session(sess):
                app.save_session(sess, resp)
            headers = resp.get_wsgi_headers(c.request.environ)
            self.cookie_jar.extract_wsgi(c.request.environ, headers)
    def open(self, *args, **kwargs):
        kwargs.setdefault('environ_overrides', {}) \
            ['flask._preserve_context'] = self.preserve_context
        as_tuple = kwargs.pop('as_tuple', False)
        buffered = kwargs.pop('buffered', False)
        follow_redirects = kwargs.pop('follow_redirects', False)
        builder = make_test_environ_builder(self.application, *args, **kwargs)
        return Client.open(self, builder,
                           as_tuple=as_tuple,
                           buffered=buffered,
                           follow_redirects=follow_redirects)
    def __enter__(self):
        if self.preserve_context:
            raise RuntimeError('Cannot nest client invocations')
        self.preserve_context = True
        return self
    def __exit__(self, exc_type, exc_value, tb):
        self.preserve_context = False
        top = _request_ctx_stack.top
        if top is not None and top.preserved:
            top.pop()
from .globals import request
from ._compat import with_metaclass
http_method_funcs = frozenset(['get', 'post', 'head', 'options',
                               'delete', 'put', 'trace', 'patch'])
class View(object):
    
    methods = None
    decorators = ()
    def dispatch_request(self):
        
        raise NotImplementedError()
    @classmethod
    def as_view(cls, name, *class_args, **class_kwargs):
        
        def view(*args, **kwargs):
            self = view.view_class(*class_args, **class_kwargs)
            return self.dispatch_request(*args, **kwargs)
        if cls.decorators:
            view.__name__ = name
            view.__module__ = cls.__module__
            for decorator in cls.decorators:
                view = decorator(view)
        view.view_class = cls
        view.__name__ = name
        view.__doc__ = cls.__doc__
        view.__module__ = cls.__module__
        view.methods = cls.methods
        return view
class MethodViewType(type):
    def __new__(cls, name, bases, d):
        rv = type.__new__(cls, name, bases, d)
        if 'methods' not in d:
            methods = set(rv.methods or [])
            for key in d:
                if key in http_method_funcs:
                    methods.add(key.upper())
            if methods:
                rv.methods = sorted(methods)
        return rv
class MethodView(with_metaclass(MethodViewType, View)):
    
    def dispatch_request(self, *args, **kwargs):
        meth = getattr(self, request.method.lower(), None)
        if meth is None and request.method == 'HEAD':
            meth = getattr(self, 'get', None)
        assert meth is not None, 'Unimplemented method %r' % request.method
        return meth(*args, **kwargs)
from werkzeug.wrappers import Request as RequestBase, Response as ResponseBase
from werkzeug.exceptions import BadRequest
from . import json
from .globals import _request_ctx_stack
_missing = object()
def _get_data(req, cache):
    getter = getattr(req, 'get_data', None)
    if getter is not None:
        return getter(cache=cache)
    return req.data
class Request(RequestBase):
    
    url_rule = None
    view_args = None
    routing_exception = None
    _is_old_module = False
    @property
    def max_content_length(self):
        
        ctx = _request_ctx_stack.top
        if ctx is not None:
            return ctx.app.config['MAX_CONTENT_LENGTH']
    @property
    def endpoint(self):
        
        if self.url_rule is not None:
            return self.url_rule.endpoint
    @property
    def module(self):
        
        from warnings import warn
        warn(DeprecationWarning('modules were deprecated in favor of '
                                'blueprints.  Use request.blueprint '
                                'instead.'), stacklevel=2)
        if self._is_old_module:
            return self.blueprint
    @property
    def blueprint(self):
        
        if self.url_rule and '.' in self.url_rule.endpoint:
            return self.url_rule.endpoint.rsplit('.', 1)[0]
    @property
    def json(self):
        
        from warnings import warn
        warn(DeprecationWarning('json is deprecated.  '
                                'Use get_json() instead.'), stacklevel=2)
        return self.get_json()
    @property
    def is_json(self):
        
        mt = self.mimetype
        if mt == 'application/json':
            return True
        if mt.startswith('application/') and mt.endswith('+json'):
            return True
        return False
    def get_json(self, force=False, silent=False, cache=True):
        
        rv = getattr(self, '_cached_json', _missing)
        if rv is not _missing:
            return rv
        if not (force or self.is_json):
            return None
        request_charset = self.mimetype_params.get('charset')
        try:
            data = _get_data(self, cache)
            if request_charset is not None:
                rv = json.loads(data, encoding=request_charset)
            else:
                rv = json.loads(data)
        except ValueError as e:
            if silent:
                rv = None
            else:
                rv = self.on_json_loading_failed(e)
        if cache:
            self._cached_json = rv
        return rv
    def on_json_loading_failed(self, e):
        
        ctx = _request_ctx_stack.top
        if ctx is not None and ctx.app.config.get('DEBUG', False):
            raise BadRequest('Failed to decode JSON object: {0}'.format(e))
        raise BadRequest()
    def _load_form_data(self):
        RequestBase._load_form_data(self)
        ctx = _request_ctx_stack.top
        if ctx is not None and ctx.app.debug and \
           self.mimetype != 'multipart/form-data' and not self.files:
            from .debughelpers import attach_enctype_error_multidict
            attach_enctype_error_multidict(self)
class Response(ResponseBase):
    
    default_mimetype = 'text/html'
def setup():
    from ..exthook import ExtensionImporter
    importer = ExtensionImporter(['flask_%s', 'flaskext.%s'], __name__)
    importer.install()
setup()
del setup
from __future__ import print_function
import re
import os
import inspect
import difflib
import posixpath
from optparse import OptionParser
try:
    import ast
except ImportError:
    ast = None
TEMPLATE_LOOKAHEAD = 4096
_app_re_part = r'((?:[a-zA-Z_][a-zA-Z0-9_]*app)|app|application)'
_string_re_part = r"('([^'\\]*(?:\\.[^'\\]*)*)'" \
                  r'|"([^"\\]*(?:\\.[^"\\]*)*)")'
_from_import_re = re.compile(r'^\s*from flask import\s+')
_url_for_re = re.compile(r'\b(url_for\()(%s)' % _string_re_part)
_render_template_re = re.compile(r'\b(render_template\()(%s)' % _string_re_part)
_after_request_re = re.compile(r'((?:@\S+\.(?:app_)?))(after_request)(\b\s*$)(?m)')
_module_constructor_re = re.compile(r'([a-zA-Z0-9_][a-zA-Z0-9_]*)\s*=\s*Module'
                                    r'\(__name__\s*(?:,\s*(?:name\s*=\s*)?(%s))?' %
                                    _string_re_part)
_error_handler_re = re.compile(r'%s\.error_handlers\[\s*(\d+)\s*\]' % _app_re_part)
_mod_route_re = re.compile(r'@([a-zA-Z0-9_][a-zA-Z0-9_]*)\.route')
_blueprint_related = [
    (re.compile(r'request\.module'), 'request.blueprint'),
    (re.compile(r'register_module'), 'register_blueprint'),
    (re.compile(r'%s\.modules' % _app_re_part), '\\1.blueprints')
]
def make_diff(filename, old, new):
    for line in difflib.unified_diff(old.splitlines(), new.splitlines(),
                     posixpath.normpath(posixpath.join('a', filename)),
                     posixpath.normpath(posixpath.join('b', filename)),
                     lineterm=''):
        print(line)
def looks_like_teardown_function(node):
    returns = [x for x in ast.walk(node) if isinstance(x, ast.Return)]
    if len(returns) != 1:
        return
    return_def = returns[0]
    resp_name = node.args.args[0]
    if not isinstance(return_def.value, ast.Name) or \
       return_def.value.id != resp_name.id:
        return
    for body_node in node.body:
        for child in ast.walk(body_node):
            if isinstance(child, ast.Name) and \
               child.id == resp_name.id:
                if child is not return_def.value:
                    return
    return resp_name.id
def fix_url_for(contents, module_declarations=None):
    if module_declarations is None:
        skip_module_test = True
    else:
        skip_module_test = False
        mapping = dict(module_declarations)
    annotated_lines = []
    def make_line_annotations():
        if not annotated_lines:
            last_index = 0
            for line in contents.splitlines(True):
                last_index += len(line)
                annotated_lines.append((last_index, line))
    def backtrack_module_name(call_start):
        make_line_annotations()
        for idx, (line_end, line) in enumerate(annotated_lines):
            if line_end > call_start:
                for _, line in reversed(annotated_lines[:idx]):
                    match = _mod_route_re.search(line)
                    if match is not None:
                        shortname = match.group(1)
                        return mapping.get(shortname)
    def handle_match(match):
        if not skip_module_test:
            modname = backtrack_module_name(match.start())
            if modname is None:
                return match.group(0)
        prefix = match.group(1)
        endpoint = ast.literal_eval(match.group(2))
        if endpoint.startswith('.'):
            endpoint = endpoint[1:]
        elif '.' not in endpoint:
            endpoint = '.' + endpoint
        else:
            return match.group(0)
        return prefix + repr(endpoint)
    return _url_for_re.sub(handle_match, contents)
def fix_teardown_funcs(contents):
    def is_return_line(line):
        args = line.strip().split()
        return args and args[0] == 'return'
    def fix_single(match, lines, lineno):
        if not lines[lineno + 1].startswith('def'):
            return
        block_lines = inspect.getblock(lines[lineno + 1:])
        func_code = ''.join(block_lines)
        if func_code[0].isspace():
            node = ast.parse('if 1:\n' + func_code).body[0].body
        else:
            node = ast.parse(func_code).body[0]
        response_param_name = looks_like_teardown_function(node)
        if response_param_name is None:
            return
        before = lines[:lineno]
        decorator = [match.group(1) +
                     match.group(2).replace('after_', 'teardown_') +
                     match.group(3)]
        body = [line.replace(response_param_name, 'exception')
                for line in block_lines if
                not is_return_line(line)]
        after = lines[lineno + len(block_lines) + 1:]
        return before + decorator + body + after
    content_lines = contents.splitlines(True)
    while 1:
        found_one = False
        for idx, line in enumerate(content_lines):
            match = _after_request_re.match(line)
            if match is None:
                continue
            new_content_lines = fix_single(match, content_lines, idx)
            if new_content_lines is not None:
                content_lines = new_content_lines
                break
        else:
            break
    return ''.join(content_lines)
def get_module_autoname(filename):
    directory, filename = os.path.split(filename)
    if filename != '__init__.py':
        return os.path.splitext(filename)[0]
    return os.path.basename(directory)
def rewrite_from_imports(prefix, fromlist, lineiter):
    import_block = [prefix, fromlist]
    if fromlist[0] == '(' and fromlist[-1] != ')':
        for line in lineiter:
            import_block.append(line)
            if line.rstrip().endswith(')'):
                break
    elif fromlist[-1] == '\\':
        for line in lineiter:
            import_block.append(line)
            if line.rstrip().endswith('\\'):
                break
    return ''.join(import_block).replace('Module', 'Blueprint')
def rewrite_blueprint_imports(contents):
    new_file = []
    lineiter = iter(contents.splitlines(True))
    for line in lineiter:
        match = _from_import_re.search(line)
        if match is not None:
            new_file.extend(rewrite_from_imports(match.group(),
                                                 line[match.end():],
                                                 lineiter))
        else:
            new_file.append(line)
    return ''.join(new_file)
def rewrite_for_blueprints(contents, filename):
    modules_declared = []
    def handle_match(match):
        target = match.group(1)
        name_param = match.group(2)
        if name_param is None:
            modname = get_module_autoname(filename)
        else:
            modname = ast.literal_eval(name_param)
        modules_declared.append((target, modname))
        return '%s = %s' % (target, 'Blueprint(%r, __name__' % modname)
    new_contents = _module_constructor_re.sub(handle_match, contents)
    if modules_declared:
        new_contents = rewrite_blueprint_imports(new_contents)
    for pattern, replacement in _blueprint_related:
        new_contents = pattern.sub(replacement, new_contents)
    return new_contents, dict(modules_declared)
def upgrade_python_file(filename, contents, teardown):
    new_contents = contents
    if teardown:
        new_contents = fix_teardown_funcs(new_contents)
    new_contents, modules = rewrite_for_blueprints(new_contents, filename)
    new_contents = fix_url_for(new_contents, modules)
    new_contents = _error_handler_re.sub('\\1.error_handler_spec[None][\\2]',
                                         new_contents)
    make_diff(filename, contents, new_contents)
def upgrade_template_file(filename, contents):
    new_contents = fix_url_for(contents, None)
    make_diff(filename, contents, new_contents)
def walk_path(path):
    this_file = os.path.realpath(__file__).rstrip('c')
    for dirpath, dirnames, filenames in os.walk(path):
        dirnames[:] = [x for x in dirnames if not x.startswith('.')]
        for filename in filenames:
            filename = os.path.join(dirpath, filename)
            if os.path.realpath(filename) == this_file:
                continue
            if filename.endswith('.py'):
                yield filename, 'python'
            elif not filename.endswith(('.diff', '.patch', '.udiff')):
                with open(filename) as f:
                    contents = f.read(TEMPLATE_LOOKAHEAD)
                if '{% for' or '{% if' or '{{ url_for' in contents:
                    yield filename, 'template'
def scan_path(path=None, teardown=True):
    for filename, type in walk_path(path):
        with open(filename) as f:
            contents = f.read()
        if type == 'python':
            upgrade_python_file(filename, contents, teardown)
        elif type == 'template':
            upgrade_template_file(filename, contents)
def main():
    
    parser = OptionParser(usage='%prog [options] [paths]')
    parser.add_option('-T', '--no-teardown-detection', dest='no_teardown',
                      action='store_true', help='Do not attempt to '
                      'detect teardown function rewrites.')
    parser.add_option('-b', '--bundled-templates', dest='bundled_tmpl',
                      action='store_true', help='Indicate to the system '
                      'that templates are bundled with modules.  Default '
                      'is auto detect.')
    options, args = parser.parse_args()
    if not args:
        args = ['.']
    if ast is None:
        parser.error('Python 2.6 or later is required to run the upgrade script.')
    for path in args:
        scan_path(path, teardown=not options.no_teardown)
if __name__ == '__main__':
    main()
import types
import sys
import os
class ExtensionImporter(object):
    
    def __init__(self, module_choices, wrapper_module):
        self.module_choices = module_choices
        self.wrapper_module = wrapper_module
        self.prefix = wrapper_module + '.'
        self.prefix_cutoff = wrapper_module.count('.') + 1
    def __eq__(self, other):
        return self.__class__.__module__ == other.__class__.__module__ and \
               self.__class__.__name__ == other.__class__.__name__ and \
               self.wrapper_module == other.wrapper_module and \
               self.module_choices == other.module_choices
    def __ne__(self, other):
        return not self.__eq__(other)
    def install(self):
        sys.meta_path[:] = [x for x in sys.meta_path if self != x] + [self]
    def find_module(self, fullname, path=None):
        if fullname.startswith(self.prefix):
            return self
    def load_module(self, fullname):
        if fullname in sys.modules:
            return sys.modules[fullname]
        modname = fullname.split('.', self.prefix_cutoff)[self.prefix_cutoff]
        for path in self.module_choices:
            realname = path % modname
            try:
                __import__(realname)
            except ImportError:
                exc_type, exc_value, tb = sys.exc_info()
                sys.modules.pop(fullname, None)
                if self.is_important_traceback(realname, tb):
                    raise exc_type, exc_value, tb.tb_next
                continue
            module = sys.modules[fullname] = sys.modules[realname]
            if '.' not in modname:
                setattr(sys.modules[self.wrapper_module], modname, module)
            return module
        raise ImportError('No module named %s' % fullname)
    def is_important_traceback(self, important_module, tb):
        
        while tb is not None:
            if self.is_important_frame(important_module, tb):
                return True
            tb = tb.tb_next
        return False
    def is_important_frame(self, important_module, tb):
        
        g = tb.tb_frame.f_globals
        if '__name__' not in g:
            return False
        module_name = g['__name__']
        if module_name == important_module:
            return True
        filename = os.path.abspath(tb.tb_frame.f_code.co_filename)
        test_string = os.path.sep + important_module.replace('.', os.path.sep)
        return test_string + '.py' in filename or \
               test_string + os.path.sep + '__init__.py' in filename
def activate():
    import flask
    ext_module = types.ModuleType('flask.ext')
    ext_module.__path__ = []
    flask.ext = sys.modules['flask.ext'] = ext_module
    importer = ExtensionImporter(['flask_%s', 'flaskext.%s'], 'flask.ext')
    importer.install()
import os
import sys
import shutil
import urllib2
import tempfile
import subprocess
import argparse
from flask import json
from setuptools.package_index import PackageIndex
from setuptools.archive_util import unpack_archive
flask_svc_url = 'http://flask.pocoo.org/extensions/'
if sys.platform == 'darwin':
    _tempdir = '/private/tmp'
else:
    _tempdir = tempfile.gettempdir()
tdir = _tempdir + '/flaskext-test'
flaskdir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
os.environ['PYTHONDONTWRITEBYTECODE'] = ''
RESULT_TEMPATE = u'''\
<!doctype html>
<title>Flask-Extension Test Results</title>
<style type=text/css>
  body         { font-family: 'Georgia', serif; font-size: 17px; color: #000; }
  a            { color: #004B6B; }
  a:hover      { color: #6D4100; }
  h1, h2, h3   { font-family: 'Garamond', 'Georgia', serif; font-weight: normal; }
  h1           { font-size: 30px; margin: 15px 0 5px 0; }
  h2           { font-size: 24px; margin: 15px 0 5px 0; }
  h3           { font-size: 19px; margin: 15px 0 5px 0; }
  textarea, code,
  pre          { font-family: 'Consolas', 'Menlo', 'Deja Vu Sans Mono',
                 'Bitstream Vera Sans Mono', monospace!important; font-size: 15px;
                 background: #eee; }
  pre          { padding: 7px 15px; line-height: 1.3; }
  p            { line-height: 1.4; }
  table        { border: 1px solid black; border-collapse: collapse;
                 margin: 15px 0; }
  td, th       { border: 1px solid black; padding: 4px 10px;
                 text-align: left; }
  th           { background: #eee; font-weight: normal; }
  tr.success   { background: #D3F5CC; }
  tr.failed    { background: #F5D2CB; }
</style>
<h1>Flask-Extension Test Results</h1>
<p>
  This page contains the detailed test results for the test run of
  all {{ 'approved' if approved }} Flask extensions.
<h2>Summary</h2>
<table class=results>
  <thead>
    <tr>
      <th>Extension
      <th>Version
      <th>Author
      <th>License
      <th>Outcome
      {%- for iptr, _ in results[0].logs|dictsort %}
        <th>{{ iptr }}
      {%- endfor %}
    </tr>
  </thead>
  <tbody>
  {%- for result in results %}
    {% set outcome = 'success' if result.success else 'failed' %}
    <tr class={{ outcome }}>
      <th>{{ result.name }}
      <td>{{ result.version }}
      <td>{{ result.author }}
      <td>{{ result.license }}
      <td>{{ outcome }}
      {%- for iptr, _ in result.logs|dictsort %}
        <td><a href="#{{ result.name }}-{{ iptr }}">see log</a>
      {%- endfor %}
    </tr>
  {%- endfor %}
  </tbody>
</table>
<h2>Test Logs</h2>
<p>Detailed test logs for all tests on all platforms:
{%- for result in results %}
  {%- for iptr, log in result.logs|dictsort %}
    <h3 id="{{ result.name }}-{{ iptr }}">
      {{ result.name }} - {{ result.version }} [{{ iptr }}]</h3>
    <pre>{{ log }}</pre>
  {%- endfor %}
{%- endfor %}
'''
def log(msg, *args):
    print('[EXTTEST] ' + (msg % args))
class TestResult(object):
    def __init__(self, name, folder, statuscode, interpreters):
        intrptr = os.path.join(folder, '.tox/%s/bin/python'
                               % interpreters[0])
        self.statuscode = statuscode
        self.folder = folder
        self.success = statuscode == 0
        def fetch(field):
            try:
                c = subprocess.Popen([intrptr, 'setup.py',
                                      '--' + field], cwd=folder,
                                      stdout=subprocess.PIPE)
                return c.communicate()[0].strip()
            except OSError:
                return '?'
        self.name = name
        self.license = fetch('license')
        self.author = fetch('author')
        self.version = fetch('version')
        self.logs = {}
        for interpreter in interpreters:
            logfile = os.path.join(folder, '.tox/%s/log/test.log'
                                   % interpreter)
            if os.path.isfile(logfile):
                self.logs[interpreter] = open(logfile).read()
            else:
                self.logs[interpreter] = ''
def create_tdir():
    try:
        shutil.rmtree(tdir)
    except Exception:
        pass
    os.mkdir(tdir)
def package_flask():
    distfolder = tdir + '/.flask-dist'
    c = subprocess.Popen(['python', 'setup.py', 'sdist', '--formats=gztar',
                          '--dist', distfolder], cwd=flaskdir)
    c.wait()
    return os.path.join(distfolder, os.listdir(distfolder)[0])
def get_test_command(checkout_dir):
    if os.path.isfile(checkout_dir + '/Makefile'):
        return 'make test'
    return 'python setup.py test'
def fetch_extensions_list():
    req = urllib2.Request(flask_svc_url, headers={'accept':'application/json'})
    d = urllib2.urlopen(req).read()
    data = json.loads(d)
    for ext in data['extensions']:
        yield ext
def checkout_extension(name):
    log('Downloading extension %s to temporary folder', name)
    root = os.path.join(tdir, name)
    os.mkdir(root)
    checkout_path = PackageIndex().download(name, root)
    unpack_archive(checkout_path, root)
    path = None
    for fn in os.listdir(root):
        path = os.path.join(root, fn)
        if os.path.isdir(path):
            break
    log('Downloaded to %s', path)
    return path
tox_template = 
def create_tox_ini(checkout_path, interpreters, flask_dep):
    tox_path = os.path.join(checkout_path, 'tox-flask-test.ini')
    if not os.path.exists(tox_path):
        with open(tox_path, 'w') as f:
            f.write(tox_template % {
                'env':      ','.join(interpreters),
                'cache':    tdir,
                'deps':     flask_dep
            })
    return tox_path
def iter_extensions(only_approved=True):
    for ext in fetch_extensions_list():
        if ext['approved'] or not only_approved:
            yield ext['name']
def test_extension(name, interpreters, flask_dep):
    checkout_path = checkout_extension(name)
    log('Running tests with tox in %s', checkout_path)
    test_command = get_test_command(checkout_path)
    log('Test command: %s', test_command)
    f = open(checkout_path + '/flaskext-runtest.sh', 'w')
    f.write(test_command + ' &> "$1" < /dev/null\n')
    f.close()
    create_tox_ini(checkout_path, interpreters, flask_dep)
    rv = subprocess.call(['tox', '-c', 'tox-flask-test.ini'], cwd=checkout_path)
    return TestResult(name, checkout_path, rv, interpreters)
def run_tests(extensions, interpreters):
    results = {}
    create_tdir()
    log('Packaging Flask')
    flask_dep = package_flask()
    log('Running extension tests')
    log('Temporary Environment: %s', tdir)
    for name in extensions:
        log('Testing %s', name)
        result = test_extension(name, interpreters, flask_dep)
        if result.success:
            log('Extension test succeeded')
        else:
            log('Extension test failed')
        results[name] = result
    return results
def render_results(results, approved):
    from jinja2 import Template
    items = results.values()
    items.sort(key=lambda x: x.name.lower())
    rv = Template(RESULT_TEMPATE, autoescape=True).render(results=items,
                                                          approved=approved)
    fd, filename = tempfile.mkstemp(suffix='.html')
    os.fdopen(fd, 'w').write(rv.encode('utf-8') + '\n')
    return filename
def main():
    parser = argparse.ArgumentParser(description='Runs Flask extension tests')
    parser.add_argument('--all', dest='all', action='store_true',
                        help='run against all extensions, not just approved')
    parser.add_argument('--browse', dest='browse', action='store_true',
                        help='show browser with the result summary')
    parser.add_argument('--env', dest='env', default='py25,py26,py27',
                        help='the tox environments to run against')
    parser.add_argument('--extension=', dest='extension', default=None,
                        help='tests a single extension')
    args = parser.parse_args()
    if args.extension is not None:
        only_approved = False
        extensions = [args.extension]
    else:
        only_approved = not args.all
        extensions = iter_extensions(only_approved)
    results = run_tests(extensions, [x.strip() for x in args.env.split(',')])
    filename = render_results(results, only_approved)
    if args.browse:
        import webbrowser
        webbrowser.open('file:///' + filename.lstrip('/'))
    print('Results written to {}'.format(filename))
if __name__ == '__main__':
    main()
from __future__ import print_function
import sys
import os
import re
from datetime import datetime, date
from subprocess import Popen, PIPE
_date_clean_re = re.compile(r'(\d+)(st|nd|rd|th)')
def parse_changelog():
    with open('CHANGES') as f:
        lineiter = iter(f)
        for line in lineiter:
            match = re.search('^Version\s+(.*)', line.strip())
            if match is None:
                continue
            version = match.group(1).strip()
            if lineiter.next().count('-') != len(match.group(0)):
                continue
            while 1:
                change_info = lineiter.next().strip()
                if change_info:
                    break
            match = re.search(r'released on (\w+\s+\d+\w+\s+\d+)'
                              r'(?:, codename (.*))?(?i)', change_info)
            if match is None:
                continue
            datestr, codename = match.groups()
            return version, parse_date(datestr), codename
def bump_version(version):
    try:
        parts = map(int, version.split('.'))
    except ValueError:
        fail('Current version is not numeric')
    parts[-1] += 1
    return '.'.join(map(str, parts))
def parse_date(string):
    string = _date_clean_re.sub(r'\1', string)
    return datetime.strptime(string, '%B %d %Y')
def set_filename_version(filename, version_number, pattern):
    changed = []
    def inject_version(match):
        before, old, after = match.groups()
        changed.append(True)
        return before + version_number + after
    with open(filename) as f:
        contents = re.sub(r"^(\s*%s\s*=\s*')(.+?)(')(?sm)" % pattern,
                          inject_version, f.read())
    if not changed:
        fail('Could not find %s in %s', pattern, filename)
    with open(filename, 'w') as f:
        f.write(contents)
def set_init_version(version):
    info('Setting __init__.py version to %s', version)
    set_filename_version('flask/__init__.py', version, '__version__')
def build_and_upload():
    Popen([sys.executable, 'setup.py', 'release', 'sdist', 'bdist_wheel', 'upload']).wait()
def fail(message, *args):
    print('Error:', message % args, file=sys.stderr)
    sys.exit(1)
def info(message, *args):
    print(message % args, file=sys.stderr)
def get_git_tags():
    return set(Popen(['git', 'tag'], stdout=PIPE).communicate()[0].splitlines())
def git_is_clean():
    return Popen(['git', 'diff', '--quiet']).wait() == 0
def make_git_commit(message, *args):
    message = message % args
    Popen(['git', 'commit', '-am', message]).wait()
def make_git_tag(tag):
    info('Tagging "%s"', tag)
    Popen(['git', 'tag', tag]).wait()
def main():
    os.chdir(os.path.join(os.path.dirname(__file__), '..'))
    rv = parse_changelog()
    if rv is None:
        fail('Could not parse changelog')
    version, release_date, codename = rv
    dev_version = bump_version(version) + '-dev'
    info('Releasing %s (codename %s, release date %s)',
         version, codename, release_date.strftime('%d/%m/%Y'))
    tags = get_git_tags()
    if version in tags:
        fail('Version "%s" is already tagged', version)
    if release_date.date() != date.today():
        fail('Release date is not today (%s != %s)',
             release_date.date(), date.today())
    if not git_is_clean():
        fail('You have uncommitted changes in git')
    set_init_version(version)
    make_git_commit('Bump version number to %s', version)
    make_git_tag(version)
    build_and_upload()
    set_init_version(dev_version)
if __name__ == '__main__':
    main()
import flask
import gc
import os
import sys
import pkgutil
import pytest
import textwrap
@pytest.fixture
def test_apps(monkeypatch):
    monkeypatch.syspath_prepend(
        os.path.abspath(os.path.join(
            os.path.dirname(__file__), 'test_apps'))
    )
@pytest.fixture(autouse=True)
def leak_detector(request):
    def ensure_clean_request_context():
        leaks = []
        while flask._request_ctx_stack.top is not None:
            leaks.append(flask._request_ctx_stack.pop())
        assert leaks == []
    request.addfinalizer(ensure_clean_request_context)
@pytest.fixture(params=(True, False))
def limit_loader(request, monkeypatch):
    
    if not request.param:
        return
    class LimitedLoader(object):
        def __init__(self, loader):
            self.loader = loader
        def __getattr__(self, name):
            if name in ('archive', 'get_filename'):
                msg = 'Mocking a loader which does not have `%s.`' % name
                raise AttributeError(msg)
            return getattr(self.loader, name)
    old_get_loader = pkgutil.get_loader
    def get_loader(*args, **kwargs):
        return LimitedLoader(old_get_loader(*args, **kwargs))
    monkeypatch.setattr(pkgutil, 'get_loader', get_loader)
@pytest.fixture
def modules_tmpdir(tmpdir, monkeypatch):
    '''A tmpdir added to sys.path'''
    rv = tmpdir.mkdir('modules_tmpdir')
    monkeypatch.syspath_prepend(str(rv))
    return rv
@pytest.fixture
def modules_tmpdir_prefix(modules_tmpdir, monkeypatch):
    monkeypatch.setattr(sys, 'prefix', str(modules_tmpdir))
    return modules_tmpdir
@pytest.fixture
def site_packages(modules_tmpdir, monkeypatch):
    '''Create a fake site-packages'''
    rv = modules_tmpdir \
        .mkdir('lib')\
        .mkdir('python{x[0]}.{x[1]}'.format(x=sys.version_info))\
        .mkdir('site-packages')
    monkeypatch.syspath_prepend(str(rv))
    return rv
@pytest.fixture
def install_egg(modules_tmpdir, monkeypatch):
    '''Generate egg from package name inside base and put the egg into
    sys.path'''
    def inner(name, base=modules_tmpdir):
        if not isinstance(name, str):
            raise ValueError(name)
        base.join(name).ensure_dir()
        base.join(name).join('__init__.py').ensure()
        egg_setup = base.join('setup.py')
        egg_setup.write(textwrap.dedent(.format(name)))
        import subprocess
        subprocess.check_call(
            [sys.executable, 'setup.py', 'bdist_egg'],
            cwd=str(modules_tmpdir)
        )
        egg_path, = modules_tmpdir.join('dist/').listdir()
        monkeypatch.syspath_prepend(str(egg_path))
        return egg_path
    return inner
@pytest.fixture
def purge_module(request):
    def inner(name):
        request.addfinalizer(lambda: sys.modules.pop(name, None))
    return inner
@pytest.yield_fixture(autouse=True)
def catch_deprecation_warnings(recwarn):
    yield
    gc.collect()
    assert not recwarn.list
import pytest
import flask
def test_basic_url_generation():
    app = flask.Flask(__name__)
    app.config['SERVER_NAME'] = 'localhost'
    app.config['PREFERRED_URL_SCHEME'] = 'https'
    @app.route('/')
    def index():
        pass
    with app.app_context():
        rv = flask.url_for('index')
        assert rv == 'https://localhost/'
def test_url_generation_requires_server_name():
    app = flask.Flask(__name__)
    with app.app_context():
        with pytest.raises(RuntimeError):
            flask.url_for('index')
def test_url_generation_without_context_fails():
    with pytest.raises(RuntimeError):
        flask.url_for('index')
def test_request_context_means_app_context():
    app = flask.Flask(__name__)
    with app.test_request_context():
        assert flask.current_app._get_current_object() == app
    assert flask._app_ctx_stack.top is None
def test_app_context_provides_current_app():
    app = flask.Flask(__name__)
    with app.app_context():
        assert flask.current_app._get_current_object() == app
    assert flask._app_ctx_stack.top is None
def test_app_tearing_down():
    cleanup_stuff = []
    app = flask.Flask(__name__)
    @app.teardown_appcontext
    def cleanup(exception):
        cleanup_stuff.append(exception)
    with app.app_context():
        pass
    assert cleanup_stuff == [None]
def test_app_tearing_down_with_previous_exception():
    cleanup_stuff = []
    app = flask.Flask(__name__)
    @app.teardown_appcontext
    def cleanup(exception):
        cleanup_stuff.append(exception)
    try:
        raise Exception('dummy')
    except Exception:
        pass
    with app.app_context():
        pass
    assert cleanup_stuff == [None]
def test_app_tearing_down_with_handled_exception():
    cleanup_stuff = []
    app = flask.Flask(__name__)
    @app.teardown_appcontext
    def cleanup(exception):
        cleanup_stuff.append(exception)
    with app.app_context():
        try:
            raise Exception('dummy')
        except Exception:
            pass
    assert cleanup_stuff == [None]
def test_app_ctx_globals_methods():
    app = flask.Flask(__name__)
    with app.app_context():
        assert flask.g.get('foo') is None
        assert flask.g.get('foo', 'bar') == 'bar'
        assert 'foo' not in flask.g
        flask.g.foo = 'bar'
        assert 'foo' in flask.g
        flask.g.setdefault('bar', 'the cake is a lie')
        flask.g.setdefault('bar', 'hello world')
        assert flask.g.bar == 'the cake is a lie'
        assert flask.g.pop('bar') == 'the cake is a lie'
        with pytest.raises(KeyError):
            flask.g.pop('bar')
        assert flask.g.pop('bar', 'more cake') == 'more cake'
        assert list(flask.g) == ['foo']
def test_custom_app_ctx_globals_class():
    class CustomRequestGlobals(object):
        def __init__(self):
            self.spam = 'eggs'
    app = flask.Flask(__name__)
    app.app_ctx_globals_class = CustomRequestGlobals
    with app.app_context():
        assert flask.render_template_string('{{ g.spam }}') == 'eggs'
def test_context_refcounts():
    called = []
    app = flask.Flask(__name__)
    @app.teardown_request
    def teardown_req(error=None):
        called.append('request')
    @app.teardown_appcontext
    def teardown_app(error=None):
        called.append('app')
    @app.route('/')
    def index():
        with flask._app_ctx_stack.top:
            with flask._request_ctx_stack.top:
                pass
        env = flask._request_ctx_stack.top.request.environ
        assert env['werkzeug.request'] is not None
        return u''
    c = app.test_client()
    res = c.get('/')
    assert res.status_code == 200
    assert res.data == b''
    assert called == ['request', 'app']
def test_clean_pop():
    called = []
    app = flask.Flask(__name__)
    @app.teardown_request
    def teardown_req(error=None):
        1 / 0
    @app.teardown_appcontext
    def teardown_app(error=None):
        called.append('TEARDOWN')
    try:
        with app.test_request_context():
            called.append(flask.current_app.name)
    except ZeroDivisionError:
        pass
    assert called == ['test_appctx', 'TEARDOWN']
    assert not flask.current_app
import pytest
import re
import uuid
import time
import flask
import pickle
from datetime import datetime
from threading import Thread
from flask._compat import text_type
from werkzeug.exceptions import BadRequest, NotFound, Forbidden
from werkzeug.http import parse_date
from werkzeug.routing import BuildError
import werkzeug.serving
def test_options_work():
    app = flask.Flask(__name__)
    @app.route('/', methods=['GET', 'POST'])
    def index():
        return 'Hello World'
    rv = app.test_client().open('/', method='OPTIONS')
    assert sorted(rv.allow) == ['GET', 'HEAD', 'OPTIONS', 'POST']
    assert rv.data == b''
def test_options_on_multiple_rules():
    app = flask.Flask(__name__)
    @app.route('/', methods=['GET', 'POST'])
    def index():
        return 'Hello World'
    @app.route('/', methods=['PUT'])
    def index_put():
        return 'Aha!'
    rv = app.test_client().open('/', method='OPTIONS')
    assert sorted(rv.allow) == ['GET', 'HEAD', 'OPTIONS', 'POST', 'PUT']
def test_options_handling_disabled():
    app = flask.Flask(__name__)
    def index():
        return 'Hello World!'
    index.provide_automatic_options = False
    app.route('/')(index)
    rv = app.test_client().open('/', method='OPTIONS')
    assert rv.status_code == 405
    app = flask.Flask(__name__)
    def index2():
        return 'Hello World!'
    index2.provide_automatic_options = True
    app.route('/', methods=['OPTIONS'])(index2)
    rv = app.test_client().open('/', method='OPTIONS')
    assert sorted(rv.allow) == ['OPTIONS']
def test_request_dispatching():
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return flask.request.method
    @app.route('/more', methods=['GET', 'POST'])
    def more():
        return flask.request.method
    c = app.test_client()
    assert c.get('/').data == b'GET'
    rv = c.post('/')
    assert rv.status_code == 405
    assert sorted(rv.allow) == ['GET', 'HEAD', 'OPTIONS']
    rv = c.head('/')
    assert rv.status_code == 200
    assert not rv.data  # head truncates
    assert c.post('/more').data == b'POST'
    assert c.get('/more').data == b'GET'
    rv = c.delete('/more')
    assert rv.status_code == 405
    assert sorted(rv.allow) == ['GET', 'HEAD', 'OPTIONS', 'POST']
def test_disallow_string_for_allowed_methods():
    app = flask.Flask(__name__)
    with pytest.raises(TypeError):
        @app.route('/', methods='GET POST')
        def index():
            return "Hey"
def test_url_mapping():
    app = flask.Flask(__name__)
    random_uuid4 = "7eb41166-9ebf-4d26-b771-ea3f54f8b383"
    def index():
        return flask.request.method
    def more():
        return flask.request.method
    def options():
        return random_uuid4
    app.add_url_rule('/', 'index', index)
    app.add_url_rule('/more', 'more', more, methods=['GET', 'POST'])
    app.add_url_rule('/options', 'options', options, methods=['options'])
    c = app.test_client()
    assert c.get('/').data == b'GET'
    rv = c.post('/')
    assert rv.status_code == 405
    assert sorted(rv.allow) == ['GET', 'HEAD', 'OPTIONS']
    rv = c.head('/')
    assert rv.status_code == 200
    assert not rv.data  # head truncates
    assert c.post('/more').data == b'POST'
    assert c.get('/more').data == b'GET'
    rv = c.delete('/more')
    assert rv.status_code == 405
    assert sorted(rv.allow) == ['GET', 'HEAD', 'OPTIONS', 'POST']
    rv = c.open('/options', method='OPTIONS')
    assert rv.status_code == 200
    assert random_uuid4 in rv.data.decode("utf-8")
def test_werkzeug_routing():
    from werkzeug.routing import Submount, Rule
    app = flask.Flask(__name__)
    app.url_map.add(Submount('/foo', [
        Rule('/bar', endpoint='bar'),
        Rule('/', endpoint='index')
    ]))
    def bar():
        return 'bar'
    def index():
        return 'index'
    app.view_functions['bar'] = bar
    app.view_functions['index'] = index
    c = app.test_client()
    assert c.get('/foo/').data == b'index'
    assert c.get('/foo/bar').data == b'bar'
def test_endpoint_decorator():
    from werkzeug.routing import Submount, Rule
    app = flask.Flask(__name__)
    app.url_map.add(Submount('/foo', [
        Rule('/bar', endpoint='bar'),
        Rule('/', endpoint='index')
    ]))
    @app.endpoint('bar')
    def bar():
        return 'bar'
    @app.endpoint('index')
    def index():
        return 'index'
    c = app.test_client()
    assert c.get('/foo/').data == b'index'
    assert c.get('/foo/bar').data == b'bar'
def test_session():
    app = flask.Flask(__name__)
    app.secret_key = 'testkey'
    @app.route('/set', methods=['POST'])
    def set():
        flask.session['value'] = flask.request.form['value']
        return 'value set'
    @app.route('/get')
    def get():
        return flask.session['value']
    c = app.test_client()
    assert c.post('/set', data={'value': '42'}).data == b'value set'
    assert c.get('/get').data == b'42'
def test_session_using_server_name():
    app = flask.Flask(__name__)
    app.config.update(
        SECRET_KEY='foo',
        SERVER_NAME='example.com'
    )
    @app.route('/')
    def index():
        flask.session['testing'] = 42
        return 'Hello World'
    rv = app.test_client().get('/', 'http://example.com/')
    assert 'domain=.example.com' in rv.headers['set-cookie'].lower()
    assert 'httponly' in rv.headers['set-cookie'].lower()
def test_session_using_server_name_and_port():
    app = flask.Flask(__name__)
    app.config.update(
        SECRET_KEY='foo',
        SERVER_NAME='example.com:8080'
    )
    @app.route('/')
    def index():
        flask.session['testing'] = 42
        return 'Hello World'
    rv = app.test_client().get('/', 'http://example.com:8080/')
    assert 'domain=.example.com' in rv.headers['set-cookie'].lower()
    assert 'httponly' in rv.headers['set-cookie'].lower()
def test_session_using_server_name_port_and_path():
    app = flask.Flask(__name__)
    app.config.update(
        SECRET_KEY='foo',
        SERVER_NAME='example.com:8080',
        APPLICATION_ROOT='/foo'
    )
    @app.route('/')
    def index():
        flask.session['testing'] = 42
        return 'Hello World'
    rv = app.test_client().get('/', 'http://example.com:8080/foo')
    assert 'domain=example.com' in rv.headers['set-cookie'].lower()
    assert 'path=/foo' in rv.headers['set-cookie'].lower()
    assert 'httponly' in rv.headers['set-cookie'].lower()
def test_session_using_application_root():
    class PrefixPathMiddleware(object):
        def __init__(self, app, prefix):
            self.app = app
            self.prefix = prefix
        def __call__(self, environ, start_response):
            environ['SCRIPT_NAME'] = self.prefix
            return self.app(environ, start_response)
    app = flask.Flask(__name__)
    app.wsgi_app = PrefixPathMiddleware(app.wsgi_app, '/bar')
    app.config.update(
        SECRET_KEY='foo',
        APPLICATION_ROOT='/bar'
    )
    @app.route('/')
    def index():
        flask.session['testing'] = 42
        return 'Hello World'
    rv = app.test_client().get('/', 'http://example.com:8080/')
    assert 'path=/bar' in rv.headers['set-cookie'].lower()
def test_session_using_session_settings():
    app = flask.Flask(__name__)
    app.config.update(
        SECRET_KEY='foo',
        SERVER_NAME='www.example.com:8080',
        APPLICATION_ROOT='/test',
        SESSION_COOKIE_DOMAIN='.example.com',
        SESSION_COOKIE_HTTPONLY=False,
        SESSION_COOKIE_SECURE=True,
        SESSION_COOKIE_PATH='/'
    )
    @app.route('/')
    def index():
        flask.session['testing'] = 42
        return 'Hello World'
    rv = app.test_client().get('/', 'http://www.example.com:8080/test/')
    cookie = rv.headers['set-cookie'].lower()
    assert 'domain=.example.com' in cookie
    assert 'path=/' in cookie
    assert 'secure' in cookie
    assert 'httponly' not in cookie
def test_missing_session():
    app = flask.Flask(__name__)
    def expect_exception(f, *args, **kwargs):
        e = pytest.raises(RuntimeError, f, *args, **kwargs)
        assert e.value.args and 'session is unavailable' in e.value.args[0]
    with app.test_request_context():
        assert flask.session.get('missing_key') is None
        expect_exception(flask.session.__setitem__, 'foo', 42)
        expect_exception(flask.session.pop, 'foo')
def test_session_expiration():
    permanent = True
    app = flask.Flask(__name__)
    app.secret_key = 'testkey'
    @app.route('/')
    def index():
        flask.session['test'] = 42
        flask.session.permanent = permanent
        return ''
    @app.route('/test')
    def test():
        return text_type(flask.session.permanent)
    client = app.test_client()
    rv = client.get('/')
    assert 'set-cookie' in rv.headers
    match = re.search(r'\bexpires=([^;]+)(?i)', rv.headers['set-cookie'])
    expires = parse_date(match.group())
    expected = datetime.utcnow() + app.permanent_session_lifetime
    assert expires.year == expected.year
    assert expires.month == expected.month
    assert expires.day == expected.day
    rv = client.get('/test')
    assert rv.data == b'True'
    permanent = False
    rv = app.test_client().get('/')
    assert 'set-cookie' in rv.headers
    match = re.search(r'\bexpires=([^;]+)', rv.headers['set-cookie'])
    assert match is None
def test_session_stored_last():
    app = flask.Flask(__name__)
    app.secret_key = 'development-key'
    app.testing = True
    @app.after_request
    def modify_session(response):
        flask.session['foo'] = 42
        return response
    @app.route('/')
    def dump_session_contents():
        return repr(flask.session.get('foo'))
    c = app.test_client()
    assert c.get('/').data == b'None'
    assert c.get('/').data == b'42'
def test_session_special_types():
    app = flask.Flask(__name__)
    app.secret_key = 'development-key'
    app.testing = True
    now = datetime.utcnow().replace(microsecond=0)
    the_uuid = uuid.uuid4()
    @app.after_request
    def modify_session(response):
        flask.session['m'] = flask.Markup('Hello!')
        flask.session['u'] = the_uuid
        flask.session['dt'] = now
        flask.session['b'] = b'\xff'
        flask.session['t'] = (1, 2, 3)
        return response
    @app.route('/')
    def dump_session_contents():
        return pickle.dumps(dict(flask.session))
    c = app.test_client()
    c.get('/')
    rv = pickle.loads(c.get('/').data)
    assert rv['m'] == flask.Markup('Hello!')
    assert type(rv['m']) == flask.Markup
    assert rv['dt'] == now
    assert rv['u'] == the_uuid
    assert rv['b'] == b'\xff'
    assert type(rv['b']) == bytes
    assert rv['t'] == (1, 2, 3)
def test_session_cookie_setting():
    app = flask.Flask(__name__)
    app.testing = True
    app.secret_key = 'dev key'
    is_permanent = True
    @app.route('/bump')
    def bump():
        rv = flask.session['foo'] = flask.session.get('foo', 0) + 1
        flask.session.permanent = is_permanent
        return str(rv)
    @app.route('/read')
    def read():
        return str(flask.session.get('foo', 0))
    def run_test(expect_header):
        with app.test_client() as c:
            assert c.get('/bump').data == b'1'
            assert c.get('/bump').data == b'2'
            assert c.get('/bump').data == b'3'
            rv = c.get('/read')
            set_cookie = rv.headers.get('set-cookie')
            assert (set_cookie is not None) == expect_header
            assert rv.data == b'3'
    is_permanent = True
    app.config['SESSION_REFRESH_EACH_REQUEST'] = True
    run_test(expect_header=True)
    is_permanent = True
    app.config['SESSION_REFRESH_EACH_REQUEST'] = False
    run_test(expect_header=False)
    is_permanent = False
    app.config['SESSION_REFRESH_EACH_REQUEST'] = True
    run_test(expect_header=False)
    is_permanent = False
    app.config['SESSION_REFRESH_EACH_REQUEST'] = False
    run_test(expect_header=False)
def test_flashes():
    app = flask.Flask(__name__)
    app.secret_key = 'testkey'
    with app.test_request_context():
        assert not flask.session.modified
        flask.flash('Zap')
        flask.session.modified = False
        flask.flash('Zip')
        assert flask.session.modified
        assert list(flask.get_flashed_messages()) == ['Zap', 'Zip']
def test_extended_flashing():
    app = flask.Flask(__name__)
    app.secret_key = 'testkey'
    app.testing = True
    @app.route('/')
    def index():
        flask.flash(u'Hello World')
        flask.flash(u'Hello World', 'error')
        flask.flash(flask.Markup(u'<em>Testing</em>'), 'warning')
        return ''
    @app.route('/test/')
    def test():
        messages = flask.get_flashed_messages()
        assert list(messages) == [
            u'Hello World',
            u'Hello World',
            flask.Markup(u'<em>Testing</em>')
        ]
        return ''
    @app.route('/test_with_categories/')
    def test_with_categories():
        messages = flask.get_flashed_messages(with_categories=True)
        assert len(messages) == 3
        assert list(messages) == [
            ('message', u'Hello World'),
            ('error', u'Hello World'),
            ('warning', flask.Markup(u'<em>Testing</em>'))
        ]
        return ''
    @app.route('/test_filter/')
    def test_filter():
        messages = flask.get_flashed_messages(
            category_filter=['message'], with_categories=True)
        assert list(messages) == [('message', u'Hello World')]
        return ''
    @app.route('/test_filters/')
    def test_filters():
        messages = flask.get_flashed_messages(
            category_filter=['message', 'warning'], with_categories=True)
        assert list(messages) == [
            ('message', u'Hello World'),
            ('warning', flask.Markup(u'<em>Testing</em>'))
        ]
        return ''
    @app.route('/test_filters_without_returning_categories/')
    def test_filters2():
        messages = flask.get_flashed_messages(
            category_filter=['message', 'warning'])
        assert len(messages) == 2
        assert messages[0] == u'Hello World'
        assert messages[1] == flask.Markup(u'<em>Testing</em>')
        return ''
    c = app.test_client()
    c.get('/')
    c.get('/test/')
    c = app.test_client()
    c.get('/')
    c.get('/test_with_categories/')
    c = app.test_client()
    c.get('/')
    c.get('/test_filter/')
    c = app.test_client()
    c.get('/')
    c.get('/test_filters/')
    c = app.test_client()
    c.get('/')
    c.get('/test_filters_without_returning_categories/')
def test_request_processing():
    app = flask.Flask(__name__)
    evts = []
    @app.before_request
    def before_request():
        evts.append('before')
    @app.after_request
    def after_request(response):
        response.data += b'|after'
        evts.append('after')
        return response
    @app.route('/')
    def index():
        assert 'before' in evts
        assert 'after' not in evts
        return 'request'
    assert 'after' not in evts
    rv = app.test_client().get('/').data
    assert 'after' in evts
    assert rv == b'request|after'
def test_request_preprocessing_early_return():
    app = flask.Flask(__name__)
    evts = []
    @app.before_request
    def before_request1():
        evts.append(1)
    @app.before_request
    def before_request2():
        evts.append(2)
        return "hello"
    @app.before_request
    def before_request3():
        evts.append(3)
        return "bye"
    @app.route('/')
    def index():
        evts.append('index')
        return "damnit"
    rv = app.test_client().get('/').data.strip()
    assert rv == b'hello'
    assert evts == [1, 2]
def test_after_request_processing():
    app = flask.Flask(__name__)
    app.testing = True
    @app.route('/')
    def index():
        @flask.after_this_request
        def foo(response):
            response.headers['X-Foo'] = 'a header'
            return response
        return 'Test'
    c = app.test_client()
    resp = c.get('/')
    assert resp.status_code == 200
    assert resp.headers['X-Foo'] == 'a header'
def test_teardown_request_handler():
    called = []
    app = flask.Flask(__name__)
    @app.teardown_request
    def teardown_request(exc):
        called.append(True)
        return "Ignored"
    @app.route('/')
    def root():
        return "Response"
    rv = app.test_client().get('/')
    assert rv.status_code == 200
    assert b'Response' in rv.data
    assert len(called) == 1
def test_teardown_request_handler_debug_mode():
    called = []
    app = flask.Flask(__name__)
    app.testing = True
    @app.teardown_request
    def teardown_request(exc):
        called.append(True)
        return "Ignored"
    @app.route('/')
    def root():
        return "Response"
    rv = app.test_client().get('/')
    assert rv.status_code == 200
    assert b'Response' in rv.data
    assert len(called) == 1
def test_teardown_request_handler_error():
    called = []
    app = flask.Flask(__name__)
    app.config['LOGGER_HANDLER_POLICY'] = 'never'
    @app.teardown_request
    def teardown_request1(exc):
        assert type(exc) == ZeroDivisionError
        called.append(True)
        try:
            raise TypeError()
        except:
            pass
    @app.teardown_request
    def teardown_request2(exc):
        assert type(exc) == ZeroDivisionError
        called.append(True)
        try:
            raise TypeError()
        except:
            pass
    @app.route('/')
    def fails():
        1 // 0
    rv = app.test_client().get('/')
    assert rv.status_code == 500
    assert b'Internal Server Error' in rv.data
    assert len(called) == 2
def test_before_after_request_order():
    called = []
    app = flask.Flask(__name__)
    @app.before_request
    def before1():
        called.append(1)
    @app.before_request
    def before2():
        called.append(2)
    @app.after_request
    def after1(response):
        called.append(4)
        return response
    @app.after_request
    def after2(response):
        called.append(3)
        return response
    @app.teardown_request
    def finish1(exc):
        called.append(6)
    @app.teardown_request
    def finish2(exc):
        called.append(5)
    @app.route('/')
    def index():
        return '42'
    rv = app.test_client().get('/')
    assert rv.data == b'42'
    assert called == [1, 2, 3, 4, 5, 6]
def test_error_handling():
    app = flask.Flask(__name__)
    app.config['LOGGER_HANDLER_POLICY'] = 'never'
    @app.errorhandler(404)
    def not_found(e):
        return 'not found', 404
    @app.errorhandler(500)
    def internal_server_error(e):
        return 'internal server error', 500
    @app.errorhandler(Forbidden)
    def forbidden(e):
        return 'forbidden', 403
    @app.route('/')
    def index():
        flask.abort(404)
    @app.route('/error')
    def error():
        1 // 0
    @app.route('/forbidden')
    def error2():
        flask.abort(403)
    c = app.test_client()
    rv = c.get('/')
    assert rv.status_code == 404
    assert rv.data == b'not found'
    rv = c.get('/error')
    assert rv.status_code == 500
    assert b'internal server error' == rv.data
    rv = c.get('/forbidden')
    assert rv.status_code == 403
    assert b'forbidden' == rv.data
def test_before_request_and_routing_errors():
    app = flask.Flask(__name__)
    @app.before_request
    def attach_something():
        flask.g.something = 'value'
    @app.errorhandler(404)
    def return_something(error):
        return flask.g.something, 404
    rv = app.test_client().get('/')
    assert rv.status_code == 404
    assert rv.data == b'value'
def test_user_error_handling():
    class MyException(Exception):
        pass
    app = flask.Flask(__name__)
    @app.errorhandler(MyException)
    def handle_my_exception(e):
        assert isinstance(e, MyException)
        return '42'
    @app.route('/')
    def index():
        raise MyException()
    c = app.test_client()
    assert c.get('/').data == b'42'
def test_http_error_subclass_handling():
    class ForbiddenSubclass(Forbidden):
        pass
    app = flask.Flask(__name__)
    @app.errorhandler(ForbiddenSubclass)
    def handle_forbidden_subclass(e):
        assert isinstance(e, ForbiddenSubclass)
        return 'banana'
    @app.errorhandler(403)
    def handle_forbidden_subclass(e):
        assert not isinstance(e, ForbiddenSubclass)
        assert isinstance(e, Forbidden)
        return 'apple'
    @app.route('/1')
    def index1():
        raise ForbiddenSubclass()
    @app.route('/2')
    def index2():
        flask.abort(403)
    @app.route('/3')
    def index3():
        raise Forbidden()
    c = app.test_client()
    assert c.get('/1').data == b'banana'
    assert c.get('/2').data == b'apple'
    assert c.get('/3').data == b'apple'
def test_trapping_of_bad_request_key_errors():
    app = flask.Flask(__name__)
    app.testing = True
    @app.route('/fail')
    def fail():
        flask.request.form['missing_key']
    c = app.test_client()
    assert c.get('/fail').status_code == 400
    app.config['TRAP_BAD_REQUEST_ERRORS'] = True
    c = app.test_client()
    with pytest.raises(KeyError) as e:
        c.get("/fail")
    assert e.errisinstance(BadRequest)
def test_trapping_of_all_http_exceptions():
    app = flask.Flask(__name__)
    app.testing = True
    app.config['TRAP_HTTP_EXCEPTIONS'] = True
    @app.route('/fail')
    def fail():
        flask.abort(404)
    c = app.test_client()
    with pytest.raises(NotFound):
        c.get('/fail')
def test_enctype_debug_helper():
    from flask.debughelpers import DebugFilesKeyError
    app = flask.Flask(__name__)
    app.debug = True
    @app.route('/fail', methods=['POST'])
    def index():
        return flask.request.files['foo'].filename
    with app.test_client() as c:
        with pytest.raises(DebugFilesKeyError) as e:
            c.post('/fail', data={'foo': 'index.txt'})
        assert 'no file contents were transmitted' in str(e.value)
        assert 'This was submitted: "index.txt"' in str(e.value)
def test_response_creation():
    app = flask.Flask(__name__)
    @app.route('/unicode')
    def from_unicode():
        return u'Hällo Wörld'
    @app.route('/string')
    def from_string():
        return u'Hällo Wörld'.encode('utf-8')
    @app.route('/args')
    def from_tuple():
        return 'Meh', 400, {
            'X-Foo': 'Testing',
            'Content-Type': 'text/plain; charset=utf-8'
        }
    @app.route('/two_args')
    def from_two_args_tuple():
        return 'Hello', {
            'X-Foo': 'Test',
            'Content-Type': 'text/plain; charset=utf-8'
        }
    @app.route('/args_status')
    def from_status_tuple():
        return 'Hi, status!', 400
    @app.route('/args_header')
    def from_response_instance_status_tuple():
        return flask.Response('Hello world', 404), {
            "X-Foo": "Bar",
            "X-Bar": "Foo"
        }
    c = app.test_client()
    assert c.get('/unicode').data == u'Hällo Wörld'.encode('utf-8')
    assert c.get('/string').data == u'Hällo Wörld'.encode('utf-8')
    rv = c.get('/args')
    assert rv.data == b'Meh'
    assert rv.headers['X-Foo'] == 'Testing'
    assert rv.status_code == 400
    assert rv.mimetype == 'text/plain'
    rv2 = c.get('/two_args')
    assert rv2.data == b'Hello'
    assert rv2.headers['X-Foo'] == 'Test'
    assert rv2.status_code == 200
    assert rv2.mimetype == 'text/plain'
    rv3 = c.get('/args_status')
    assert rv3.data == b'Hi, status!'
    assert rv3.status_code == 400
    assert rv3.mimetype == 'text/html'
    rv4 = c.get('/args_header')
    assert rv4.data == b'Hello world'
    assert rv4.headers['X-Foo'] == 'Bar'
    assert rv4.headers['X-Bar'] == 'Foo'
    assert rv4.status_code == 404
def test_make_response():
    app = flask.Flask(__name__)
    with app.test_request_context():
        rv = flask.make_response()
        assert rv.status_code == 200
        assert rv.data == b''
        assert rv.mimetype == 'text/html'
        rv = flask.make_response('Awesome')
        assert rv.status_code == 200
        assert rv.data == b'Awesome'
        assert rv.mimetype == 'text/html'
        rv = flask.make_response('W00t', 404)
        assert rv.status_code == 404
        assert rv.data == b'W00t'
        assert rv.mimetype == 'text/html'
def test_make_response_with_response_instance():
    app = flask.Flask(__name__)
    with app.test_request_context():
        rv = flask.make_response(
            flask.jsonify({'msg': 'W00t'}), 400)
        assert rv.status_code == 400
        assert rv.data == b'{\n  "msg": "W00t"\n}\n'
        assert rv.mimetype == 'application/json'
        rv = flask.make_response(
            flask.Response(''), 400)
        assert rv.status_code == 400
        assert rv.data == b''
        assert rv.mimetype == 'text/html'
        rv = flask.make_response(
            flask.Response('', headers={'Content-Type': 'text/html'}),
            400, [('X-Foo', 'bar')])
        assert rv.status_code == 400
        assert rv.headers['Content-Type'] == 'text/html'
        assert rv.headers['X-Foo'] == 'bar'
def test_jsonify_no_prettyprint():
    app = flask.Flask(__name__)
    app.config.update({"JSONIFY_PRETTYPRINT_REGULAR": False})
    with app.test_request_context():
        compressed_msg = b'{"msg":{"submsg":"W00t"},"msg2":"foobar"}\n'
        uncompressed_msg = {
            "msg": {
                "submsg": "W00t"
            },
            "msg2": "foobar"
            }
        rv = flask.make_response(
            flask.jsonify(uncompressed_msg), 200)
        assert rv.data == compressed_msg
def test_jsonify_prettyprint():
    app = flask.Flask(__name__)
    app.config.update({"JSONIFY_PRETTYPRINT_REGULAR": True})
    with app.test_request_context():
        compressed_msg = {"msg":{"submsg":"W00t"},"msg2":"foobar"}
        pretty_response =\
            b'{\n  "msg": {\n    "submsg": "W00t"\n  }, \n  "msg2": "foobar"\n}\n'
        rv = flask.make_response(
            flask.jsonify(compressed_msg), 200)
        assert rv.data == pretty_response
def test_jsonify_mimetype():
    app = flask.Flask(__name__)
    app.config.update({"JSONIFY_MIMETYPE": 'application/vnd.api+json'})
    with app.test_request_context():
        msg = {
            "msg": {"submsg": "W00t"},
        }
        rv = flask.make_response(
            flask.jsonify(msg), 200)
        assert rv.mimetype == 'application/vnd.api+json'
def test_jsonify_args_and_kwargs_check():
    app = flask.Flask(__name__)
    with app.test_request_context():
        with pytest.raises(TypeError) as e:
            flask.jsonify('fake args', kwargs='fake')
        assert 'behavior undefined' in str(e.value)
def test_url_generation():
    app = flask.Flask(__name__)
    @app.route('/hello/<name>', methods=['POST'])
    def hello():
        pass
    with app.test_request_context():
        assert flask.url_for('hello', name='test x') == '/hello/test%20x'
        assert flask.url_for('hello', name='test x', _external=True) == \
            'http://localhost/hello/test%20x'
def test_build_error_handler():
    app = flask.Flask(__name__)
    with app.test_request_context():
        pytest.raises(BuildError, flask.url_for, 'spam')
    try:
        with app.test_request_context():
            flask.url_for('spam')
    except BuildError as err:
        error = err
    try:
        raise RuntimeError('Test case where BuildError is not current.')
    except RuntimeError:
        pytest.raises(
            BuildError, app.handle_url_build_error, error, 'spam', {})
    def handler(error, endpoint, values):
        return '/test_handler/'
    app.url_build_error_handlers.append(handler)
    with app.test_request_context():
        assert flask.url_for('spam') == '/test_handler/'
def test_build_error_handler_reraise():
    app = flask.Flask(__name__)
    def handler_raises_build_error(error, endpoint, values):
        raise error
    app.url_build_error_handlers.append(handler_raises_build_error)
    with app.test_request_context():
        pytest.raises(BuildError, flask.url_for, 'not.existing')
def test_custom_converters():
    from werkzeug.routing import BaseConverter
    class ListConverter(BaseConverter):
        def to_python(self, value):
            return value.split(',')
        def to_url(self, value):
            base_to_url = super(ListConverter, self).to_url
            return ','.join(base_to_url(x) for x in value)
    app = flask.Flask(__name__)
    app.url_map.converters['list'] = ListConverter
    @app.route('/<list:args>')
    def index(args):
        return '|'.join(args)
    c = app.test_client()
    assert c.get('/1,2,3').data == b'1|2|3'
def test_static_files():
    app = flask.Flask(__name__)
    app.testing = True
    rv = app.test_client().get('/static/index.html')
    assert rv.status_code == 200
    assert rv.data.strip() == b'<h1>Hello World!</h1>'
    with app.test_request_context():
        assert flask.url_for('static', filename='index.html') == \
            '/static/index.html'
    rv.close()
def test_static_path_deprecated(recwarn):
    app = flask.Flask(__name__, static_path='/foo')
    recwarn.pop(DeprecationWarning)
    app.testing = True
    rv = app.test_client().get('/foo/index.html')
    assert rv.status_code == 200
    rv.close()
    with app.test_request_context():
        assert flask.url_for('static', filename='index.html') == '/foo/index.html'
def test_static_url_path():
    app = flask.Flask(__name__, static_url_path='/foo')
    app.testing = True
    rv = app.test_client().get('/foo/index.html')
    assert rv.status_code == 200
    rv.close()
    with app.test_request_context():
        assert flask.url_for('static', filename='index.html') == '/foo/index.html'
def test_none_response():
    app = flask.Flask(__name__)
    app.testing = True
    @app.route('/')
    def test():
        return None
    try:
        app.test_client().get('/')
    except ValueError as e:
        assert str(e) == 'View function did not return a response'
        pass
    else:
        assert "Expected ValueError"
def test_request_locals():
    assert repr(flask.g) == '<LocalProxy unbound>'
    assert not flask.g
def test_test_app_proper_environ():
    app = flask.Flask(__name__)
    app.config.update(
        SERVER_NAME='localhost.localdomain:5000'
    )
    @app.route('/')
    def index():
        return 'Foo'
    @app.route('/', subdomain='foo')
    def subdomain():
        return 'Foo SubDomain'
    rv = app.test_client().get('/')
    assert rv.data == b'Foo'
    rv = app.test_client().get('/', 'http://localhost.localdomain:5000')
    assert rv.data == b'Foo'
    rv = app.test_client().get('/', 'https://localhost.localdomain:5000')
    assert rv.data == b'Foo'
    app.config.update(SERVER_NAME='localhost.localdomain')
    rv = app.test_client().get('/', 'https://localhost.localdomain')
    assert rv.data == b'Foo'
    try:
        app.config.update(SERVER_NAME='localhost.localdomain:443')
        rv = app.test_client().get('/', 'https://localhost.localdomain')
        assert rv.status_code == 404
    except ValueError as e:
        assert str(e) == (
            "the server name provided "
            "('localhost.localdomain:443') does not match the "
            "server name from the WSGI environment ('localhost.localdomain')"
        )
    try:
        app.config.update(SERVER_NAME='localhost.localdomain')
        rv = app.test_client().get('/', 'http://foo.localhost')
        assert rv.status_code == 404
    except ValueError as e:
        assert str(e) == (
            "the server name provided "
            "('localhost.localdomain') does not match the "
            "server name from the WSGI environment ('foo.localhost')"
        )
    rv = app.test_client().get('/', 'http://foo.localhost.localdomain')
    assert rv.data == b'Foo SubDomain'
def test_exception_propagation():
    def apprunner(config_key):
        app = flask.Flask(__name__)
        app.config['LOGGER_HANDLER_POLICY'] = 'never'
        @app.route('/')
        def index():
            1 // 0
        c = app.test_client()
        if config_key is not None:
            app.config[config_key] = True
            with pytest.raises(Exception):
                c.get('/')
        else:
            assert c.get('/').status_code == 500
    for config_key in 'TESTING', 'PROPAGATE_EXCEPTIONS', 'DEBUG', None:
        t = Thread(target=apprunner, args=(config_key,))
        t.start()
        t.join()
@pytest.mark.parametrize('debug', [True, False])
@pytest.mark.parametrize('use_debugger', [True, False])
@pytest.mark.parametrize('use_reloader', [True, False])
@pytest.mark.parametrize('propagate_exceptions', [None, True, False])
def test_werkzeug_passthrough_errors(monkeypatch, debug, use_debugger,
                                     use_reloader, propagate_exceptions):
    rv = {}
    def run_simple_mock(*args, **kwargs):
        rv['passthrough_errors'] = kwargs.get('passthrough_errors')
    app = flask.Flask(__name__)
    monkeypatch.setattr(werkzeug.serving, 'run_simple', run_simple_mock)
    app.config['PROPAGATE_EXCEPTIONS'] = propagate_exceptions
    app.run(debug=debug, use_debugger=use_debugger, use_reloader=use_reloader)
    assert rv['passthrough_errors']
def test_max_content_length():
    app = flask.Flask(__name__)
    app.config['MAX_CONTENT_LENGTH'] = 64
    @app.before_request
    def always_first():
        flask.request.form['myfile']
        assert False
    @app.route('/accept', methods=['POST'])
    def accept_file():
        flask.request.form['myfile']
        assert False
    @app.errorhandler(413)
    def catcher(error):
        return '42'
    c = app.test_client()
    rv = c.post('/accept', data={'myfile': 'foo' * 100})
    assert rv.data == b'42'
def test_url_processors():
    app = flask.Flask(__name__)
    @app.url_defaults
    def add_language_code(endpoint, values):
        if flask.g.lang_code is not None and \
           app.url_map.is_endpoint_expecting(endpoint, 'lang_code'):
            values.setdefault('lang_code', flask.g.lang_code)
    @app.url_value_preprocessor
    def pull_lang_code(endpoint, values):
        flask.g.lang_code = values.pop('lang_code', None)
    @app.route('/<lang_code>/')
    def index():
        return flask.url_for('about')
    @app.route('/<lang_code>/about')
    def about():
        return flask.url_for('something_else')
    @app.route('/foo')
    def something_else():
        return flask.url_for('about', lang_code='en')
    c = app.test_client()
    assert c.get('/de/').data == b'/de/about'
    assert c.get('/de/about').data == b'/foo'
    assert c.get('/foo').data == b'/en/about'
def test_inject_blueprint_url_defaults():
    app = flask.Flask(__name__)
    bp = flask.Blueprint('foo.bar.baz', __name__,
                         template_folder='template')
    @bp.url_defaults
    def bp_defaults(endpoint, values):
        values['page'] = 'login'
    @bp.route('/<page>')
    def view(page):
        pass
    app.register_blueprint(bp)
    values = dict()
    app.inject_url_defaults('foo.bar.baz.view', values)
    expected = dict(page='login')
    assert values == expected
    with app.test_request_context('/somepage'):
        url = flask.url_for('foo.bar.baz.view')
    expected = '/login'
    assert url == expected
def test_nonascii_pathinfo():
    app = flask.Flask(__name__)
    app.testing = True
    @app.route(u'/киртест')
    def index():
        return 'Hello World!'
    c = app.test_client()
    rv = c.get(u'/киртест')
    assert rv.data == b'Hello World!'
def test_debug_mode_complains_after_first_request():
    app = flask.Flask(__name__)
    app.debug = True
    @app.route('/')
    def index():
        return 'Awesome'
    assert not app.got_first_request
    assert app.test_client().get('/').data == b'Awesome'
    with pytest.raises(AssertionError) as e:
        @app.route('/foo')
        def broken():
            return 'Meh'
    assert 'A setup function was called' in str(e)
    app.debug = False
    @app.route('/foo')
    def working():
        return 'Meh'
    assert app.test_client().get('/foo').data == b'Meh'
    assert app.got_first_request
def test_before_first_request_functions():
    got = []
    app = flask.Flask(__name__)
    @app.before_first_request
    def foo():
        got.append(42)
    c = app.test_client()
    c.get('/')
    assert got == [42]
    c.get('/')
    assert got == [42]
    assert app.got_first_request
def test_before_first_request_functions_concurrent():
    got = []
    app = flask.Flask(__name__)
    @app.before_first_request
    def foo():
        time.sleep(0.2)
        got.append(42)
    c = app.test_client()
    def get_and_assert():
        c.get("/")
        assert got == [42]
    t = Thread(target=get_and_assert)
    t.start()
    get_and_assert()
    t.join()
    assert app.got_first_request
def test_routing_redirect_debugging():
    app = flask.Flask(__name__)
    app.debug = True
    @app.route('/foo/', methods=['GET', 'POST'])
    def foo():
        return 'success'
    with app.test_client() as c:
        with pytest.raises(AssertionError) as e:
            c.post('/foo', data={})
        assert 'http://localhost/foo/' in str(e)
        assert ('Make sure to directly send '
                'your POST-request to this URL') in str(e)
        rv = c.get('/foo', data={}, follow_redirects=True)
        assert rv.data == b'success'
    app.debug = False
    with app.test_client() as c:
        rv = c.post('/foo', data={}, follow_redirects=True)
        assert rv.data == b'success'
def test_route_decorator_custom_endpoint():
    app = flask.Flask(__name__)
    app.debug = True
    @app.route('/foo/')
    def foo():
        return flask.request.endpoint
    @app.route('/bar/', endpoint='bar')
    def for_bar():
        return flask.request.endpoint
    @app.route('/bar/123', endpoint='123')
    def for_bar_foo():
        return flask.request.endpoint
    with app.test_request_context():
        assert flask.url_for('foo') == '/foo/'
        assert flask.url_for('bar') == '/bar/'
        assert flask.url_for('123') == '/bar/123'
    c = app.test_client()
    assert c.get('/foo/').data == b'foo'
    assert c.get('/bar/').data == b'bar'
    assert c.get('/bar/123').data == b'123'
def test_preserve_only_once():
    app = flask.Flask(__name__)
    app.debug = True
    @app.route('/fail')
    def fail_func():
        1 // 0
    c = app.test_client()
    for x in range(3):
        with pytest.raises(ZeroDivisionError):
            c.get('/fail')
    assert flask._request_ctx_stack.top is not None
    assert flask._app_ctx_stack.top is not None
    flask._request_ctx_stack.top.pop()
    assert flask._request_ctx_stack.top is None
    assert flask._app_ctx_stack.top is None
def test_preserve_remembers_exception():
    app = flask.Flask(__name__)
    app.debug = True
    errors = []
    @app.route('/fail')
    def fail_func():
        1 // 0
    @app.route('/success')
    def success_func():
        return 'Okay'
    @app.teardown_request
    def teardown_handler(exc):
        errors.append(exc)
    c = app.test_client()
    with pytest.raises(ZeroDivisionError):
        c.get('/fail')
    assert errors == []
    c.get('/success')
    assert len(errors) == 2
    assert isinstance(errors[0], ZeroDivisionError)
    c.get('/success')
    assert len(errors) == 3
    assert errors[1] is None
def test_get_method_on_g():
    app = flask.Flask(__name__)
    app.testing = True
    with app.app_context():
        assert flask.g.get('x') is None
        assert flask.g.get('x', 11) == 11
        flask.g.x = 42
        assert flask.g.get('x') == 42
        assert flask.g.x == 42
def test_g_iteration_protocol():
    app = flask.Flask(__name__)
    app.testing = True
    with app.app_context():
        flask.g.foo = 23
        flask.g.bar = 42
        assert 'foo' in flask.g
        assert 'foos' not in flask.g
        assert sorted(flask.g) == ['bar', 'foo']
def test_subdomain_basic_support():
    app = flask.Flask(__name__)
    app.config['SERVER_NAME'] = 'localhost'
    @app.route('/')
    def normal_index():
        return 'normal index'
    @app.route('/', subdomain='test')
    def test_index():
        return 'test index'
    c = app.test_client()
    rv = c.get('/', 'http://localhost/')
    assert rv.data == b'normal index'
    rv = c.get('/', 'http://test.localhost/')
    assert rv.data == b'test index'
def test_subdomain_matching():
    app = flask.Flask(__name__)
    app.config['SERVER_NAME'] = 'localhost'
    @app.route('/', subdomain='<user>')
    def index(user):
        return 'index for %s' % user
    c = app.test_client()
    rv = c.get('/', 'http://mitsuhiko.localhost/')
    assert rv.data == b'index for mitsuhiko'
def test_subdomain_matching_with_ports():
    app = flask.Flask(__name__)
    app.config['SERVER_NAME'] = 'localhost:3000'
    @app.route('/', subdomain='<user>')
    def index(user):
        return 'index for %s' % user
    c = app.test_client()
    rv = c.get('/', 'http://mitsuhiko.localhost:3000/')
    assert rv.data == b'index for mitsuhiko'
def test_multi_route_rules():
    app = flask.Flask(__name__)
    @app.route('/')
    @app.route('/<test>/')
    def index(test='a'):
        return test
    rv = app.test_client().open('/')
    assert rv.data == b'a'
    rv = app.test_client().open('/b/')
    assert rv.data == b'b'
def test_multi_route_class_views():
    class View(object):
        def __init__(self, app):
            app.add_url_rule('/', 'index', self.index)
            app.add_url_rule('/<test>/', 'index', self.index)
        def index(self, test='a'):
            return test
    app = flask.Flask(__name__)
    _ = View(app)
    rv = app.test_client().open('/')
    assert rv.data == b'a'
    rv = app.test_client().open('/b/')
    assert rv.data == b'b'
def test_run_defaults(monkeypatch):
    rv = {}
    def run_simple_mock(*args, **kwargs):
        rv['result'] = 'running...'
    app = flask.Flask(__name__)
    monkeypatch.setattr(werkzeug.serving, 'run_simple', run_simple_mock)
    app.run()
    assert rv['result'] == 'running...'
def test_run_server_port(monkeypatch):
    rv = {}
    def run_simple_mock(hostname, port, application, *args, **kwargs):
        rv['result'] = 'running on %s:%s ...' % (hostname, port)
    app = flask.Flask(__name__)
    monkeypatch.setattr(werkzeug.serving, 'run_simple', run_simple_mock)
    hostname, port = 'localhost', 8000
    app.run(hostname, port, debug=True)
    assert rv['result'] == 'running on %s:%s ...' % (hostname, port)
import pytest
import flask
from flask._compat import text_type
from werkzeug.http import parse_cache_control_header
from jinja2 import TemplateNotFound
def test_blueprint_specific_error_handling():
    frontend = flask.Blueprint('frontend', __name__)
    backend = flask.Blueprint('backend', __name__)
    sideend = flask.Blueprint('sideend', __name__)
    @frontend.errorhandler(403)
    def frontend_forbidden(e):
        return 'frontend says no', 403
    @frontend.route('/frontend-no')
    def frontend_no():
        flask.abort(403)
    @backend.errorhandler(403)
    def backend_forbidden(e):
        return 'backend says no', 403
    @backend.route('/backend-no')
    def backend_no():
        flask.abort(403)
    @sideend.route('/what-is-a-sideend')
    def sideend_no():
        flask.abort(403)
    app = flask.Flask(__name__)
    app.register_blueprint(frontend)
    app.register_blueprint(backend)
    app.register_blueprint(sideend)
    @app.errorhandler(403)
    def app_forbidden(e):
        return 'application itself says no', 403
    c = app.test_client()
    assert c.get('/frontend-no').data == b'frontend says no'
    assert c.get('/backend-no').data == b'backend says no'
    assert c.get('/what-is-a-sideend').data == b'application itself says no'
def test_blueprint_specific_user_error_handling():
    class MyDecoratorException(Exception):
        pass
    class MyFunctionException(Exception):
        pass
    blue = flask.Blueprint('blue', __name__)
    @blue.errorhandler(MyDecoratorException)
    def my_decorator_exception_handler(e):
        assert isinstance(e, MyDecoratorException)
        return 'boom'
    def my_function_exception_handler(e):
        assert isinstance(e, MyFunctionException)
        return 'bam'
    blue.register_error_handler(MyFunctionException, my_function_exception_handler)
    @blue.route('/decorator')
    def blue_deco_test():
        raise MyDecoratorException()
    @blue.route('/function')
    def blue_func_test():
        raise MyFunctionException()
    app = flask.Flask(__name__)
    app.register_blueprint(blue)
    c = app.test_client()
    assert c.get('/decorator').data == b'boom'
    assert c.get('/function').data == b'bam'
def test_blueprint_url_definitions():
    bp = flask.Blueprint('test', __name__)
    @bp.route('/foo', defaults={'baz': 42})
    def foo(bar, baz):
        return '%s/%d' % (bar, baz)
    @bp.route('/bar')
    def bar(bar):
        return text_type(bar)
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/1', url_defaults={'bar': 23})
    app.register_blueprint(bp, url_prefix='/2', url_defaults={'bar': 19})
    c = app.test_client()
    assert c.get('/1/foo').data == b'23/42'
    assert c.get('/2/foo').data == b'19/42'
    assert c.get('/1/bar').data == b'23'
    assert c.get('/2/bar').data == b'19'
def test_blueprint_url_processors():
    bp = flask.Blueprint('frontend', __name__, url_prefix='/<lang_code>')
    @bp.url_defaults
    def add_language_code(endpoint, values):
        values.setdefault('lang_code', flask.g.lang_code)
    @bp.url_value_preprocessor
    def pull_lang_code(endpoint, values):
        flask.g.lang_code = values.pop('lang_code')
    @bp.route('/')
    def index():
        return flask.url_for('.about')
    @bp.route('/about')
    def about():
        return flask.url_for('.index')
    app = flask.Flask(__name__)
    app.register_blueprint(bp)
    c = app.test_client()
    assert c.get('/de/').data == b'/de/about'
    assert c.get('/de/about').data == b'/de/'
def test_templates_and_static(test_apps):
    from blueprintapp import app
    c = app.test_client()
    rv = c.get('/')
    assert rv.data == b'Hello from the Frontend'
    rv = c.get('/admin/')
    assert rv.data == b'Hello from the Admin'
    rv = c.get('/admin/index2')
    assert rv.data == b'Hello from the Admin'
    rv = c.get('/admin/static/test.txt')
    assert rv.data.strip() == b'Admin File'
    rv.close()
    rv = c.get('/admin/static/css/test.css')
    assert rv.data.strip() == b'/* nested file */'
    rv.close()
    max_age_default = app.config['SEND_FILE_MAX_AGE_DEFAULT']
    try:
        expected_max_age = 3600
        if app.config['SEND_FILE_MAX_AGE_DEFAULT'] == expected_max_age:
            expected_max_age = 7200
        app.config['SEND_FILE_MAX_AGE_DEFAULT'] = expected_max_age
        rv = c.get('/admin/static/css/test.css')
        cc = parse_cache_control_header(rv.headers['Cache-Control'])
        assert cc.max_age == expected_max_age
        rv.close()
    finally:
        app.config['SEND_FILE_MAX_AGE_DEFAULT'] = max_age_default
    with app.test_request_context():
        assert flask.url_for('admin.static', filename='test.txt') == '/admin/static/test.txt'
    with app.test_request_context():
        with pytest.raises(TemplateNotFound) as e:
            flask.render_template('missing.html')
        assert e.value.name == 'missing.html'
    with flask.Flask(__name__).test_request_context():
        assert flask.render_template('nested/nested.txt') == 'I\'m nested'
def test_default_static_cache_timeout():
    app = flask.Flask(__name__)
    class MyBlueprint(flask.Blueprint):
        def get_send_file_max_age(self, filename):
            return 100
    blueprint = MyBlueprint('blueprint', __name__, static_folder='static')
    app.register_blueprint(blueprint)
    max_age_default = app.config['SEND_FILE_MAX_AGE_DEFAULT']
    try:
        with app.test_request_context():
            unexpected_max_age = 3600
            if app.config['SEND_FILE_MAX_AGE_DEFAULT'] == unexpected_max_age:
                unexpected_max_age = 7200
            app.config['SEND_FILE_MAX_AGE_DEFAULT'] = unexpected_max_age
            rv = blueprint.send_static_file('index.html')
            cc = parse_cache_control_header(rv.headers['Cache-Control'])
            assert cc.max_age == 100
            rv.close()
    finally:
        app.config['SEND_FILE_MAX_AGE_DEFAULT'] = max_age_default
def test_templates_list(test_apps):
    from blueprintapp import app
    templates = sorted(app.jinja_env.list_templates())
    assert templates == ['admin/index.html', 'frontend/index.html']
def test_dotted_names():
    frontend = flask.Blueprint('myapp.frontend', __name__)
    backend = flask.Blueprint('myapp.backend', __name__)
    @frontend.route('/fe')
    def frontend_index():
        return flask.url_for('myapp.backend.backend_index')
    @frontend.route('/fe2')
    def frontend_page2():
        return flask.url_for('.frontend_index')
    @backend.route('/be')
    def backend_index():
        return flask.url_for('myapp.frontend.frontend_index')
    app = flask.Flask(__name__)
    app.register_blueprint(frontend)
    app.register_blueprint(backend)
    c = app.test_client()
    assert c.get('/fe').data.strip() == b'/be'
    assert c.get('/fe2').data.strip() == b'/fe'
    assert c.get('/be').data.strip() == b'/fe'
def test_dotted_names_from_app():
    app = flask.Flask(__name__)
    app.testing = True
    test = flask.Blueprint('test', __name__)
    @app.route('/')
    def app_index():
        return flask.url_for('test.index')
    @test.route('/test/')
    def index():
        return flask.url_for('app_index')
    app.register_blueprint(test)
    with app.test_client() as c:
        rv = c.get('/')
        assert rv.data == b'/test/'
def test_empty_url_defaults():
    bp = flask.Blueprint('bp', __name__)
    @bp.route('/', defaults={'page': 1})
    @bp.route('/page/<int:page>')
    def something(page):
        return str(page)
    app = flask.Flask(__name__)
    app.register_blueprint(bp)
    c = app.test_client()
    assert c.get('/').data == b'1'
    assert c.get('/page/2').data == b'2'
def test_route_decorator_custom_endpoint():
    bp = flask.Blueprint('bp', __name__)
    @bp.route('/foo')
    def foo():
        return flask.request.endpoint
    @bp.route('/bar', endpoint='bar')
    def foo_bar():
        return flask.request.endpoint
    @bp.route('/bar/123', endpoint='123')
    def foo_bar_foo():
        return flask.request.endpoint
    @bp.route('/bar/foo')
    def bar_foo():
        return flask.request.endpoint
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    @app.route('/')
    def index():
        return flask.request.endpoint
    c = app.test_client()
    assert c.get('/').data == b'index'
    assert c.get('/py/foo').data == b'bp.foo'
    assert c.get('/py/bar').data == b'bp.bar'
    assert c.get('/py/bar/123').data == b'bp.123'
    assert c.get('/py/bar/foo').data == b'bp.bar_foo'
def test_route_decorator_custom_endpoint_with_dots():
    bp = flask.Blueprint('bp', __name__)
    @bp.route('/foo')
    def foo():
        return flask.request.endpoint
    try:
        @bp.route('/bar', endpoint='bar.bar')
        def foo_bar():
            return flask.request.endpoint
    except AssertionError:
        pass
    else:
        raise AssertionError('expected AssertionError not raised')
    try:
        @bp.route('/bar/123', endpoint='bar.123')
        def foo_bar_foo():
            return flask.request.endpoint
    except AssertionError:
        pass
    else:
        raise AssertionError('expected AssertionError not raised')
    def foo_foo_foo():
        pass
    pytest.raises(
        AssertionError,
        lambda: bp.add_url_rule(
            '/bar/123', endpoint='bar.123', view_func=foo_foo_foo
        )
    )
    pytest.raises(
        AssertionError,
        bp.route('/bar/123', endpoint='bar.123'),
        lambda: None
    )
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    c = app.test_client()
    assert c.get('/py/foo').data == b'bp.foo'
    rv = c.get('/py/bar')
    assert rv.status_code == 404
    rv = c.get('/py/bar/123')
    assert rv.status_code == 404
def test_template_filter():
    bp = flask.Blueprint('bp', __name__)
    @bp.app_template_filter()
    def my_reverse(s):
        return s[::-1]
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    assert 'my_reverse' in app.jinja_env.filters.keys()
    assert app.jinja_env.filters['my_reverse'] == my_reverse
    assert app.jinja_env.filters['my_reverse']('abcd') == 'dcba'
def test_add_template_filter():
    bp = flask.Blueprint('bp', __name__)
    def my_reverse(s):
        return s[::-1]
    bp.add_app_template_filter(my_reverse)
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    assert 'my_reverse' in app.jinja_env.filters.keys()
    assert app.jinja_env.filters['my_reverse'] == my_reverse
    assert app.jinja_env.filters['my_reverse']('abcd') == 'dcba'
def test_template_filter_with_name():
    bp = flask.Blueprint('bp', __name__)
    @bp.app_template_filter('strrev')
    def my_reverse(s):
        return s[::-1]
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    assert 'strrev' in app.jinja_env.filters.keys()
    assert app.jinja_env.filters['strrev'] == my_reverse
    assert app.jinja_env.filters['strrev']('abcd') == 'dcba'
def test_add_template_filter_with_name():
    bp = flask.Blueprint('bp', __name__)
    def my_reverse(s):
        return s[::-1]
    bp.add_app_template_filter(my_reverse, 'strrev')
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    assert 'strrev' in app.jinja_env.filters.keys()
    assert app.jinja_env.filters['strrev'] == my_reverse
    assert app.jinja_env.filters['strrev']('abcd') == 'dcba'
def test_template_filter_with_template():
    bp = flask.Blueprint('bp', __name__)
    @bp.app_template_filter()
    def super_reverse(s):
        return s[::-1]
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    @app.route('/')
    def index():
        return flask.render_template('template_filter.html', value='abcd')
    rv = app.test_client().get('/')
    assert rv.data == b'dcba'
def test_template_filter_after_route_with_template():
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return flask.render_template('template_filter.html', value='abcd')
    bp = flask.Blueprint('bp', __name__)
    @bp.app_template_filter()
    def super_reverse(s):
        return s[::-1]
    app.register_blueprint(bp, url_prefix='/py')
    rv = app.test_client().get('/')
    assert rv.data == b'dcba'
def test_add_template_filter_with_template():
    bp = flask.Blueprint('bp', __name__)
    def super_reverse(s):
        return s[::-1]
    bp.add_app_template_filter(super_reverse)
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    @app.route('/')
    def index():
        return flask.render_template('template_filter.html', value='abcd')
    rv = app.test_client().get('/')
    assert rv.data == b'dcba'
def test_template_filter_with_name_and_template():
    bp = flask.Blueprint('bp', __name__)
    @bp.app_template_filter('super_reverse')
    def my_reverse(s):
        return s[::-1]
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    @app.route('/')
    def index():
        return flask.render_template('template_filter.html', value='abcd')
    rv = app.test_client().get('/')
    assert rv.data == b'dcba'
def test_add_template_filter_with_name_and_template():
    bp = flask.Blueprint('bp', __name__)
    def my_reverse(s):
        return s[::-1]
    bp.add_app_template_filter(my_reverse, 'super_reverse')
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    @app.route('/')
    def index():
        return flask.render_template('template_filter.html', value='abcd')
    rv = app.test_client().get('/')
    assert rv.data == b'dcba'
def test_template_test():
    bp = flask.Blueprint('bp', __name__)
    @bp.app_template_test()
    def is_boolean(value):
        return isinstance(value, bool)
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    assert 'is_boolean' in app.jinja_env.tests.keys()
    assert app.jinja_env.tests['is_boolean'] == is_boolean
    assert app.jinja_env.tests['is_boolean'](False)
def test_add_template_test():
    bp = flask.Blueprint('bp', __name__)
    def is_boolean(value):
        return isinstance(value, bool)
    bp.add_app_template_test(is_boolean)
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    assert 'is_boolean' in app.jinja_env.tests.keys()
    assert app.jinja_env.tests['is_boolean'] == is_boolean
    assert app.jinja_env.tests['is_boolean'](False)
def test_template_test_with_name():
    bp = flask.Blueprint('bp', __name__)
    @bp.app_template_test('boolean')
    def is_boolean(value):
        return isinstance(value, bool)
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    assert 'boolean' in app.jinja_env.tests.keys()
    assert app.jinja_env.tests['boolean'] == is_boolean
    assert app.jinja_env.tests['boolean'](False)
def test_add_template_test_with_name():
    bp = flask.Blueprint('bp', __name__)
    def is_boolean(value):
        return isinstance(value, bool)
    bp.add_app_template_test(is_boolean, 'boolean')
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    assert 'boolean' in app.jinja_env.tests.keys()
    assert app.jinja_env.tests['boolean'] == is_boolean
    assert app.jinja_env.tests['boolean'](False)
def test_template_test_with_template():
    bp = flask.Blueprint('bp', __name__)
    @bp.app_template_test()
    def boolean(value):
        return isinstance(value, bool)
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    @app.route('/')
    def index():
        return flask.render_template('template_test.html', value=False)
    rv = app.test_client().get('/')
    assert b'Success!' in rv.data
def test_template_test_after_route_with_template():
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return flask.render_template('template_test.html', value=False)
    bp = flask.Blueprint('bp', __name__)
    @bp.app_template_test()
    def boolean(value):
        return isinstance(value, bool)
    app.register_blueprint(bp, url_prefix='/py')
    rv = app.test_client().get('/')
    assert b'Success!' in rv.data
def test_add_template_test_with_template():
    bp = flask.Blueprint('bp', __name__)
    def boolean(value):
        return isinstance(value, bool)
    bp.add_app_template_test(boolean)
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    @app.route('/')
    def index():
        return flask.render_template('template_test.html', value=False)
    rv = app.test_client().get('/')
    assert b'Success!' in rv.data
def test_template_test_with_name_and_template():
    bp = flask.Blueprint('bp', __name__)
    @bp.app_template_test('boolean')
    def is_boolean(value):
        return isinstance(value, bool)
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    @app.route('/')
    def index():
        return flask.render_template('template_test.html', value=False)
    rv = app.test_client().get('/')
    assert b'Success!' in rv.data
def test_add_template_test_with_name_and_template():
    bp = flask.Blueprint('bp', __name__)
    def is_boolean(value):
        return isinstance(value, bool)
    bp.add_app_template_test(is_boolean, 'boolean')
    app = flask.Flask(__name__)
    app.register_blueprint(bp, url_prefix='/py')
    @app.route('/')
    def index():
        return flask.render_template('template_test.html', value=False)
    rv = app.test_client().get('/')
    assert b'Success!' in rv.data
from __future__ import absolute_import, print_function
import os
import sys
import click
import pytest
from click.testing import CliRunner
from flask import Flask, current_app
from flask.cli import AppGroup, FlaskGroup, NoAppException, ScriptInfo, \
    find_best_app, locate_app, with_appcontext, prepare_exec_for_file, \
    find_default_import_path
def test_cli_name(test_apps):
    
    from cliapp.app import testapp
    assert testapp.cli.name == testapp.name
def test_find_best_app(test_apps):
    
    class Module:
        app = Flask('appname')
    assert find_best_app(Module) == Module.app
    class Module:
        application = Flask('appname')
    assert find_best_app(Module) == Module.application
    class Module:
        myapp = Flask('appname')
    assert find_best_app(Module) == Module.myapp
    class Module:
        pass
    pytest.raises(NoAppException, find_best_app, Module)
    class Module:
        myapp1 = Flask('appname1')
        myapp2 = Flask('appname2')
    pytest.raises(NoAppException, find_best_app, Module)
def test_prepare_exec_for_file(test_apps):
    
    realpath = os.path.realpath('/tmp/share/test.py')
    dirname = os.path.dirname(realpath)
    assert prepare_exec_for_file('/tmp/share/test.py') == 'test'
    assert dirname in sys.path
    realpath = os.path.realpath('/tmp/share/__init__.py')
    dirname = os.path.dirname(os.path.dirname(realpath))
    assert prepare_exec_for_file('/tmp/share/__init__.py') == 'share'
    assert dirname in sys.path
    with pytest.raises(NoAppException):
        prepare_exec_for_file('/tmp/share/test.txt')
def test_locate_app(test_apps):
    
    assert locate_app("cliapp.app").name == "testapp"
    assert locate_app("cliapp.app:testapp").name == "testapp"
    assert locate_app("cliapp.multiapp:app1").name == "app1"
    pytest.raises(RuntimeError, locate_app, "cliapp.app:notanapp")
def test_find_default_import_path(test_apps, monkeypatch, tmpdir):
    
    monkeypatch.delitem(os.environ, 'FLASK_APP', raising=False)
    assert find_default_import_path() == None
    monkeypatch.setitem(os.environ, 'FLASK_APP', 'notanapp')
    assert find_default_import_path() == 'notanapp'
    tmpfile = tmpdir.join('testapp.py')
    tmpfile.write('')
    monkeypatch.setitem(os.environ, 'FLASK_APP', str(tmpfile))
    expect_rv = prepare_exec_for_file(str(tmpfile))
    assert find_default_import_path() == expect_rv
def test_scriptinfo(test_apps):
    
    obj = ScriptInfo(app_import_path="cliapp.app:testapp")
    assert obj.load_app().name == "testapp"
    assert obj.load_app().name == "testapp"
    def create_app(info):
        return Flask("createapp")
    obj = ScriptInfo(create_app=create_app)
    app = obj.load_app()
    assert app.name == "createapp"
    assert obj.load_app() == app
def test_with_appcontext():
    
    @click.command()
    @with_appcontext
    def testcmd():
        click.echo(current_app.name)
    obj = ScriptInfo(create_app=lambda info: Flask("testapp"))
    runner = CliRunner()
    result = runner.invoke(testcmd, obj=obj)
    assert result.exit_code == 0
    assert result.output == 'testapp\n'
def test_appgroup():
    
    @click.group(cls=AppGroup)
    def cli():
        pass
    @cli.command(with_appcontext=True)
    def test():
        click.echo(current_app.name)
    @cli.group()
    def subgroup():
        pass
    @subgroup.command(with_appcontext=True)
    def test2():
        click.echo(current_app.name)
    obj = ScriptInfo(create_app=lambda info: Flask("testappgroup"))
    runner = CliRunner()
    result = runner.invoke(cli, ['test'], obj=obj)
    assert result.exit_code == 0
    assert result.output == 'testappgroup\n'
    result = runner.invoke(cli, ['subgroup', 'test2'], obj=obj)
    assert result.exit_code == 0
    assert result.output == 'testappgroup\n'
def test_flaskgroup():
    
    def create_app(info):
        return Flask("flaskgroup")
    @click.group(cls=FlaskGroup, create_app=create_app)
    def cli(**params):
        pass
    @cli.command()
    def test():
        click.echo(current_app.name)
    runner = CliRunner()
    result = runner.invoke(cli, ['test'])
    assert result.exit_code == 0
    assert result.output == 'flaskgroup\n'
import pytest
import os
from datetime import timedelta
import flask
TEST_KEY = 'foo'
SECRET_KEY = 'devkey'
def common_object_test(app):
    assert app.secret_key == 'devkey'
    assert app.config['TEST_KEY'] == 'foo'
    assert 'TestConfig' not in app.config
def test_config_from_file():
    app = flask.Flask(__name__)
    app.config.from_pyfile(__file__.rsplit('.', 1)[0] + '.py')
    common_object_test(app)
def test_config_from_object():
    app = flask.Flask(__name__)
    app.config.from_object(__name__)
    common_object_test(app)
def test_config_from_json():
    app = flask.Flask(__name__)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app.config.from_json(os.path.join(current_dir, 'static', 'config.json'))
    common_object_test(app)
def test_config_from_mapping():
    app = flask.Flask(__name__)
    app.config.from_mapping({
        'SECRET_KEY': 'devkey',
        'TEST_KEY': 'foo'
    })
    common_object_test(app)
    app = flask.Flask(__name__)
    app.config.from_mapping([
        ('SECRET_KEY', 'devkey'),
        ('TEST_KEY', 'foo')
    ])
    common_object_test(app)
    app = flask.Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY='devkey',
        TEST_KEY='foo'
    )
    common_object_test(app)
    app = flask.Flask(__name__)
    with pytest.raises(TypeError):
        app.config.from_mapping(
            {}, {}
        )
def test_config_from_class():
    class Base(object):
        TEST_KEY = 'foo'
    class Test(Base):
        SECRET_KEY = 'devkey'
    app = flask.Flask(__name__)
    app.config.from_object(Test)
    common_object_test(app)
def test_config_from_envvar():
    env = os.environ
    try:
        os.environ = {}
        app = flask.Flask(__name__)
        with pytest.raises(RuntimeError) as e:
            app.config.from_envvar('FOO_SETTINGS')
        assert "'FOO_SETTINGS' is not set" in str(e.value)
        assert not app.config.from_envvar('FOO_SETTINGS', silent=True)
        os.environ = {'FOO_SETTINGS': __file__.rsplit('.', 1)[0] + '.py'}
        assert app.config.from_envvar('FOO_SETTINGS')
        common_object_test(app)
    finally:
        os.environ = env
def test_config_from_envvar_missing():
    env = os.environ
    try:
        os.environ = {'FOO_SETTINGS': 'missing.cfg'}
        with pytest.raises(IOError) as e:
            app = flask.Flask(__name__)
            app.config.from_envvar('FOO_SETTINGS')
        msg = str(e.value)
        assert msg.startswith('[Errno 2] Unable to load configuration '
                              'file (No such file or directory):')
        assert msg.endswith("missing.cfg'")
        assert not app.config.from_envvar('FOO_SETTINGS', silent=True)
    finally:
        os.environ = env
def test_config_missing():
    app = flask.Flask(__name__)
    with pytest.raises(IOError) as e:
        app.config.from_pyfile('missing.cfg')
    msg = str(e.value)
    assert msg.startswith('[Errno 2] Unable to load configuration '
                          'file (No such file or directory):')
    assert msg.endswith("missing.cfg'")
    assert not app.config.from_pyfile('missing.cfg', silent=True)
def test_config_missing_json():
    app = flask.Flask(__name__)
    with pytest.raises(IOError) as e:
        app.config.from_json('missing.json')
    msg = str(e.value)
    assert msg.startswith('[Errno 2] Unable to load configuration '
                          'file (No such file or directory):')
    assert msg.endswith("missing.json'")
    assert not app.config.from_json('missing.json', silent=True)
def test_custom_config_class():
    class Config(flask.Config):
        pass
    class Flask(flask.Flask):
        config_class = Config
    app = Flask(__name__)
    assert isinstance(app.config, Config)
    app.config.from_object(__name__)
    common_object_test(app)
def test_session_lifetime():
    app = flask.Flask(__name__)
    app.config['PERMANENT_SESSION_LIFETIME'] = 42
    assert app.permanent_session_lifetime.seconds == 42
def test_send_file_max_age():
    app = flask.Flask(__name__)
    app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 3600
    assert app.send_file_max_age_default.seconds == 3600
    app.config['SEND_FILE_MAX_AGE_DEFAULT'] = timedelta(hours=2)
    assert app.send_file_max_age_default.seconds == 7200
def test_get_namespace():
    app = flask.Flask(__name__)
    app.config['FOO_OPTION_1'] = 'foo option 1'
    app.config['FOO_OPTION_2'] = 'foo option 2'
    app.config['BAR_STUFF_1'] = 'bar stuff 1'
    app.config['BAR_STUFF_2'] = 'bar stuff 2'
    foo_options = app.config.get_namespace('FOO_')
    assert 2 == len(foo_options)
    assert 'foo option 1' == foo_options['option_1']
    assert 'foo option 2' == foo_options['option_2']
    bar_options = app.config.get_namespace('BAR_', lowercase=False)
    assert 2 == len(bar_options)
    assert 'bar stuff 1' == bar_options['STUFF_1']
    assert 'bar stuff 2' == bar_options['STUFF_2']
    foo_options = app.config.get_namespace('FOO_', trim_namespace=False)
    assert 2 == len(foo_options)
    assert 'foo option 1' == foo_options['foo_option_1']
    assert 'foo option 2' == foo_options['foo_option_2']
    bar_options = app.config.get_namespace('BAR_', lowercase=False, trim_namespace=False)
    assert 2 == len(bar_options)
    assert 'bar stuff 1' == bar_options['BAR_STUFF_1']
    assert 'bar stuff 2' == bar_options['BAR_STUFF_2']
import pytest
import flask
class TestRequestDeprecation(object):
    def test_request_json(self, recwarn):
        
        app = flask.Flask(__name__)
        app.testing = True
        @app.route('/', methods=['POST'])
        def index():
            assert flask.request.json == {'spam': 42}
            print(flask.request.json)
            return 'OK'
        c = app.test_client()
        c.post('/', data='{"spam": 42}', content_type='application/json')
        recwarn.pop(DeprecationWarning)
    def test_request_module(self, recwarn):
        
        app = flask.Flask(__name__)
        app.testing = True
        @app.route('/')
        def index():
            assert flask.request.module is None
            return 'OK'
        c = app.test_client()
        c.get('/')
        recwarn.pop(DeprecationWarning)
import sys
import pytest
try:
    from imp import reload as reload_module
except ImportError:
    reload_module = reload
from flask._compat import PY2
@pytest.fixture(autouse=True)
def disable_extwarnings(request, recwarn):
    from flask.exthook import ExtDeprecationWarning
    def inner():
        assert set(w.category for w in recwarn.list) \
            <= set([ExtDeprecationWarning])
        recwarn.clear()
    request.addfinalizer(inner)
@pytest.fixture(autouse=True)
def importhook_setup(monkeypatch, request):
    for entry, value in list(sys.modules.items()):
        if (
            entry.startswith('flask.ext.') or
            entry.startswith('flask_') or
            entry.startswith('flaskext.') or
            entry == 'flaskext'
        ) and value is not None:
            monkeypatch.delitem(sys.modules, entry)
    from flask import ext
    reload_module(ext)
    import_hooks = 0
    for item in sys.meta_path:
        cls = type(item)
        if cls.__module__ == 'flask.exthook' and \
           cls.__name__ == 'ExtensionImporter':
            import_hooks += 1
    assert import_hooks == 1
    def teardown():
        from flask import ext
        for key in ext.__dict__:
            assert '.' not in key
    request.addfinalizer(teardown)
@pytest.fixture
def newext_simple(modules_tmpdir):
    x = modules_tmpdir.join('flask_newext_simple.py')
    x.write('ext_id = "newext_simple"')
@pytest.fixture
def oldext_simple(modules_tmpdir):
    flaskext = modules_tmpdir.mkdir('flaskext')
    flaskext.join('__init__.py').write('\n')
    flaskext.join('oldext_simple.py').write('ext_id = "oldext_simple"')
@pytest.fixture
def newext_package(modules_tmpdir):
    pkg = modules_tmpdir.mkdir('flask_newext_package')
    pkg.join('__init__.py').write('ext_id = "newext_package"')
    pkg.join('submodule.py').write('def test_function():\n    return 42\n')
@pytest.fixture
def oldext_package(modules_tmpdir):
    flaskext = modules_tmpdir.mkdir('flaskext')
    flaskext.join('__init__.py').write('\n')
    oldext = flaskext.mkdir('oldext_package')
    oldext.join('__init__.py').write('ext_id = "oldext_package"')
    oldext.join('submodule.py').write('def test_function():\n'
                                      '    return 42')
@pytest.fixture
def flaskext_broken(modules_tmpdir):
    ext = modules_tmpdir.mkdir('flask_broken')
    ext.join('b.py').write('\n')
    ext.join('__init__.py').write('import flask.ext.broken.b\n'
                                  'import missing_module')
def test_flaskext_new_simple_import_normal(newext_simple):
    from flask.ext.newext_simple import ext_id
    assert ext_id == 'newext_simple'
def test_flaskext_new_simple_import_module(newext_simple):
    from flask.ext import newext_simple
    assert newext_simple.ext_id == 'newext_simple'
    assert newext_simple.__name__ == 'flask_newext_simple'
def test_flaskext_new_package_import_normal(newext_package):
    from flask.ext.newext_package import ext_id
    assert ext_id == 'newext_package'
def test_flaskext_new_package_import_module(newext_package):
    from flask.ext import newext_package
    assert newext_package.ext_id == 'newext_package'
    assert newext_package.__name__ == 'flask_newext_package'
def test_flaskext_new_package_import_submodule_function(newext_package):
    from flask.ext.newext_package.submodule import test_function
    assert test_function() == 42
def test_flaskext_new_package_import_submodule(newext_package):
    from flask.ext.newext_package import submodule
    assert submodule.__name__ == 'flask_newext_package.submodule'
    assert submodule.test_function() == 42
def test_flaskext_old_simple_import_normal(oldext_simple):
    from flask.ext.oldext_simple import ext_id
    assert ext_id == 'oldext_simple'
def test_flaskext_old_simple_import_module(oldext_simple):
    from flask.ext import oldext_simple
    assert oldext_simple.ext_id == 'oldext_simple'
    assert oldext_simple.__name__ == 'flaskext.oldext_simple'
def test_flaskext_old_package_import_normal(oldext_package):
    from flask.ext.oldext_package import ext_id
    assert ext_id == 'oldext_package'
def test_flaskext_old_package_import_module(oldext_package):
    from flask.ext import oldext_package
    assert oldext_package.ext_id == 'oldext_package'
    assert oldext_package.__name__ == 'flaskext.oldext_package'
def test_flaskext_old_package_import_submodule(oldext_package):
    from flask.ext.oldext_package import submodule
    assert submodule.__name__ == 'flaskext.oldext_package.submodule'
    assert submodule.test_function() == 42
def test_flaskext_old_package_import_submodule_function(oldext_package):
    from flask.ext.oldext_package.submodule import test_function
    assert test_function() == 42
def test_flaskext_broken_package_no_module_caching(flaskext_broken):
    for x in range(2):
        with pytest.raises(ImportError):
            import flask.ext.broken
def test_no_error_swallowing(flaskext_broken):
    with pytest.raises(ImportError) as excinfo:
        import flask.ext.broken
    assert excinfo.type is ImportError
    if PY2:
        message = 'No module named missing_module'
    else:
        message = 'No module named \'missing_module\''
    assert str(excinfo.value) == message
    assert excinfo.tb.tb_frame.f_globals is globals()
    next = excinfo.tb.tb_next.tb_next
    if not PY2:
        next = next.tb_next
    import os.path
    assert os.path.join('flask_broken', '__init__.py') in \
        next.tb_frame.f_code.co_filename
import pytest
import os
import datetime
import flask
from logging import StreamHandler
from werkzeug.exceptions import BadRequest, NotFound
from werkzeug.http import parse_cache_control_header, parse_options_header
from werkzeug.http import http_date
from flask._compat import StringIO, text_type, PY2
def has_encoding(name):
    try:
        import codecs
        codecs.lookup(name)
        return True
    except LookupError:
        return False
class TestJSON(object):
    def test_post_empty_json_adds_exception_to_response_content_in_debug(self):
        app = flask.Flask(__name__)
        app.config['DEBUG'] = True
        @app.route('/json', methods=['POST'])
        def post_json():
            flask.request.get_json()
            return None
        c = app.test_client()
        rv = c.post('/json', data=None, content_type='application/json')
        assert rv.status_code == 400
        assert b'Failed to decode JSON object' in rv.data
    def test_post_empty_json_wont_add_exception_to_response_if_no_debug(self):
        app = flask.Flask(__name__)
        app.config['DEBUG'] = False
        @app.route('/json', methods=['POST'])
        def post_json():
            flask.request.get_json()
            return None
        c = app.test_client()
        rv = c.post('/json', data=None, content_type='application/json')
        assert rv.status_code == 400
        assert b'Failed to decode JSON object' not in rv.data
    def test_json_bad_requests(self):
        app = flask.Flask(__name__)
        @app.route('/json', methods=['POST'])
        def return_json():
            return flask.jsonify(foo=text_type(flask.request.get_json()))
        c = app.test_client()
        rv = c.post('/json', data='malformed', content_type='application/json')
        assert rv.status_code == 400
    def test_json_custom_mimetypes(self):
        app = flask.Flask(__name__)
        @app.route('/json', methods=['POST'])
        def return_json():
            return flask.request.get_json()
        c = app.test_client()
        rv = c.post('/json', data='"foo"', content_type='application/x+json')
        assert rv.data == b'foo'
    def test_json_body_encoding(self):
        app = flask.Flask(__name__)
        app.testing = True
        @app.route('/')
        def index():
            return flask.request.get_json()
        c = app.test_client()
        resp = c.get('/', data=u'"Hällo Wörld"'.encode('iso-8859-15'),
                     content_type='application/json; charset=iso-8859-15')
        assert resp.data == u'Hällo Wörld'.encode('utf-8')
    def test_json_as_unicode(self):
        app = flask.Flask(__name__)
        app.config['JSON_AS_ASCII'] = True
        with app.app_context():
            rv = flask.json.dumps(u'\N{SNOWMAN}')
            assert rv == '"\\u2603"'
        app.config['JSON_AS_ASCII'] = False
        with app.app_context():
            rv = flask.json.dumps(u'\N{SNOWMAN}')
            assert rv == u'"\u2603"'
    def test_jsonify_basic_types(self):
        
        test_data = (0, 1, 23, 3.14, 's', "longer string", True, False,)
        app = flask.Flask(__name__)
        c = app.test_client()
        for i, d in enumerate(test_data):
            url = '/jsonify_basic_types{0}'.format(i)
            app.add_url_rule(url, str(i), lambda x=d: flask.jsonify(x))
            rv = c.get(url)
            assert rv.mimetype == 'application/json'
            assert flask.json.loads(rv.data) == d
    def test_jsonify_dicts(self):
        
        d = dict(
            a=0, b=23, c=3.14, d='t', e='Hi', f=True, g=False,
            h=['test list', 10, False],
            i={'test':'dict'}
        )
        app = flask.Flask(__name__)
        @app.route('/kw')
        def return_kwargs():
            return flask.jsonify(**d)
        @app.route('/dict')
        def return_dict():
            return flask.jsonify(d)
        c = app.test_client()
        for url in '/kw', '/dict':
            rv = c.get(url)
            assert rv.mimetype == 'application/json'
            assert flask.json.loads(rv.data) == d
    def test_jsonify_arrays(self):
        
        l = [
            0, 42, 3.14, 't', 'hello', True, False,
            ['test list', 2, False],
            {'test':'dict'}
        ]
        app = flask.Flask(__name__)
        @app.route('/args_unpack')
        def return_args_unpack():
            return flask.jsonify(*l)
        @app.route('/array')
        def return_array():
            return flask.jsonify(l)
        c = app.test_client()
        for url in '/args_unpack', '/array':
            rv = c.get(url)
            assert rv.mimetype == 'application/json'
            assert flask.json.loads(rv.data) == l
    def test_jsonify_date_types(self):
        
        test_dates = (
            datetime.datetime(1973, 3, 11, 6, 30, 45),
            datetime.date(1975, 1, 5)
        )
        app = flask.Flask(__name__)
        c = app.test_client()
        for i, d in enumerate(test_dates):
            url = '/datetest{0}'.format(i)
            app.add_url_rule(url, str(i), lambda val=d: flask.jsonify(x=val))
            rv = c.get(url)
            assert rv.mimetype == 'application/json'
            assert flask.json.loads(rv.data)['x'] == http_date(d.timetuple())
    def test_json_attr(self):
        app = flask.Flask(__name__)
        @app.route('/add', methods=['POST'])
        def add():
            json = flask.request.get_json()
            return text_type(json['a'] + json['b'])
        c = app.test_client()
        rv = c.post('/add', data=flask.json.dumps({'a': 1, 'b': 2}),
                            content_type='application/json')
        assert rv.data == b'3'
    def test_template_escaping(self):
        app = flask.Flask(__name__)
        render = flask.render_template_string
        with app.test_request_context():
            rv = flask.json.htmlsafe_dumps('</script>')
            assert rv == u'"\\u003c/script\\u003e"'
            assert type(rv) == text_type
            rv = render('{{ "</script>"|tojson }}')
            assert rv == '"\\u003c/script\\u003e"'
            rv = render('{{ "<\0/script>"|tojson }}')
            assert rv == '"\\u003c\\u0000/script\\u003e"'
            rv = render('{{ "<!--<script>"|tojson }}')
            assert rv == '"\\u003c!--\\u003cscript\\u003e"'
            rv = render('{{ "&"|tojson }}')
            assert rv == '"\\u0026"'
            rv = render('{{ "\'"|tojson }}')
            assert rv == '"\\u0027"'
            rv = render("<a ng-data='{{ data|tojson }}'></a>",
                data={'x': ["foo", "bar", "baz'"]})
            assert rv == '<a ng-data=\'{"x": ["foo", "bar", "baz\\u0027"]}\'></a>'
    def test_json_customization(self):
        class X(object):
            def __init__(self, val):
                self.val = val
        class MyEncoder(flask.json.JSONEncoder):
            def default(self, o):
                if isinstance(o, X):
                    return '<%d>' % o.val
                return flask.json.JSONEncoder.default(self, o)
        class MyDecoder(flask.json.JSONDecoder):
            def __init__(self, *args, **kwargs):
                kwargs.setdefault('object_hook', self.object_hook)
                flask.json.JSONDecoder.__init__(self, *args, **kwargs)
            def object_hook(self, obj):
                if len(obj) == 1 and '_foo' in obj:
                    return X(obj['_foo'])
                return obj
        app = flask.Flask(__name__)
        app.testing = True
        app.json_encoder = MyEncoder
        app.json_decoder = MyDecoder
        @app.route('/', methods=['POST'])
        def index():
            return flask.json.dumps(flask.request.get_json()['x'])
        c = app.test_client()
        rv = c.post('/', data=flask.json.dumps({
            'x': {'_foo': 42}
        }), content_type='application/json')
        assert rv.data == b'"<42>"'
    def test_modified_url_encoding(self):
        class ModifiedRequest(flask.Request):
            url_charset = 'euc-kr'
        app = flask.Flask(__name__)
        app.testing = True
        app.request_class = ModifiedRequest
        app.url_map.charset = 'euc-kr'
        @app.route('/')
        def index():
            return flask.request.args['foo']
        rv = app.test_client().get(u'/?foo=정상처리'.encode('euc-kr'))
        assert rv.status_code == 200
        assert rv.data == u'정상처리'.encode('utf-8')
    if not has_encoding('euc-kr'):
        test_modified_url_encoding = None
    def test_json_key_sorting(self):
        app = flask.Flask(__name__)
        app.testing = True
        assert app.config['JSON_SORT_KEYS'] == True
        d = dict.fromkeys(range(20), 'foo')
        @app.route('/')
        def index():
            return flask.jsonify(values=d)
        c = app.test_client()
        rv = c.get('/')
        lines = [x.strip() for x in rv.data.strip().decode('utf-8').splitlines()]
        sorted_by_str = [
            '{',
            '"values": {',
            '"0": "foo",',
            '"1": "foo",',
            '"10": "foo",',
            '"11": "foo",',
            '"12": "foo",',
            '"13": "foo",',
            '"14": "foo",',
            '"15": "foo",',
            '"16": "foo",',
            '"17": "foo",',
            '"18": "foo",',
            '"19": "foo",',
            '"2": "foo",',
            '"3": "foo",',
            '"4": "foo",',
            '"5": "foo",',
            '"6": "foo",',
            '"7": "foo",',
            '"8": "foo",',
            '"9": "foo"',
            '}',
            '}'
        ]
        sorted_by_int = [
            '{',
            '"values": {',
            '"0": "foo",',
            '"1": "foo",',
            '"2": "foo",',
            '"3": "foo",',
            '"4": "foo",',
            '"5": "foo",',
            '"6": "foo",',
            '"7": "foo",',
            '"8": "foo",',
            '"9": "foo",',
            '"10": "foo",',
            '"11": "foo",',
            '"12": "foo",',
            '"13": "foo",',
            '"14": "foo",',
            '"15": "foo",',
            '"16": "foo",',
            '"17": "foo",',
            '"18": "foo",',
            '"19": "foo"',
            '}',
            '}'
        ]
        try:
            assert lines == sorted_by_int
        except AssertionError:
            assert lines == sorted_by_str
class TestSendfile(object):
    def test_send_file_regular(self):
        app = flask.Flask(__name__)
        with app.test_request_context():
            rv = flask.send_file('static/index.html')
            assert rv.direct_passthrough
            assert rv.mimetype == 'text/html'
            with app.open_resource('static/index.html') as f:
                rv.direct_passthrough = False
                assert rv.data == f.read()
            rv.close()
    def test_send_file_xsendfile(self, catch_deprecation_warnings):
        app = flask.Flask(__name__)
        app.use_x_sendfile = True
        with app.test_request_context():
            rv = flask.send_file('static/index.html')
            assert rv.direct_passthrough
            assert 'x-sendfile' in rv.headers
            assert rv.headers['x-sendfile'] == \
                os.path.join(app.root_path, 'static/index.html')
            assert rv.mimetype == 'text/html'
            rv.close()
    def test_send_file_last_modified(self):
        app = flask.Flask(__name__)
        last_modified = datetime.datetime(1999, 1, 1)
        @app.route('/')
        def index():
            return flask.send_file(StringIO("party like it's"), last_modified=last_modified)
        c = app.test_client()
        rv = c.get('/')
        assert rv.last_modified == last_modified
    def test_send_file_object(self):
        app = flask.Flask(__name__)
        with app.test_request_context():
            with open(os.path.join(app.root_path, 'static/index.html'), mode='rb') as f:
                rv = flask.send_file(f)
                rv.direct_passthrough = False
                with app.open_resource('static/index.html') as f:
                    assert rv.data == f.read()
                assert rv.mimetype == 'text/html'
                rv.close()
        app.use_x_sendfile = True
        with app.test_request_context():
            with open(os.path.join(app.root_path, 'static/index.html')) as f:
                rv = flask.send_file(f)
                assert rv.mimetype == 'text/html'
                assert 'x-sendfile' in rv.headers
                assert rv.headers['x-sendfile'] == \
                    os.path.join(app.root_path, 'static/index.html')
                rv.close()
        app.use_x_sendfile = False
        with app.test_request_context():
            f = StringIO('Test')
            rv = flask.send_file(f)
            rv.direct_passthrough = False
            assert rv.data == b'Test'
            assert rv.mimetype == 'application/octet-stream'
            rv.close()
            class PyStringIO(object):
                def __init__(self, *args, **kwargs):
                    self._io = StringIO(*args, **kwargs)
                def __getattr__(self, name):
                    return getattr(self._io, name)
            f = PyStringIO('Test')
            f.name = 'test.txt'
            rv = flask.send_file(f)
            rv.direct_passthrough = False
            assert rv.data == b'Test'
            assert rv.mimetype == 'text/plain'
            rv.close()
            f = StringIO('Test')
            rv = flask.send_file(f, mimetype='text/plain')
            rv.direct_passthrough = False
            assert rv.data == b'Test'
            assert rv.mimetype == 'text/plain'
            rv.close()
        app.use_x_sendfile = True
        with app.test_request_context():
            f = StringIO('Test')
            rv = flask.send_file(f)
            assert 'x-sendfile' not in rv.headers
            rv.close()
    def test_attachment(self):
        app = flask.Flask(__name__)
        with app.test_request_context():
            with open(os.path.join(app.root_path, 'static/index.html')) as f:
                rv = flask.send_file(f, as_attachment=True)
                value, options = \
                    parse_options_header(rv.headers['Content-Disposition'])
                assert value == 'attachment'
                rv.close()
        with app.test_request_context():
            assert options['filename'] == 'index.html'
            rv = flask.send_file('static/index.html', as_attachment=True)
            value, options = parse_options_header(rv.headers['Content-Disposition'])
            assert value == 'attachment'
            assert options['filename'] == 'index.html'
            rv.close()
        with app.test_request_context():
            rv = flask.send_file(StringIO('Test'), as_attachment=True,
                                 attachment_filename='index.txt',
                                 add_etags=False)
            assert rv.mimetype == 'text/plain'
            value, options = parse_options_header(rv.headers['Content-Disposition'])
            assert value == 'attachment'
            assert options['filename'] == 'index.txt'
            rv.close()
    def test_static_file(self):
        app = flask.Flask(__name__)
        with app.test_request_context():
            rv = app.send_static_file('index.html')
            cc = parse_cache_control_header(rv.headers['Cache-Control'])
            assert cc.max_age == 12 * 60 * 60
            rv.close()
            rv = flask.send_file('static/index.html')
            cc = parse_cache_control_header(rv.headers['Cache-Control'])
            assert cc.max_age == 12 * 60 * 60
            rv.close()
        app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 3600
        with app.test_request_context():
            rv = app.send_static_file('index.html')
            cc = parse_cache_control_header(rv.headers['Cache-Control'])
            assert cc.max_age == 3600
            rv.close()
            rv = flask.send_file('static/index.html')
            cc = parse_cache_control_header(rv.headers['Cache-Control'])
            assert cc.max_age == 3600
            rv.close()
        class StaticFileApp(flask.Flask):
            def get_send_file_max_age(self, filename):
                return 10
        app = StaticFileApp(__name__)
        with app.test_request_context():
            rv = app.send_static_file('index.html')
            cc = parse_cache_control_header(rv.headers['Cache-Control'])
            assert cc.max_age == 10
            rv.close()
            rv = flask.send_file('static/index.html')
            cc = parse_cache_control_header(rv.headers['Cache-Control'])
            assert cc.max_age == 10
            rv.close()
    def test_send_from_directory(self):
        app = flask.Flask(__name__)
        app.testing = True
        app.root_path = os.path.join(os.path.dirname(__file__),
                                     'test_apps', 'subdomaintestmodule')
        with app.test_request_context():
            rv = flask.send_from_directory('static', 'hello.txt')
            rv.direct_passthrough = False
            assert rv.data.strip() == b'Hello Subdomain'
            rv.close()
    def test_send_from_directory_bad_request(self):
        app = flask.Flask(__name__)
        app.testing = True
        app.root_path = os.path.join(os.path.dirname(__file__),
                                     'test_apps', 'subdomaintestmodule')
        with app.test_request_context():
            with pytest.raises(BadRequest):
                flask.send_from_directory('static', 'bad\x00')
class TestLogging(object):
    def test_logger_cache(self):
        app = flask.Flask(__name__)
        logger1 = app.logger
        assert app.logger is logger1
        assert logger1.name == __name__
        app.logger_name = __name__ + '/test_logger_cache'
        assert app.logger is not logger1
    def test_debug_log(self, capsys):
        app = flask.Flask(__name__)
        app.debug = True
        @app.route('/')
        def index():
            app.logger.warning('the standard library is dead')
            app.logger.debug('this is a debug statement')
            return ''
        @app.route('/exc')
        def exc():
            1 // 0
        with app.test_client() as c:
            c.get('/')
            out, err = capsys.readouterr()
            assert 'WARNING in test_helpers [' in err
            assert os.path.basename(__file__.rsplit('.', 1)[0] + '.py') in err
            assert 'the standard library is dead' in err
            assert 'this is a debug statement' in err
            with pytest.raises(ZeroDivisionError):
                c.get('/exc')
    def test_debug_log_override(self):
        app = flask.Flask(__name__)
        app.debug = True
        app.logger_name = 'flask_tests/test_debug_log_override'
        app.logger.level = 10
        assert app.logger.level == 10
    def test_exception_logging(self):
        out = StringIO()
        app = flask.Flask(__name__)
        app.config['LOGGER_HANDLER_POLICY'] = 'never'
        app.logger_name = 'flask_tests/test_exception_logging'
        app.logger.addHandler(StreamHandler(out))
        @app.route('/')
        def index():
            1 // 0
        rv = app.test_client().get('/')
        assert rv.status_code == 500
        assert b'Internal Server Error' in rv.data
        err = out.getvalue()
        assert 'Exception on / [GET]' in err
        assert 'Traceback (most recent call last):' in err
        assert '1 // 0' in err
        assert 'ZeroDivisionError:' in err
    def test_processor_exceptions(self):
        app = flask.Flask(__name__)
        app.config['LOGGER_HANDLER_POLICY'] = 'never'
        @app.before_request
        def before_request():
            if trigger == 'before':
                1 // 0
        @app.after_request
        def after_request(response):
            if trigger == 'after':
                1 // 0
            return response
        @app.route('/')
        def index():
            return 'Foo'
        @app.errorhandler(500)
        def internal_server_error(e):
            return 'Hello Server Error', 500
        for trigger in 'before', 'after':
            rv = app.test_client().get('/')
            assert rv.status_code == 500
            assert rv.data == b'Hello Server Error'
    def test_url_for_with_anchor(self):
        app = flask.Flask(__name__)
        @app.route('/')
        def index():
            return '42'
        with app.test_request_context():
            assert flask.url_for('index', _anchor='x y') == '/#x%20y'
    def test_url_for_with_scheme(self):
        app = flask.Flask(__name__)
        @app.route('/')
        def index():
            return '42'
        with app.test_request_context():
            assert flask.url_for('index', _external=True, _scheme='https') == 'https://localhost/'
    def test_url_for_with_scheme_not_external(self):
        app = flask.Flask(__name__)
        @app.route('/')
        def index():
            return '42'
        with app.test_request_context():
            pytest.raises(ValueError,
                               flask.url_for,
                               'index',
                               _scheme='https')
    def test_url_for_with_alternating_schemes(self):
        app = flask.Flask(__name__)
        @app.route('/')
        def index():
            return '42'
        with app.test_request_context():
            assert flask.url_for('index', _external=True) == 'http://localhost/'
            assert flask.url_for('index', _external=True, _scheme='https') == 'https://localhost/'
            assert flask.url_for('index', _external=True) == 'http://localhost/'
    def test_url_with_method(self):
        from flask.views import MethodView
        app = flask.Flask(__name__)
        class MyView(MethodView):
            def get(self, id=None):
                if id is None:
                    return 'List'
                return 'Get %d' % id
            def post(self):
                return 'Create'
        myview = MyView.as_view('myview')
        app.add_url_rule('/myview/', methods=['GET'],
                         view_func=myview)
        app.add_url_rule('/myview/<int:id>', methods=['GET'],
                         view_func=myview)
        app.add_url_rule('/myview/create', methods=['POST'],
                         view_func=myview)
        with app.test_request_context():
            assert flask.url_for('myview', _method='GET') == '/myview/'
            assert flask.url_for('myview', id=42, _method='GET') == '/myview/42'
            assert flask.url_for('myview', _method='POST') == '/myview/create'
class TestNoImports(object):
    
    def test_name_with_import_error(self, modules_tmpdir):
        modules_tmpdir.join('importerror.py').write('raise NotImplementedError()')
        try:
            flask.Flask('importerror')
        except NotImplementedError:
            assert False, 'Flask(import_name) is importing import_name.'
class TestStreaming(object):
    def test_streaming_with_context(self):
        app = flask.Flask(__name__)
        app.testing = True
        @app.route('/')
        def index():
            def generate():
                yield 'Hello '
                yield flask.request.args['name']
                yield '!'
            return flask.Response(flask.stream_with_context(generate()))
        c = app.test_client()
        rv = c.get('/?name=World')
        assert rv.data == b'Hello World!'
    def test_streaming_with_context_as_decorator(self):
        app = flask.Flask(__name__)
        app.testing = True
        @app.route('/')
        def index():
            @flask.stream_with_context
            def generate(hello):
                yield hello
                yield flask.request.args['name']
                yield '!'
            return flask.Response(generate('Hello '))
        c = app.test_client()
        rv = c.get('/?name=World')
        assert rv.data == b'Hello World!'
    def test_streaming_with_context_and_custom_close(self):
        app = flask.Flask(__name__)
        app.testing = True
        called = []
        class Wrapper(object):
            def __init__(self, gen):
                self._gen = gen
            def __iter__(self):
                return self
            def close(self):
                called.append(42)
            def __next__(self):
                return next(self._gen)
            next = __next__
        @app.route('/')
        def index():
            def generate():
                yield 'Hello '
                yield flask.request.args['name']
                yield '!'
            return flask.Response(flask.stream_with_context(
                Wrapper(generate())))
        c = app.test_client()
        rv = c.get('/?name=World')
        assert rv.data == b'Hello World!'
        assert called == [42]
class TestSafeJoin(object):
    def test_safe_join(self):
        passing = (
            (('a/b/c', ), 'a/b/c'),
            (('/', 'a/', 'b/', 'c/', ), '/a/b/c'),
            (('a', 'b', 'c', ), 'a/b/c'),
            (('/a', 'b/c', ), '/a/b/c'),
            (('a/b', 'X/../c'), 'a/b/c', ),
            (('/a/b', 'c/X/..'), '/a/b/c', ),
            (('/a/b/c', '', ), '/a/b/c/', ),
            (('/a/b/c', './', ), '/a/b/c/.', ),
            (('a/b/c', 'X/..'), 'a/b/c/.', ),
            (('../', 'a/b/c'), '../a/b/c'),
            (('/..', ), '/..'),
        )
        for args, expected in passing:
            assert flask.safe_join(*args) == expected
    def test_safe_join_exceptions(self):
        failing = (
            ('/a', 'b', '/c'),
            ('/a', '../b/c', ),
            ('/a', '..', 'b/c'),
            ('/a', 'b/../b/../../c', ),
            ('/a', 'b', 'c/../..'),
            ('/a', 'b/../../c', ),
        )
        for args in failing:
            with pytest.raises(NotFound):
                print(flask.safe_join(*args))
import os
import sys
import pytest
import flask
from flask._compat import PY2
def test_explicit_instance_paths(modules_tmpdir):
    with pytest.raises(ValueError) as excinfo:
        flask.Flask(__name__, instance_path='instance')
    assert 'must be absolute' in str(excinfo.value)
    app = flask.Flask(__name__, instance_path=str(modules_tmpdir))
    assert app.instance_path == str(modules_tmpdir)
def test_main_module_paths(modules_tmpdir, purge_module):
    app = modules_tmpdir.join('main_app.py')
    app.write('import flask\n\napp = flask.Flask("__main__")')
    purge_module('main_app')
    from main_app import app
    here = os.path.abspath(os.getcwd())
    assert app.instance_path == os.path.join(here, 'instance')
def test_uninstalled_module_paths(modules_tmpdir, purge_module):
    app = modules_tmpdir.join('config_module_app.py').write(
        'import os\n'
        'import flask\n'
        'here = os.path.abspath(os.path.dirname(__file__))\n'
        'app = flask.Flask(__name__)\n'
    )
    purge_module('config_module_app')
    from config_module_app import app
    assert app.instance_path == str(modules_tmpdir.join('instance'))
def test_uninstalled_package_paths(modules_tmpdir, purge_module):
    app = modules_tmpdir.mkdir('config_package_app')
    init = app.join('__init__.py')
    init.write(
        'import os\n'
        'import flask\n'
        'here = os.path.abspath(os.path.dirname(__file__))\n'
        'app = flask.Flask(__name__)\n'
    )
    purge_module('config_package_app')
    from config_package_app import app
    assert app.instance_path == str(modules_tmpdir.join('instance'))
def test_installed_module_paths(modules_tmpdir, modules_tmpdir_prefix,
                                purge_module, site_packages, limit_loader):
    site_packages.join('site_app.py').write(
        'import flask\n'
        'app = flask.Flask(__name__)\n'
    )
    purge_module('site_app')
    from site_app import app
    assert app.instance_path == \
        modules_tmpdir.join('var').join('site_app-instance')
def test_installed_package_paths(limit_loader, modules_tmpdir,
                                 modules_tmpdir_prefix, purge_module,
                                 monkeypatch):
    installed_path = modules_tmpdir.mkdir('path')
    monkeypatch.syspath_prepend(installed_path)
    app = installed_path.mkdir('installed_package')
    init = app.join('__init__.py')
    init.write('import flask\napp = flask.Flask(__name__)')
    purge_module('installed_package')
    from installed_package import app
    assert app.instance_path == \
        modules_tmpdir.join('var').join('installed_package-instance')
def test_prefix_package_paths(limit_loader, modules_tmpdir,
                              modules_tmpdir_prefix, purge_module,
                              site_packages):
    app = site_packages.mkdir('site_package')
    init = app.join('__init__.py')
    init.write('import flask\napp = flask.Flask(__name__)')
    purge_module('site_package')
    import site_package
    assert site_package.app.instance_path == \
        modules_tmpdir.join('var').join('site_package-instance')
def test_egg_installed_paths(install_egg, modules_tmpdir,
                             modules_tmpdir_prefix):
    modules_tmpdir.mkdir('site_egg').join('__init__.py').write(
        'import flask\n\napp = flask.Flask(__name__)'
    )
    install_egg('site_egg')
    try:
        import site_egg
        assert site_egg.app.instance_path == \
            str(modules_tmpdir.join('var/').join('site_egg-instance'))
    finally:
        if 'site_egg' in sys.modules:
            del sys.modules['site_egg']
@pytest.mark.skipif(not PY2, reason='This only works under Python 2.')
def test_meta_path_loader_without_is_package(request, modules_tmpdir):
    app = modules_tmpdir.join('unimportable.py')
    app.write('import flask\napp = flask.Flask(__name__)')
    class Loader(object):
        def find_module(self, name, path=None):
            return self
    sys.meta_path.append(Loader())
    request.addfinalizer(sys.meta_path.pop)
    with pytest.raises(AttributeError):
        import unimportable
import pytest
import os
import gc
import sys
import flask
import threading
from werkzeug.exceptions import NotFound
_gc_lock = threading.Lock()
class assert_no_leak(object):
    def __enter__(self):
        gc.disable()
        _gc_lock.acquire()
        loc = flask._request_ctx_stack._local
        loc.__storage__['FOOO'] = [1, 2, 3]
        gc.collect()
        self.old_objects = len(gc.get_objects())
    def __exit__(self, exc_type, exc_value, tb):
        gc.collect()
        new_objects = len(gc.get_objects())
        if new_objects > self.old_objects:
            pytest.fail('Example code leaked')
        _gc_lock.release()
        gc.enable()
def test_memory_consumption():
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return flask.render_template('simple_template.html', whiskey=42)
    def fire():
        with app.test_client() as c:
            rv = c.get('/')
            assert rv.status_code == 200
            assert rv.data == b'<h1>42</h1>'
    fire()
    if sys.version_info >= (2, 7) and \
            not hasattr(sys, 'pypy_translation_info'):
        with assert_no_leak():
            for x in range(10):
                fire()
def test_safe_join_toplevel_pardir():
    from flask.helpers import safe_join
    with pytest.raises(NotFound):
        safe_join('/foo', '..')
def test_aborting():
    class Foo(Exception):
        whatever = 42
    app = flask.Flask(__name__)
    app.testing = True
    @app.errorhandler(Foo)
    def handle_foo(e):
        return str(e.whatever)
    @app.route('/')
    def index():
        raise flask.abort(flask.redirect(flask.url_for('test')))
    @app.route('/test')
    def test():
        raise Foo()
    with app.test_client() as c:
        rv = c.get('/')
        assert rv.headers['Location'] == 'http://localhost/test'
        rv = c.get('/test')
        assert rv.data == b'42'
import pytest
import flask
try:
    from greenlet import greenlet
except ImportError:
    greenlet = None
def test_teardown_on_pop():
    buffer = []
    app = flask.Flask(__name__)
    @app.teardown_request
    def end_of_request(exception):
        buffer.append(exception)
    ctx = app.test_request_context()
    ctx.push()
    assert buffer == []
    ctx.pop()
    assert buffer == [None]
def test_teardown_with_previous_exception():
    buffer = []
    app = flask.Flask(__name__)
    @app.teardown_request
    def end_of_request(exception):
        buffer.append(exception)
    try:
        raise Exception('dummy')
    except Exception:
        pass
    with app.test_request_context():
        assert buffer == []
    assert buffer == [None]
def test_teardown_with_handled_exception():
    buffer = []
    app = flask.Flask(__name__)
    @app.teardown_request
    def end_of_request(exception):
        buffer.append(exception)
    with app.test_request_context():
        assert buffer == []
        try:
            raise Exception('dummy')
        except Exception:
            pass
    assert buffer == [None]
def test_proper_test_request_context():
    app = flask.Flask(__name__)
    app.config.update(
        SERVER_NAME='localhost.localdomain:5000'
    )
    @app.route('/')
    def index():
        return None
    @app.route('/', subdomain='foo')
    def sub():
        return None
    with app.test_request_context('/'):
        assert flask.url_for('index', _external=True) == \
            'http://localhost.localdomain:5000/'
    with app.test_request_context('/'):
        assert flask.url_for('sub', _external=True) == \
            'http://foo.localhost.localdomain:5000/'
    try:
        with app.test_request_context('/', environ_overrides={'HTTP_HOST': 'localhost'}):
            pass
    except ValueError as e:
        assert str(e) == (
            "the server name provided "
            "('localhost.localdomain:5000') does not match the "
            "server name from the WSGI environment ('localhost')"
        )
    app.config.update(SERVER_NAME='localhost')
    with app.test_request_context('/', environ_overrides={'SERVER_NAME': 'localhost'}):
        pass
    app.config.update(SERVER_NAME='localhost:80')
    with app.test_request_context('/', environ_overrides={'SERVER_NAME': 'localhost:80'}):
        pass
def test_context_binding():
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return 'Hello %s!' % flask.request.args['name']
    @app.route('/meh')
    def meh():
        return flask.request.url
    with app.test_request_context('/?name=World'):
        assert index() == 'Hello World!'
    with app.test_request_context('/meh'):
        assert meh() == 'http://localhost/meh'
    assert flask._request_ctx_stack.top is None
def test_context_test():
    app = flask.Flask(__name__)
    assert not flask.request
    assert not flask.has_request_context()
    ctx = app.test_request_context()
    ctx.push()
    try:
        assert flask.request
        assert flask.has_request_context()
    finally:
        ctx.pop()
def test_manual_context_binding():
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return 'Hello %s!' % flask.request.args['name']
    ctx = app.test_request_context('/?name=World')
    ctx.push()
    assert index() == 'Hello World!'
    ctx.pop()
    with pytest.raises(RuntimeError):
        index()
@pytest.mark.skipif(greenlet is None, reason='greenlet not installed')
def test_greenlet_context_copying():
    app = flask.Flask(__name__)
    greenlets = []
    @app.route('/')
    def index():
        reqctx = flask._request_ctx_stack.top.copy()
        def g():
            assert not flask.request
            assert not flask.current_app
            with reqctx:
                assert flask.request
                assert flask.current_app == app
                assert flask.request.path == '/'
                assert flask.request.args['foo'] == 'bar'
            assert not flask.request
            return 42
        greenlets.append(greenlet(g))
        return 'Hello World!'
    rv = app.test_client().get('/?foo=bar')
    assert rv.data == b'Hello World!'
    result = greenlets[0].run()
    assert result == 42
@pytest.mark.skipif(greenlet is None, reason='greenlet not installed')
def test_greenlet_context_copying_api():
    app = flask.Flask(__name__)
    greenlets = []
    @app.route('/')
    def index():
        reqctx = flask._request_ctx_stack.top.copy()
        @flask.copy_current_request_context
        def g():
            assert flask.request
            assert flask.current_app == app
            assert flask.request.path == '/'
            assert flask.request.args['foo'] == 'bar'
            return 42
        greenlets.append(greenlet(g))
        return 'Hello World!'
    rv = app.test_client().get('/?foo=bar')
    assert rv.data == b'Hello World!'
    result = greenlets[0].run()
    assert result == 42
import pytest
try:
    import blinker
except ImportError:
    blinker = None
import flask
pytestmark = pytest.mark.skipif(
    blinker is None,
    reason='Signals require the blinker library.'
)
def test_template_rendered():
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return flask.render_template('simple_template.html', whiskey=42)
    recorded = []
    def record(sender, template, context):
        recorded.append((template, context))
    flask.template_rendered.connect(record, app)
    try:
        app.test_client().get('/')
        assert len(recorded) == 1
        template, context = recorded[0]
        assert template.name == 'simple_template.html'
        assert context['whiskey'] == 42
    finally:
        flask.template_rendered.disconnect(record, app)
def test_before_render_template():
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return flask.render_template('simple_template.html', whiskey=42)
    recorded = []
    def record(sender, template, context):
        context['whiskey'] = 43
        recorded.append((template, context))
    flask.before_render_template.connect(record, app)
    try:
        rv = app.test_client().get('/')
        assert len(recorded) == 1
        template, context = recorded[0]
        assert template.name == 'simple_template.html'
        assert context['whiskey'] == 43
        assert rv.data == b'<h1>43</h1>'
    finally:
        flask.before_render_template.disconnect(record, app)
def test_request_signals():
    app = flask.Flask(__name__)
    calls = []
    def before_request_signal(sender):
        calls.append('before-signal')
    def after_request_signal(sender, response):
        assert response.data == b'stuff'
        calls.append('after-signal')
    @app.before_request
    def before_request_handler():
        calls.append('before-handler')
    @app.after_request
    def after_request_handler(response):
        calls.append('after-handler')
        response.data = 'stuff'
        return response
    @app.route('/')
    def index():
        calls.append('handler')
        return 'ignored anyway'
    flask.request_started.connect(before_request_signal, app)
    flask.request_finished.connect(after_request_signal, app)
    try:
        rv = app.test_client().get('/')
        assert rv.data == b'stuff'
        assert calls == ['before-signal', 'before-handler', 'handler',
                         'after-handler', 'after-signal']
    finally:
        flask.request_started.disconnect(before_request_signal, app)
        flask.request_finished.disconnect(after_request_signal, app)
def test_request_exception_signal():
    app = flask.Flask(__name__)
    recorded = []
    @app.route('/')
    def index():
        1 // 0
    def record(sender, exception):
        recorded.append(exception)
    flask.got_request_exception.connect(record, app)
    try:
        assert app.test_client().get('/').status_code == 500
        assert len(recorded) == 1
        assert isinstance(recorded[0], ZeroDivisionError)
    finally:
        flask.got_request_exception.disconnect(record, app)
def test_appcontext_signals():
    app = flask.Flask(__name__)
    recorded = []
    def record_push(sender, **kwargs):
        recorded.append('push')
    def record_pop(sender, **kwargs):
        recorded.append('pop')
    @app.route('/')
    def index():
        return 'Hello'
    flask.appcontext_pushed.connect(record_push, app)
    flask.appcontext_popped.connect(record_pop, app)
    try:
        with app.test_client() as c:
            rv = c.get('/')
            assert rv.data == b'Hello'
            assert recorded == ['push']
        assert recorded == ['push', 'pop']
    finally:
        flask.appcontext_pushed.disconnect(record_push, app)
        flask.appcontext_popped.disconnect(record_pop, app)
def test_flash_signal():
    app = flask.Flask(__name__)
    app.config['SECRET_KEY'] = 'secret'
    @app.route('/')
    def index():
        flask.flash('This is a flash message', category='notice')
        return flask.redirect('/other')
    recorded = []
    def record(sender, message, category):
        recorded.append((message, category))
    flask.message_flashed.connect(record, app)
    try:
        client = app.test_client()
        with client.session_transaction():
            client.get('/')
            assert len(recorded) == 1
            message, category = recorded[0]
            assert message == 'This is a flash message'
            assert category == 'notice'
    finally:
        flask.message_flashed.disconnect(record, app)
def test_appcontext_tearing_down_signal():
    app = flask.Flask(__name__)
    recorded = []
    def record_teardown(sender, **kwargs):
        recorded.append(('tear_down', kwargs))
    @app.route('/')
    def index():
        1 // 0
    flask.appcontext_tearing_down.connect(record_teardown, app)
    try:
        with app.test_client() as c:
            rv = c.get('/')
            assert rv.status_code == 500
            assert recorded == []
        assert recorded == [('tear_down', {'exc': None})]
    finally:
        flask.appcontext_tearing_down.disconnect(record_teardown, app)
import flask
from logging import StreamHandler
from flask._compat import StringIO
def test_suppressed_exception_logging():
    class SuppressedFlask(flask.Flask):
        def log_exception(self, exc_info):
            pass
    out = StringIO()
    app = SuppressedFlask(__name__)
    app.logger_name = 'flask_tests/test_suppressed_exception_logging'
    app.logger.addHandler(StreamHandler(out))
    @app.route('/')
    def index():
        1 // 0
    rv = app.test_client().get('/')
    assert rv.status_code == 500
    assert b'Internal Server Error' in rv.data
    err = out.getvalue()
    assert err == ''
import pytest
import flask
import logging
from jinja2 import TemplateNotFound
def test_context_processing():
    app = flask.Flask(__name__)
    @app.context_processor
    def context_processor():
        return {'injected_value': 42}
    @app.route('/')
    def index():
        return flask.render_template('context_template.html', value=23)
    rv = app.test_client().get('/')
    assert rv.data == b'<p>23|42'
def test_original_win():
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return flask.render_template_string('{{ config }}', config=42)
    rv = app.test_client().get('/')
    assert rv.data == b'42'
def test_request_less_rendering():
    app = flask.Flask(__name__)
    app.config['WORLD_NAME'] = 'Special World'
    @app.context_processor
    def context_processor():
        return dict(foo=42)
    with app.app_context():
        rv = flask.render_template_string('Hello {{ config.WORLD_NAME }} '
                                          '{{ foo }}')
        assert rv == 'Hello Special World 42'
def test_standard_context():
    app = flask.Flask(__name__)
    app.secret_key = 'development key'
    @app.route('/')
    def index():
        flask.g.foo = 23
        flask.session['test'] = 'aha'
        return flask.render_template_string('''
            {{ request.args.foo }}
            {{ g.foo }}
            {{ config.DEBUG }}
            {{ session.test }}
        ''')
    rv = app.test_client().get('/?foo=42')
    assert rv.data.split() == [b'42', b'23', b'False', b'aha']
def test_escaping():
    text = '<p>Hello World!'
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return flask.render_template('escaping_template.html', text=text,
                                     html=flask.Markup(text))
    lines = app.test_client().get('/').data.splitlines()
    assert lines == [
        b'&lt;p&gt;Hello World!',
        b'<p>Hello World!',
        b'<p>Hello World!',
        b'<p>Hello World!',
        b'&lt;p&gt;Hello World!',
        b'<p>Hello World!'
    ]
def test_no_escaping():
    text = '<p>Hello World!'
    app = flask.Flask(__name__)
    @app.route('/')
    def index():
        return flask.render_template('non_escaping_template.txt', text=text,
                                     html=flask.Markup(text))
    lines = app.test_client().get('/').data.splitlines()
    assert lines == [
        b'<p>Hello World!',
        b'<p>Hello World!',
        b'<p>Hello World!',
        b'<p>Hello World!',
        b'&lt;p&gt;Hello World!',
        b'<p>Hello World!',
        b'<p>Hello World!',
        b'<p>Hello World!'
    ]
def test_escaping_without_template_filename():
    app = flask.Flask(__name__)
    with app.test_request_context():
        assert flask.render_template_string(
            '{{ foo }}', foo='<test>') == '&lt;test&gt;'
        assert flask.render_template('mail.txt', foo='<test>') == \
            '<test> Mail'
def test_macros():
    app = flask.Flask(__name__)
    with app.test_request_context():
        macro = flask.get_template_attribute('_macro.html', 'hello')
        assert macro('World') == 'Hello World!'
def test_template_filter():
    app = flask.Flask(__name__)
    @app.template_filter()
    def my_reverse(s):
        return s[::-1]
    assert 'my_reverse' in app.jinja_env.filters.keys()
    assert app.jinja_env.filters['my_reverse'] == my_reverse
    assert app.jinja_env.filters['my_reverse']('abcd') == 'dcba'
def test_add_template_filter():
    app = flask.Flask(__name__)
    def my_reverse(s):
        return s[::-1]
    app.add_template_filter(my_reverse)
    assert 'my_reverse' in app.jinja_env.filters.keys()
    assert app.jinja_env.filters['my_reverse'] == my_reverse
    assert app.jinja_env.filters['my_reverse']('abcd') == 'dcba'
def test_template_filter_with_name():
    app = flask.Flask(__name__)
    @app.template_filter('strrev')
    def my_reverse(s):
        return s[::-1]
    assert 'strrev' in app.jinja_env.filters.keys()
    assert app.jinja_env.filters['strrev'] == my_reverse
    assert app.jinja_env.filters['strrev']('abcd') == 'dcba'
def test_add_template_filter_with_name():
    app = flask.Flask(__name__)
    def my_reverse(s):
        return s[::-1]
    app.add_template_filter(my_reverse, 'strrev')
    assert 'strrev' in app.jinja_env.filters.keys()
    assert app.jinja_env.filters['strrev'] == my_reverse
    assert app.jinja_env.filters['strrev']('abcd') == 'dcba'
def test_template_filter_with_template():
    app = flask.Flask(__name__)
    @app.template_filter()
    def super_reverse(s):
        return s[::-1]
    @app.route('/')
    def index():
        return flask.render_template('template_filter.html', value='abcd')
    rv = app.test_client().get('/')
    assert rv.data == b'dcba'
def test_add_template_filter_with_template():
    app = flask.Flask(__name__)
    def super_reverse(s):
        return s[::-1]
    app.add_template_filter(super_reverse)
    @app.route('/')
    def index():
        return flask.render_template('template_filter.html', value='abcd')
    rv = app.test_client().get('/')
    assert rv.data == b'dcba'
def test_template_filter_with_name_and_template():
    app = flask.Flask(__name__)
    @app.template_filter('super_reverse')
    def my_reverse(s):
        return s[::-1]
    @app.route('/')
    def index():
        return flask.render_template('template_filter.html', value='abcd')
    rv = app.test_client().get('/')
    assert rv.data == b'dcba'
def test_add_template_filter_with_name_and_template():
    app = flask.Flask(__name__)
    def my_reverse(s):
        return s[::-1]
    app.add_template_filter(my_reverse, 'super_reverse')
    @app.route('/')
    def index():
        return flask.render_template('template_filter.html', value='abcd')
    rv = app.test_client().get('/')
    assert rv.data == b'dcba'
def test_template_test():
    app = flask.Flask(__name__)
    @app.template_test()
    def boolean(value):
        return isinstance(value, bool)
    assert 'boolean' in app.jinja_env.tests.keys()
    assert app.jinja_env.tests['boolean'] == boolean
    assert app.jinja_env.tests['boolean'](False)
def test_add_template_test():
    app = flask.Flask(__name__)
    def boolean(value):
        return isinstance(value, bool)
    app.add_template_test(boolean)
    assert 'boolean' in app.jinja_env.tests.keys()
    assert app.jinja_env.tests['boolean'] == boolean
    assert app.jinja_env.tests['boolean'](False)
def test_template_test_with_name():
    app = flask.Flask(__name__)
    @app.template_test('boolean')
    def is_boolean(value):
        return isinstance(value, bool)
    assert 'boolean' in app.jinja_env.tests.keys()
    assert app.jinja_env.tests['boolean'] == is_boolean
    assert app.jinja_env.tests['boolean'](False)
def test_add_template_test_with_name():
    app = flask.Flask(__name__)
    def is_boolean(value):
        return isinstance(value, bool)
    app.add_template_test(is_boolean, 'boolean')
    assert 'boolean' in app.jinja_env.tests.keys()
    assert app.jinja_env.tests['boolean'] == is_boolean
    assert app.jinja_env.tests['boolean'](False)
def test_template_test_with_template():
    app = flask.Flask(__name__)
    @app.template_test()
    def boolean(value):
        return isinstance(value, bool)
    @app.route('/')
    def index():
        return flask.render_template('template_test.html', value=False)
    rv = app.test_client().get('/')
    assert b'Success!' in rv.data
def test_add_template_test_with_template():
    app = flask.Flask(__name__)
    def boolean(value):
        return isinstance(value, bool)
    app.add_template_test(boolean)
    @app.route('/')
    def index():
        return flask.render_template('template_test.html', value=False)
    rv = app.test_client().get('/')
    assert b'Success!' in rv.data
def test_template_test_with_name_and_template():
    app = flask.Flask(__name__)
    @app.template_test('boolean')
    def is_boolean(value):
        return isinstance(value, bool)
    @app.route('/')
    def index():
        return flask.render_template('template_test.html', value=False)
    rv = app.test_client().get('/')
    assert b'Success!' in rv.data
def test_add_template_test_with_name_and_template():
    app = flask.Flask(__name__)
    def is_boolean(value):
        return isinstance(value, bool)
    app.add_template_test(is_boolean, 'boolean')
    @app.route('/')
    def index():
        return flask.render_template('template_test.html', value=False)
    rv = app.test_client().get('/')
    assert b'Success!' in rv.data
def test_add_template_global():
    app = flask.Flask(__name__)
    @app.template_global()
    def get_stuff():
        return 42
    assert 'get_stuff' in app.jinja_env.globals.keys()
    assert app.jinja_env.globals['get_stuff'] == get_stuff
    assert app.jinja_env.globals['get_stuff'](), 42
    with app.app_context():
        rv = flask.render_template_string('{{ get_stuff() }}')
        assert rv == '42'
def test_custom_template_loader():
    class MyFlask(flask.Flask):
        def create_global_jinja_loader(self):
            from jinja2 import DictLoader
            return DictLoader({'index.html': 'Hello Custom World!'})
    app = MyFlask(__name__)
    @app.route('/')
    def index():
        return flask.render_template('index.html')
    c = app.test_client()
    rv = c.get('/')
    assert rv.data == b'Hello Custom World!'
def test_iterable_loader():
    app = flask.Flask(__name__)
    @app.context_processor
    def context_processor():
        return {'whiskey': 'Jameson'}
    @app.route('/')
    def index():
        return flask.render_template(
            ['no_template.xml',  # should skip this one
            'simple_template.html',  # should render this
            'context_template.html'],
            value=23)
    rv = app.test_client().get('/')
    assert rv.data == b'<h1>Jameson</h1>'
def test_templates_auto_reload():
    app = flask.Flask(__name__)
    assert app.debug is False
    assert app.config['TEMPLATES_AUTO_RELOAD'] is None
    assert app.jinja_env.auto_reload is False
    app = flask.Flask(__name__)
    app.config['TEMPLATES_AUTO_RELOAD'] = False
    assert app.debug is False
    assert app.jinja_env.auto_reload is False
    app = flask.Flask(__name__)
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    assert app.debug is False
    assert app.jinja_env.auto_reload is True
    app = flask.Flask(__name__)
    app.config['DEBUG'] = True
    assert app.config['TEMPLATES_AUTO_RELOAD'] is None
    assert app.jinja_env.auto_reload is True
    app = flask.Flask(__name__)
    app.config['DEBUG'] = True
    app.config['TEMPLATES_AUTO_RELOAD'] = False
    assert app.jinja_env.auto_reload is False
    app = flask.Flask(__name__)
    app.config['DEBUG'] = True
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    assert app.jinja_env.auto_reload is True
def test_template_loader_debugging(test_apps):
    from blueprintapp import app
    called = []
    class _TestHandler(logging.Handler):
        def handle(x, record):
            called.append(True)
            text = str(record.msg)
            assert '1: trying loader of application "blueprintapp"' in text
            assert ('2: trying loader of blueprint "admin" '
                    '(blueprintapp.apps.admin)') in text
            assert ('trying loader of blueprint "frontend" '
                    '(blueprintapp.apps.frontend)') in text
            assert 'Error: the template could not be found' in text
            assert ('looked up from an endpoint that belongs to '
                    'the blueprint "frontend"') in text
            assert 'See http://flask.pocoo.org/docs/blueprints/#templates' in text
    with app.test_client() as c:
        try:
            old_load_setting = app.config['EXPLAIN_TEMPLATE_LOADING']
            old_handlers = app.logger.handlers[:]
            app.logger.handlers = [_TestHandler()]
            app.config['EXPLAIN_TEMPLATE_LOADING'] = True
            with pytest.raises(TemplateNotFound) as excinfo:
                c.get('/missing')
            assert 'missing_template.html' in str(excinfo.value)
        finally:
            app.logger.handlers[:] = old_handlers
            app.config['EXPLAIN_TEMPLATE_LOADING'] = old_load_setting
    assert len(called) == 1
def test_custom_jinja_env():
    class CustomEnvironment(flask.templating.Environment):
        pass
    class CustomFlask(flask.Flask):
        jinja_environment = CustomEnvironment
    app = CustomFlask(__name__)
    assert isinstance(app.jinja_env, CustomEnvironment)
import pytest
import flask
from flask._compat import text_type
def test_environ_defaults_from_config():
    app = flask.Flask(__name__)
    app.testing = True
    app.config['SERVER_NAME'] = 'example.com:1234'
    app.config['APPLICATION_ROOT'] = '/foo'
    @app.route('/')
    def index():
        return flask.request.url
    ctx = app.test_request_context()
    assert ctx.request.url == 'http://example.com:1234/foo/'
    with app.test_client() as c:
        rv = c.get('/')
        assert rv.data == b'http://example.com:1234/foo/'
def test_environ_defaults():
    app = flask.Flask(__name__)
    app.testing = True
    @app.route('/')
    def index():
        return flask.request.url
    ctx = app.test_request_context()
    assert ctx.request.url == 'http://localhost/'
    with app.test_client() as c:
        rv = c.get('/')
        assert rv.data == b'http://localhost/'
def test_redirect_keep_session():
    app = flask.Flask(__name__)
    app.secret_key = 'testing'
    @app.route('/', methods=['GET', 'POST'])
    def index():
        if flask.request.method == 'POST':
            return flask.redirect('/getsession')
        flask.session['data'] = 'foo'
        return 'index'
    @app.route('/getsession')
    def get_session():
        return flask.session.get('data', '<missing>')
    with app.test_client() as c:
        rv = c.get('/getsession')
        assert rv.data == b'<missing>'
        rv = c.get('/')
        assert rv.data == b'index'
        assert flask.session.get('data') == 'foo'
        rv = c.post('/', data={}, follow_redirects=True)
        assert rv.data == b'foo'
        if not hasattr(c, 'redirect_client'):
            assert flask.session.get('data') == 'foo'
        rv = c.get('/getsession')
        assert rv.data == b'foo'
def test_session_transactions():
    app = flask.Flask(__name__)
    app.testing = True
    app.secret_key = 'testing'
    @app.route('/')
    def index():
        return text_type(flask.session['foo'])
    with app.test_client() as c:
        with c.session_transaction() as sess:
            assert len(sess) == 0
            sess['foo'] = [42]
            assert len(sess) == 1
        rv = c.get('/')
        assert rv.data == b'[42]'
        with c.session_transaction() as sess:
            assert len(sess) == 1
            assert sess['foo'] == [42]
def test_session_transactions_no_null_sessions():
    app = flask.Flask(__name__)
    app.testing = True
    with app.test_client() as c:
        with pytest.raises(RuntimeError) as e:
            with c.session_transaction() as sess:
                pass
        assert 'Session backend did not open a session' in str(e.value)
def test_session_transactions_keep_context():
    app = flask.Flask(__name__)
    app.testing = True
    app.secret_key = 'testing'
    with app.test_client() as c:
        rv = c.get('/')
        req = flask.request._get_current_object()
        assert req is not None
        with c.session_transaction():
            assert req is flask.request._get_current_object()
def test_session_transaction_needs_cookies():
    app = flask.Flask(__name__)
    app.testing = True
    c = app.test_client(use_cookies=False)
    with pytest.raises(RuntimeError) as e:
        with c.session_transaction() as s:
            pass
    assert 'cookies' in str(e.value)
def test_test_client_context_binding():
    app = flask.Flask(__name__)
    app.config['LOGGER_HANDLER_POLICY'] = 'never'
    @app.route('/')
    def index():
        flask.g.value = 42
        return 'Hello World!'
    @app.route('/other')
    def other():
        1 // 0
    with app.test_client() as c:
        resp = c.get('/')
        assert flask.g.value == 42
        assert resp.data == b'Hello World!'
        assert resp.status_code == 200
        resp = c.get('/other')
        assert not hasattr(flask.g, 'value')
        assert b'Internal Server Error' in resp.data
        assert resp.status_code == 500
        flask.g.value = 23
    try:
        flask.g.value
    except (AttributeError, RuntimeError):
        pass
    else:
        raise AssertionError('some kind of exception expected')
def test_reuse_client():
    app = flask.Flask(__name__)
    c = app.test_client()
    with c:
        assert c.get('/').status_code == 404
    with c:
        assert c.get('/').status_code == 404
def test_test_client_calls_teardown_handlers():
    app = flask.Flask(__name__)
    called = []
    @app.teardown_request
    def remember(error):
        called.append(error)
    with app.test_client() as c:
        assert called == []
        c.get('/')
        assert called == []
    assert called == [None]
    del called[:]
    with app.test_client() as c:
        assert called == []
        c.get('/')
        assert called == []
        c.get('/')
        assert called == [None]
    assert called == [None, None]
def test_full_url_request():
    app = flask.Flask(__name__)
    app.testing = True
    @app.route('/action', methods=['POST'])
    def action():
        return 'x'
    with app.test_client() as c:
        rv = c.post('http://domain.com/action?vodka=42', data={'gin': 43})
        assert rv.status_code == 200
        assert 'gin' in flask.request.form
        assert 'vodka' in flask.request.args
def test_subdomain():
    app = flask.Flask(__name__)
    app.config['SERVER_NAME'] = 'example.com'
    @app.route('/', subdomain='<company_id>')
    def view(company_id):
        return company_id
    with app.test_request_context():
        url = flask.url_for('view', company_id='xxx')
    with app.test_client() as c:
        response = c.get(url)
    assert 200 == response.status_code
    assert b'xxx' == response.data
def test_nosubdomain():
    app = flask.Flask(__name__)
    app.config['SERVER_NAME'] = 'example.com'
    @app.route('/<company_id>')
    def view(company_id):
        return company_id
    with app.test_request_context():
        url = flask.url_for('view', company_id='xxx')
    with app.test_client() as c:
        response = c.get(url)
    assert 200 == response.status_code
    assert b'xxx' == response.data
from werkzeug.exceptions import Forbidden, InternalServerError
import flask
def test_error_handler_no_match():
    app = flask.Flask(__name__)
    class CustomException(Exception):
        pass
    @app.errorhandler(CustomException)
    def custom_exception_handler(e):
        assert isinstance(e, CustomException)
        return 'custom'
    @app.errorhandler(500)
    def handle_500(e):
        return type(e).__name__
    @app.route('/custom')
    def custom_test():
        raise CustomException()
    @app.route('/keyerror')
    def key_error():
        raise KeyError()
    c = app.test_client()
    assert c.get('/custom').data == b'custom'
    assert c.get('/keyerror').data == b'KeyError'
def test_error_handler_subclass():
    app = flask.Flask(__name__)
    class ParentException(Exception):
        pass
    class ChildExceptionUnregistered(ParentException):
        pass
    class ChildExceptionRegistered(ParentException):
        pass
    @app.errorhandler(ParentException)
    def parent_exception_handler(e):
        assert isinstance(e, ParentException)
        return 'parent'
    @app.errorhandler(ChildExceptionRegistered)
    def child_exception_handler(e):
        assert isinstance(e, ChildExceptionRegistered)
        return 'child-registered'
    @app.route('/parent')
    def parent_test():
        raise ParentException()
    @app.route('/child-unregistered')
    def unregistered_test():
        raise ChildExceptionUnregistered()
    @app.route('/child-registered')
    def registered_test():
        raise ChildExceptionRegistered()
    c = app.test_client()
    assert c.get('/parent').data == b'parent'
    assert c.get('/child-unregistered').data == b'parent'
    assert c.get('/child-registered').data == b'child-registered'
def test_error_handler_http_subclass():
    app = flask.Flask(__name__)
    class ForbiddenSubclassRegistered(Forbidden):
        pass
    class ForbiddenSubclassUnregistered(Forbidden):
        pass
    @app.errorhandler(403)
    def code_exception_handler(e):
        assert isinstance(e, Forbidden)
        return 'forbidden'
    @app.errorhandler(ForbiddenSubclassRegistered)
    def subclass_exception_handler(e):
        assert isinstance(e, ForbiddenSubclassRegistered)
        return 'forbidden-registered'
    @app.route('/forbidden')
    def forbidden_test():
        raise Forbidden()
    @app.route('/forbidden-registered')
    def registered_test():
        raise ForbiddenSubclassRegistered()
    @app.route('/forbidden-unregistered')
    def unregistered_test():
        raise ForbiddenSubclassUnregistered()
    c = app.test_client()
    assert c.get('/forbidden').data == b'forbidden'
    assert c.get('/forbidden-unregistered').data == b'forbidden'
    assert c.get('/forbidden-registered').data == b'forbidden-registered'
def test_error_handler_blueprint():
    bp = flask.Blueprint('bp', __name__)
    @bp.errorhandler(500)
    def bp_exception_handler(e):
        return 'bp-error'
    @bp.route('/error')
    def bp_test():
        raise InternalServerError()
    app = flask.Flask(__name__)
    @app.errorhandler(500)
    def app_exception_handler(e):
        return 'app-error'
    @app.route('/error')
    def app_test():
        raise InternalServerError()
    app.register_blueprint(bp, url_prefix='/bp')
    c = app.test_client()
    assert c.get('/error').data == b'app-error'
    assert c.get('/bp/error').data == b'bp-error'
import pytest
import flask
import flask.views
from werkzeug.http import parse_set_header
def common_test(app):
    c = app.test_client()
    assert c.get('/').data == b'GET'
    assert c.post('/').data == b'POST'
    assert c.put('/').status_code == 405
    meths = parse_set_header(c.open('/', method='OPTIONS').headers['Allow'])
    assert sorted(meths) == ['GET', 'HEAD', 'OPTIONS', 'POST']
def test_basic_view():
    app = flask.Flask(__name__)
    class Index(flask.views.View):
        methods = ['GET', 'POST']
        def dispatch_request(self):
            return flask.request.method
    app.add_url_rule('/', view_func=Index.as_view('index'))
    common_test(app)
def test_method_based_view():
    app = flask.Flask(__name__)
    class Index(flask.views.MethodView):
        def get(self):
            return 'GET'
        def post(self):
            return 'POST'
    app.add_url_rule('/', view_func=Index.as_view('index'))
    common_test(app)
def test_view_patching():
    app = flask.Flask(__name__)
    class Index(flask.views.MethodView):
        def get(self):
            1 // 0
        def post(self):
            1 // 0
    class Other(Index):
        def get(self):
            return 'GET'
        def post(self):
            return 'POST'
    view = Index.as_view('index')
    view.view_class = Other
    app.add_url_rule('/', view_func=view)
    common_test(app)
def test_view_inheritance():
    app = flask.Flask(__name__)
    class Index(flask.views.MethodView):
        def get(self):
            return 'GET'
        def post(self):
            return 'POST'
    class BetterIndex(Index):
        def delete(self):
            return 'DELETE'
    app.add_url_rule('/', view_func=BetterIndex.as_view('index'))
    c = app.test_client()
    meths = parse_set_header(c.open('/', method='OPTIONS').headers['Allow'])
    assert sorted(meths) == ['DELETE', 'GET', 'HEAD', 'OPTIONS', 'POST']
def test_view_decorators():
    app = flask.Flask(__name__)
    def add_x_parachute(f):
        def new_function(*args, **kwargs):
            resp = flask.make_response(f(*args, **kwargs))
            resp.headers['X-Parachute'] = 'awesome'
            return resp
        return new_function
    class Index(flask.views.View):
        decorators = [add_x_parachute]
        def dispatch_request(self):
            return 'Awesome'
    app.add_url_rule('/', view_func=Index.as_view('index'))
    c = app.test_client()
    rv = c.get('/')
    assert rv.headers['X-Parachute'] == 'awesome'
    assert rv.data == b'Awesome'
def test_implicit_head():
    app = flask.Flask(__name__)
    class Index(flask.views.MethodView):
        def get(self):
            return flask.Response('Blub', headers={
                'X-Method': flask.request.method
            })
    app.add_url_rule('/', view_func=Index.as_view('index'))
    c = app.test_client()
    rv = c.get('/')
    assert rv.data == b'Blub'
    assert rv.headers['X-Method'] == 'GET'
    rv = c.head('/')
    assert rv.data == b''
    assert rv.headers['X-Method'] == 'HEAD'
def test_explicit_head():
    app = flask.Flask(__name__)
    class Index(flask.views.MethodView):
        def get(self):
            return 'GET'
        def head(self):
            return flask.Response('', headers={'X-Method': 'HEAD'})
    app.add_url_rule('/', view_func=Index.as_view('index'))
    c = app.test_client()
    rv = c.get('/')
    assert rv.data == b'GET'
    rv = c.head('/')
    assert rv.data == b''
    assert rv.headers['X-Method'] == 'HEAD'
def test_endpoint_override():
    app = flask.Flask(__name__)
    app.debug = True
    class Index(flask.views.View):
        methods = ['GET', 'POST']
        def dispatch_request(self):
            return flask.request.method
    app.add_url_rule('/', view_func=Index.as_view('index'))
    with pytest.raises(AssertionError):
        app.add_url_rule('/', view_func=Index.as_view('index'))
    common_test(app)
from flask import Flask
app = Flask(__name__)
app.config['DEBUG'] = True
from blueprintapp.apps.admin import admin
from blueprintapp.apps.frontend import frontend
app.register_blueprint(admin)
app.register_blueprint(frontend)
from flask import Blueprint, render_template
admin = Blueprint('admin', __name__, url_prefix='/admin',
                  template_folder='templates',
                  static_folder='static')
@admin.route('/')
def index():
    return render_template('admin/index.html')
@admin.route('/index2')
def index2():
    return render_template('./admin/index.html')
from flask import Blueprint, render_template
frontend = Blueprint('frontend', __name__, template_folder='templates')
@frontend.route('/')
def index():
    return render_template('frontend/index.htl')
@frontend.route('/missing')
def missing_template():
    return render_template('missing_template.html')
from __future__ import absolute_import, print_function
from flask import Flask
testapp = Flask('testapp')
from __future__ import absolute_import, print_function
from flask import Flask
app1 = Flask('app1')
app2 = Flask('app2')
from flask import Module
mod = Module(__name__, 'foo', subdomain='foo')