import os
import sys
import logging
import time
from threading import Thread
from flask_cors import CORS
from pogom import config
from pogom.app import Pogom
from pogom.utils import get_args, insert_mock_data
from pogom.search import search_loop, create_search_threads, fake_search_loop
from pogom.models import init_database, create_tables, Pokemon, Pokestop, Gym
from pogom.pgoapi.utilities import get_pos_by_name
logging.basicConfig(format='%(asctime)s [%(module)14s] [%(levelname)7s] %(message)s')
log = logging.getLogger()
if __name__ == '__main__':
    args = get_args()
    if args.debug:
        log.setLevel(logging.DEBUG);
    else:
        log.setLevel(logging.INFO);
    logging.getLogger("peewee").setLevel(logging.INFO)
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("pogom.pgoapi.pgoapi").setLevel(logging.WARNING)
    logging.getLogger("pogom.pgoapi.rpc_api").setLevel(logging.INFO)
    logging.getLogger('werkzeug').setLevel(logging.ERROR)
    config['parse_pokemon'] = not args.no_pokemon
    config['parse_pokestops'] = not args.no_pokestops
    config['parse_gyms'] = not args.no_gyms
    if args.debug:
        logging.getLogger("requests").setLevel(logging.DEBUG)
        logging.getLogger("pgoapi").setLevel(logging.DEBUG)
        logging.getLogger("rpc_api").setLevel(logging.DEBUG)
    db = init_database()
    create_tables(db)
    position = get_pos_by_name(args.location)
    if not any(position):
        log.error('Could not get a position by name, aborting.')
        sys.exit()
    log.info('Parsed location is: {:.4f}/{:.4f}/{:.4f} (lat/lng/alt)'.
             format(*position))
    if args.no_pokemon:
        log.info('Parsing of Pokemon disabled.')
    if args.no_pokestops:
        log.info('Parsing of Pokestops disabled.')
    if args.no_gyms:
        log.info('Parsing of Gyms disabled.')
    config['ORIGINAL_LATITUDE'] = position[0]
    config['ORIGINAL_LONGITUDE'] = position[1]
    config['LOCALE'] = args.locale
    config['CHINA'] = args.china
    if not args.only_server:
        if not args.mock:
            log.debug('Starting a real search thread and {} search runner thread(s)'.format(args.num_threads))
            create_search_threads(args.num_threads)
            search_thread = Thread(target=search_loop, args=(args,))
        else:
            log.debug('Starting a fake search thread')
            insert_mock_data()
            search_thread = Thread(target=fake_search_loop)
        search_thread.daemon = True
        search_thread.name = 'search_thread'
        search_thread.start()
    app = Pogom(__name__)
    if args.cors:
        CORS(app);
    config['ROOT_PATH'] = app.root_path
    config['GMAPS_KEY'] = args.gmaps_key
    config['REQ_SLEEP'] = args.scan_delay
    if args.no_server:
        while search_thread.is_alive():
            time.sleep(60)
    else:
        app.run(threaded=True, use_reloader=False, debug=args.debug, host=args.host, port=args.port)
config = {
    'LOCALE': 'en',
    'LOCALES_DIR': 'static/locales',
    'ROOT_PATH': '',
    'ORIGINAL_LATITUDE': None,
    'ORIGINAL_LONGITUDE': None,
    'GMAPS_KEY': None,
    'REQ_SLEEP': 5,
    'REQ_HEAVY_SLEEP': 30,
    'REQ_MAX_FAILED': 5,
    'PASSWORD': None
}
import calendar
import logging
from flask import Flask, jsonify, render_template, request
from flask.json import JSONEncoder
from flask_compress import Compress
from datetime import datetime
from s2sphere import *
from pogom.utils import get_args
from . import config
from .models import Pokemon, Gym, Pokestop, ScannedLocation
log = logging.getLogger(__name__)
compress = Compress()
class Pogom(Flask):
    def __init__(self, import_name, **kwargs):
        super(Pogom, self).__init__(import_name, **kwargs)
        compress.init_app(self)
        self.json_encoder = CustomJSONEncoder
        self.route("/", methods=['GET'])(self.fullmap)
        self.route("/raw_data", methods=['GET'])(self.raw_data)
        self.route("/loc", methods=['GET'])(self.loc)
        self.route("/next_loc", methods=['POST'])(self.next_loc)
        self.route("/mobile", methods=['GET'])(self.list_pokemon)
    def fullmap(self):
        args = get_args()
        display = "inline"
        if args.fixed_location:
            display = "none"
        return render_template('map.html',
                               lat=config['ORIGINAL_LATITUDE'],
                               lng=config['ORIGINAL_LONGITUDE'],
                               gmaps_key=config['GMAPS_KEY'],
                               lang=config['LOCALE'],
                               is_fixed=display
                               )
    def raw_data(self):
        d = {}
        swLat = request.args.get('swLat')
        swLng = request.args.get('swLng')
        neLat = request.args.get('neLat')
        neLng = request.args.get('neLng')
        if request.args.get('pokemon', 'true') == 'true':
            if request.args.get('ids'):
                ids = [int(x) for x in request.args.get('ids').split(',')]
                d['pokemons'] = Pokemon.get_active_by_id(ids, swLat, swLng,
                                                         neLat, neLng)
            else:
                d['pokemons'] = Pokemon.get_active(swLat, swLng, neLat, neLng)
        if request.args.get('pokestops', 'false') == 'true':
            d['pokestops'] = Pokestop.get_stops(swLat, swLng, neLat, neLng)
        if request.args.get('gyms', 'true') == 'true':
            d['gyms'] = Gym.get_gyms(swLat, swLng, neLat, neLng)
        if request.args.get('scanned', 'true') == 'true':
            d['scanned'] = ScannedLocation.get_recent(swLat, swLng, neLat,
                                                      neLng)
        return jsonify(d)
    def loc(self):
        d = {}
        d['lat'] = config['ORIGINAL_LATITUDE']
        d['lng'] = config['ORIGINAL_LONGITUDE']
        return jsonify(d)
    def next_loc(self):
        args = get_args()
        if args.fixed_location:
            return 'Location searching is turned off', 403
        if request.args:
            lat = request.args.get('lat', type=float)
            lon = request.args.get('lon', type=float)
        if request.form:
            lat = request.form.get('lat', type=float)
            lon = request.form.get('lon', type=float)
        if not (lat and lon):
            log.warning('Invalid next location: %s,%s' % (lat, lon))
            return 'bad parameters', 400
        else:
            config['NEXT_LOCATION'] = {'lat': lat, 'lon': lon}
            log.info('Changing next location: %s,%s' % (lat, lon))
            return 'ok'
    def list_pokemon(self):
        pokemon_list = []
        lat = request.args.get('lat', config['ORIGINAL_LATITUDE'], type=float)
        lon = request.args.get('lon', config['ORIGINAL_LONGITUDE'], type=float)
        origin_point = LatLng.from_degrees(lat, lon)
        for pokemon in Pokemon.get_active(None, None, None, None):
            pokemon_point = LatLng.from_degrees(pokemon['latitude'],
                                                pokemon['longitude'])
            diff = pokemon_point - origin_point
            diff_lat = diff.lat().degrees
            diff_lng = diff.lng().degrees
            direction = (('N' if diff_lat >= 0 else 'S')
                         if abs(diff_lat) > 1e-4 else '') +\
                        (('E' if diff_lng >= 0 else 'W')
                         if abs(diff_lng) > 1e-4 else '')
            entry = {
                'id': pokemon['pokemon_id'],
                'name': pokemon['pokemon_name'],
                'card_dir': direction,
                'distance': int(origin_point.get_distance(
                    pokemon_point).radians * 6366468.241830914),
                'time_to_disappear': '%d min %d sec' % (divmod((
                    pokemon['disappear_time']-datetime.utcnow()).seconds, 60)),
                'disappear_time': pokemon['disappear_time'],
                'latitude': pokemon['latitude'],
                'longitude': pokemon['longitude']
            }
            pokemon_list.append((entry, entry['distance']))
        pokemon_list = [y[0] for y in sorted(pokemon_list, key=lambda x: x[1])]
        return render_template('mobile_list.html',
                               pokemon_list=pokemon_list,
                               origin_lat=lat,
                               origin_lng=lon)
class CustomJSONEncoder(JSONEncoder):
    def default(self, obj):
        try:
            if isinstance(obj, datetime):
                if obj.utcoffset() is not None:
                    obj = obj - obj.utcoffset()
                millis = int(
                    calendar.timegm(obj.timetuple()) * 1000 +
                    obj.microsecond / 1000
                )
                return millis
            iterable = iter(obj)
        except TypeError:
            pass
        else:
            return list(iterable)
        return JSONEncoder.default(self, obj)
from .utils import get_pokemon_name
from pogom.utils import get_args
from datetime import datetime
args = get_args()
def printPokemon(id,lat,lng,itime):
    if args.display_in_console:
        pokemon_name = get_pokemon_name(id).lower()
        pokemon_id = str(id)
        doPrint = True
        if doPrint:
            timeLeft = itime-datetime.utcnow()
            print "======================================\n Name: %s\n Coord: (%f,%f)\n ID: %s \n Remaining Time: %s\n======================================" % (
                pokemon_name.encode('utf-8'),lat,lng,pokemon_id,str(timeLeft))
class APIKeyException(Exception):
    pass
import logging
import os
import time
from peewee import Model, MySQLDatabase, SqliteDatabase, InsertQuery,\
                   IntegerField, CharField, DoubleField, BooleanField,\
                   DateTimeField, OperationalError
from datetime import datetime, timedelta
from base64 import b64encode
from . import config
from .utils import get_pokemon_name, get_args, send_to_webhook
from .transform import transform_from_wgs_to_gcj
from .customLog import printPokemon
log = logging.getLogger(__name__)
args = get_args()
db = None
def init_database():
    global db
    if db is not None:
        return db
    if args.db_type == 'mysql':
        db = MySQLDatabase(
            args.db_name,
            user=args.db_user,
            password=args.db_pass,
            host=args.db_host)
        log.info('Connecting to MySQL database on {}.'.format(args.db_host))
    else:
        db = SqliteDatabase(args.db)
        log.info('Connecting to local SQLLite database.')
    return db
class BaseModel(Model):
    class Meta:
        database = init_database()
    @classmethod
    def get_all(cls):
        results = [m for m in cls.select().dicts()]
        if args.china:
            for result in results:
                result['latitude'], result['longitude'] = \
                    transform_from_wgs_to_gcj(
                        result['latitude'], result['longitude'])
        return results
class Pokemon(BaseModel):
    encounter_id = CharField(primary_key=True, max_length=50)
    spawnpoint_id = CharField()
    pokemon_id = IntegerField()
    latitude = DoubleField()
    longitude = DoubleField()
    disappear_time = DateTimeField()
    @classmethod
    def get_active(cls, swLat, swLng, neLat, neLng):
        if swLat is None or swLng is None or neLat is None or neLng is None:
            query = (Pokemon
                     .select()
                     .where(Pokemon.disappear_time > datetime.utcnow())
                     .dicts())
        else:
            query = (Pokemon
                     .select()
                     .where((Pokemon.disappear_time > datetime.utcnow()) &
                            (Pokemon.latitude >= swLat) &
                            (Pokemon.longitude >= swLng) &
                            (Pokemon.latitude <= neLat) &
                            (Pokemon.longitude <= neLng))
                     .dicts())
        pokemons = []
        for p in query:
            p['pokemon_name'] = get_pokemon_name(p['pokemon_id'])
            if args.china:
                p['latitude'], p['longitude'] = \
                    transform_from_wgs_to_gcj(p['latitude'], p['longitude'])
            pokemons.append(p)
        return pokemons
    @classmethod
    def get_active_by_id(cls, ids, swLat, swLng, neLat, neLng):
        if swLat is None or swLng is None or neLat is None or neLng is None:
            query = (Pokemon
                     .select()
                     .where((Pokemon.pokemon_id << ids) &
                            (Pokemon.disappear_time > datetime.utcnow()))
                     .dicts())
        else:
            query = (Pokemon
                     .select()
                     .where((Pokemon.pokemon_id << ids) &
                            (Pokemon.disappear_time > datetime.utcnow()) &
                            (Pokemon.latitude >= swLat) &
                            (Pokemon.longitude >= swLng) &
                            (Pokemon.latitude <= neLat) &
                            (Pokemon.longitude <= neLng))
                     .dicts())
        pokemons = []
        for p in query:
            p['pokemon_name'] = get_pokemon_name(p['pokemon_id'])
            if args.china:
                p['latitude'], p['longitude'] = \
                    transform_from_wgs_to_gcj(p['latitude'], p['longitude'])
            pokemons.append(p)
        return pokemons
class Pokestop(BaseModel):
    pokestop_id = CharField(primary_key=True, max_length=50)
    enabled = BooleanField()
    latitude = DoubleField()
    longitude = DoubleField()
    last_modified = DateTimeField()
    lure_expiration = DateTimeField(null=True)
    active_pokemon_id = IntegerField(null=True)
    @classmethod
    def get_stops(cls, swLat, swLng, neLat, neLng):
        if swLat is None or swLng is None or neLat is None or neLng is None:
            query = (Pokestop
                     .select()
                     .dicts())
        else:
            query = (Pokestop
                     .select()
                     .where((Pokestop.latitude >= swLat) &
                            (Pokestop.longitude >= swLng) &
                            (Pokestop.latitude <= neLat) &
                            (Pokestop.longitude <= neLng))
                     .dicts())
        pokestops = []
        for p in query:
            if args.china:
                p['latitude'], p['longitude'] = \
                    transform_from_wgs_to_gcj(p['latitude'], p['longitude'])
            pokestops.append(p)
        return pokestops
class Gym(BaseModel):
    UNCONTESTED = 0
    TEAM_MYSTIC = 1
    TEAM_VALOR = 2
    TEAM_INSTINCT = 3
    gym_id = CharField(primary_key=True, max_length=50)
    team_id = IntegerField()
    guard_pokemon_id = IntegerField()
    gym_points = IntegerField()
    enabled = BooleanField()
    latitude = DoubleField()
    longitude = DoubleField()
    last_modified = DateTimeField()
    @classmethod
    def get_gyms(cls, swLat, swLng, neLat, neLng):
        if swLat is None or swLng is None or neLat is None or neLng is None:
            query = (Gym
                     .select()
                     .dicts())
        else:
            query = (Gym
                     .select()
                     .where((Gym.latitude >= swLat) &
                            (Gym.longitude >= swLng) &
                            (Gym.latitude <= neLat) &
                            (Gym.longitude <= neLng))
                     .dicts())
        gyms = []
        for g in query:
            gyms.append(g)
        return gyms
class ScannedLocation(BaseModel):
    scanned_id = CharField(primary_key=True, max_length=50)
    latitude = DoubleField()
    longitude = DoubleField()
    last_modified = DateTimeField()
    @classmethod
    def get_recent(cls, swLat, swLng, neLat, neLng):
        query = (ScannedLocation
                 .select()
                 .where((ScannedLocation.last_modified >=
                        (datetime.utcnow() - timedelta(minutes=15))) &
                        (ScannedLocation.latitude >= swLat) &
                        (ScannedLocation.longitude >= swLng) &
                        (ScannedLocation.latitude <= neLat) &
                        (ScannedLocation.longitude <= neLng))
                 .dicts())
        scans = []
        for s in query:
            scans.append(s)
        return scans
def parse_map(map_dict, iteration_num, step, step_location):
    pokemons = {}
    pokestops = {}
    gyms = {}
    scanned = {}
    cells = map_dict['responses']['GET_MAP_OBJECTS']['map_cells']
    for cell in cells:
        if config['parse_pokemon']:
            for p in cell.get('wild_pokemons', []):
                d_t = datetime.utcfromtimestamp(
                    (p['last_modified_timestamp_ms'] +
                     p['time_till_hidden_ms']) / 1000.0)
                printPokemon(p['pokemon_data']['pokemon_id'], p['latitude'],
                             p['longitude'], d_t)
                pokemons[p['encounter_id']] = {
                    'encounter_id': b64encode(str(p['encounter_id'])),
                    'spawnpoint_id': p['spawnpoint_id'],
                    'pokemon_id': p['pokemon_data']['pokemon_id'],
                    'latitude': p['latitude'],
                    'longitude': p['longitude'],
                    'disappear_time': d_t
                }
                webhook_data = {
                    'encounter_id': b64encode(str(p['encounter_id'])),
                    'spawnpoint_id': p['spawnpoint_id'],
                    'pokemon_id': p['pokemon_data']['pokemon_id'],
                    'latitude': p['latitude'],
                    'longitude': p['longitude'],
                    'disappear_time': time.mktime(d_t.timetuple())
                }
                send_to_webhook('pokemon', webhook_data)
        if iteration_num > 0 or step > 50:
            for f in cell.get('forts', []):
                if config['parse_pokestops'] and f.get('type') == 1:  # Pokestops
                        if 'lure_info' in f:
                            lure_expiration = datetime.utcfromtimestamp(
                                f['lure_info']['lure_expires_timestamp_ms'] / 1000.0)
                            active_pokemon_id = f['lure_info']['active_pokemon_id']
                        else:
                            lure_expiration, active_pokemon_id = None, None
                        pokestops[f['id']] = {
                            'pokestop_id': f['id'],
                            'enabled': f['enabled'],
                            'latitude': f['latitude'],
                            'longitude': f['longitude'],
                            'last_modified': datetime.utcfromtimestamp(
                                f['last_modified_timestamp_ms'] / 1000.0),
                            'lure_expiration': lure_expiration,
                            'active_pokemon_id': active_pokemon_id
                        }
                elif config['parse_gyms'] and f.get('type') is None:  # Currently, there are only stops and gyms
                        gyms[f['id']] = {
                            'gym_id': f['id'],
                            'team_id': f.get('owned_by_team', 0),
                            'guard_pokemon_id': f.get('guard_pokemon_id', 0),
                            'gym_points': f.get('gym_points', 0),
                            'enabled': f['enabled'],
                            'latitude': f['latitude'],
                            'longitude': f['longitude'],
                            'last_modified': datetime.utcfromtimestamp(
                                f['last_modified_timestamp_ms'] / 1000.0),
                        }
    pokemons_upserted = 0
    pokestops_upserted = 0
    gyms_upserted = 0
    if pokemons and config['parse_pokemon']:
        pokemons_upserted = len(pokemons)
        log.debug("Upserting {} pokemon".format(len(pokemons)))
        bulk_upsert(Pokemon, pokemons)
    if pokestops and config['parse_pokestops']:
        pokestops_upserted = len(pokestops)
        log.debug("Upserting {} pokestops".format(len(pokestops)))
        bulk_upsert(Pokestop, pokestops)
    if gyms and config['parse_gyms']:
        gyms_upserted = len(gyms)
        log.debug("Upserting {} gyms".format(len(gyms)))
        bulk_upsert(Gym, gyms)
    log.info("Upserted {} pokemon, {} pokestops, and {} gyms".format(
      pokemons_upserted,
      pokestops_upserted,
      gyms_upserted))
    scanned[0] = {
        'scanned_id': str(step_location[0])+','+str(step_location[1]),
        'latitude': step_location[0],
        'longitude': step_location[1],
        'last_modified': datetime.utcnow(),
    }
    bulk_upsert(ScannedLocation, scanned)
def bulk_upsert(cls, data):
    num_rows = len(data.values())
    i = 0
    step = 120
    while i < num_rows:
        log.debug("Inserting items {} to {}".format(i, min(i+step, num_rows)))
        try:
            InsertQuery(cls, rows=data.values()[i:min(i+step, num_rows)]).upsert().execute()
        except OperationalError as e:
            log.warning("%s... Retrying", e)
            continue
        i+=step
def create_tables(db):
    db.connect()
    db.create_tables([Pokemon, Pokestop, Gym, ScannedLocation], safe=True)
    db.close()
'''
Search Architecture:
 - Create a Queue
   - Holds a list of locations to scan
 - Create N search threads
   - Each search thread will be responsible for hitting the API for a given scan location
 - Create a "overseer" loop
   - Creates/updates the search grid, populates the Queue, and waits for the current search itteration to complete
   -
'''
import logging
import time
import math
import threading
from threading import Thread, Lock
from queue import Queue
from pgoapi import PGoApi
from pgoapi.utilities import f2i, get_cellid
from . import config
from .models import parse_map
log = logging.getLogger(__name__)
TIMESTAMP = '\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000'
api = PGoApi()
search_queue = Queue()
def calculate_lng_degrees(lat):
    return float(lng_gap_meters) / \
        (meters_per_degree * math.cos(math.radians(lat)))
def send_map_request(api, position):
    try:
        api_copy = api.copy()
        api_copy.set_position(*position)
        api_copy.get_map_objects(latitude=f2i(position[0]),
                                 longitude=f2i(position[1]),
                                 since_timestamp_ms=TIMESTAMP,
                                 cell_id=get_cellid(position[0], position[1]))
        return api_copy.call()
    except Exception as e:
        log.warning("Uncaught exception when downloading map " + str(e))
        return False
def get_new_coords(init_loc, distance, bearing):
     
    R = 6378.1 #km radius of the earth
    bearing = math.radians(bearing)
    init_coords = [math.radians(init_loc[0]), math.radians(init_loc[1])] # convert lat/lng to radians
    new_lat = math.asin( math.sin(init_coords[0])*math.cos(distance/R) +
        math.cos(init_coords[0])*math.sin(distance/R)*math.cos(bearing))
    new_lon = init_coords[1] + math.atan2(math.sin(bearing)*math.sin(distance/R)*math.cos(init_coords[0]),
        math.cos(distance/R)-math.sin(init_coords[0])*math.sin(new_lat))
    return [math.degrees(new_lat), math.degrees(new_lon)]
def generate_location_steps(initial_loc, step_count):
    NORTH = 0
    EAST = 90
    SOUTH = 180
    WEST = 270
    pulse_radius = 0.1                  # km - radius of players heartbeat is 100m
    xdist = math.sqrt(3)*pulse_radius   # dist between column centers
    ydist = 3*(pulse_radius/2)          # dist between row centers
    yield (initial_loc[0], initial_loc[1], 0) #insert initial location
    ring = 1            
    loc = initial_loc
    while ring < step_count:
        loc = get_new_coords(loc, ydist, NORTH)
        loc = get_new_coords(loc, xdist/2, WEST)
        for direction in range(6):
            for i in range(ring):
                if direction == 0: # RIGHT
                    loc = get_new_coords(loc, xdist, EAST)
                if direction == 1: # DOWN + RIGHT
                    loc = get_new_coords(loc, ydist, SOUTH)
                    loc = get_new_coords(loc, xdist/2, EAST)
                if direction == 2: # DOWN + LEFT
                    loc = get_new_coords(loc, ydist, SOUTH)
                    loc = get_new_coords(loc, xdist/2, WEST)
                if direction == 3: # LEFT
                    loc = get_new_coords(loc, xdist, WEST)
                if direction == 4: # UP + LEFT
                    loc = get_new_coords(loc, ydist, NORTH)
                    loc = get_new_coords(loc, xdist/2, WEST)
                if direction == 5: # UP + RIGHT
                    loc = get_new_coords(loc, ydist, NORTH)
                    loc = get_new_coords(loc, xdist/2, EAST)
                yield (loc[0], loc[1], 0)
        ring += 1
def login(args, position):
    log.info('Attempting login to Pokemon Go.')
    api.set_position(*position)
    while not api.login(args.auth_service, args.username, args.password):
        log.info('Failed to login to Pokemon Go. Trying again in {:g} seconds.'.format(args.login_delay))
        time.sleep(args.login_delay)
    log.info('Login to Pokemon Go successful.')
def create_search_threads(num):
    search_threads = []
    for i in range(num):
        t = Thread(target=search_thread, name='search_thread-{}'.format(i), args=(search_queue,))
        t.daemon = True
        t.start()
        search_threads.append(t)
def search_thread(q):
    threadname = threading.currentThread().getName()
    log.debug("Search thread {}: started and waiting".format(threadname))
    while True:
        i, step_location, step, lock = q.get()
        if 'NEXT_LOCATION' in config:
            log.debug("{}: new location waiting, flushing queue".format(threadname))
            q.task_done()
            continue
        log.debug("{}: processing itteration {} step {}".format(threadname, i, step))
        response_dict = {}
        failed_consecutive = 0
        while not response_dict:
            response_dict = send_map_request(api, step_location)
            if response_dict:
                with lock:
                    try:
                        parse_map(response_dict, i, step, step_location)
                        log.debug("{}: itteration {} step {} complete".format(threadname, i, step))
                    except KeyError:
                        log.error('Search thread failed. Response dictionary key error')
                        log.debug('{}: itteration {} step {} failed. Response dictionary\
                            key error.'.format(threadname, i, step))
                        failed_consecutive += 1
                        if(failed_consecutive >= config['REQ_MAX_FAILED']):
                            log.error('Niantic servers under heavy load. Waiting before trying again')
                            time.sleep(config['REQ_HEAVY_SLEEP'])
                            failed_consecutive = 0
                        response_dict = {}
            else:
                log.info('Map download failed, waiting and retrying')
                log.debug('{}: itteration {} step {} failed'.format(threadname, i, step))
                time.sleep(config['REQ_SLEEP'])
        time.sleep(config['REQ_SLEEP'])
        q.task_done()
def search_loop(args):
    i = 0
    while True:
        log.info("Search loop {} starting".format(i))
        try:
            search(args, i)
            log.info("Search loop {} complete.".format(i))
            i += 1
        except Exception as e:
            log.error('Scanning error @ {0.__class__.__name__}: {0}'.format(e))
        finally:
            if args.thread_delay > 0:
                log.info('Waiting {:g} seconds before beginning new scan.'.format(args.thread_delay))
                time.sleep(args.thread_delay)
def search(args, i):
    num_steps = args.step_limit
    if 'NEXT_LOCATION' in config:
        log.info('New location set')
        config['ORIGINAL_LATITUDE'] = config['NEXT_LOCATION']['lat']
        config['ORIGINAL_LONGITUDE'] = config['NEXT_LOCATION']['lon']
        config.pop('NEXT_LOCATION', None)
    position = (config['ORIGINAL_LATITUDE'], config['ORIGINAL_LONGITUDE'], 0)
    if api._auth_provider and api._auth_provider._ticket_expire:
        remaining_time = api._auth_provider._ticket_expire/1000 - time.time()
        if remaining_time > 60:
            log.info("Skipping Pokemon Go login process since already logged in \
                for another {:.2f} seconds".format(remaining_time))
        else:
            login(args, position)
    else:
        login(args, position)
    lock = Lock()
    for step, step_location in enumerate(generate_location_steps(position, num_steps), 1):
        log.debug("Queue search itteration {}, step {}".format(i, step))
        search_args = (i, step_location, step, lock)
        search_queue.put(search_args)
    while not search_queue.empty():
        log.debug("Waiting for current search queue to complete (remaining: {})".format(search_queue.qsize()))
        time.sleep(1)
    search_queue.join()
def fake_search_loop():
    while True:
        log.info('Fake search loop running...')
        time.sleep(10)
from math import sqrt, sin, cos
a = 6378245.0
ee = 0.00669342162296594323
pi = 3.14159265358979324
def transform_from_wgs_to_gcj(latitude, longitude):
    if is_location_out_of_china(latitude, longitude):
        adjust_lat, adjust_lon = latitude, longitude
    else:
        adjust_lat = transform_lat(longitude - 105, latitude - 35.0)
        adjust_lon = transform_long(longitude - 105, latitude - 35.0)
        rad_lat = latitude / 180.0 * pi
        magic = sin(rad_lat)
        magic = 1 - ee * magic * magic
        sqrt_magic = sqrt(magic)
        adjust_lat = (adjust_lat * 180.0) / ((a * (1 - ee)) / (magic * sqrt_magic) * pi)
        adjust_lon = (adjust_lon * 180.0) / (a / sqrt_magic * cos(rad_lat) * pi)
        adjust_lat += latitude
        adjust_lon += longitude
    return adjust_lat, adjust_lon
def is_location_out_of_china(latitude, longitude):
    if longitude < 72.004 or longitude > 137.8347 or latitude < 0.8293 or latitude > 55.8271:
        return True
    return False
def transform_lat(x, y):
    lat = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * sqrt(abs(x))
    lat += (20.0 * sin(6.0 * x * pi) + 20.0 * sin(2.0 * x * pi)) * 2.0 / 3.0
    lat += (20.0 * sin(y * pi) + 40.0 * sin(y / 3.0 * pi)) * 2.0 / 3.0
    lat += (160.0 * sin(y / 12.0 * pi) + 320 * sin(y * pi / 30.0)) * 2.0 / 3.0
    return lat
def transform_long(x, y):
    lon = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * sqrt(abs(x))
    lon += (20.0 * sin(6.0 * x * pi) + 20.0 * sin(2.0 * x * pi)) * 2.0 / 3.0
    lon += (20.0 * sin(x * pi) + 40.0 * sin(x / 3.0 * pi)) * 2.0 / 3.0
    lon += (150.0 * sin(x / 12.0 * pi) + 300.0 * sin(x / 30.0 * pi)) * 2.0 / 3.0
    return lon
import sys
import getpass
import configargparse
import uuid
import os
import json
from datetime import datetime, timedelta
import logging
import shutil
import requests
from . import config
log = logging.getLogger(__name__)
def parse_unicode(bytestring):
    decoded_string = bytestring.decode(sys.getfilesystemencoding())
    return decoded_string
def verify_config_file_exists(filename):
    fullpath = os.path.join(os.path.dirname(__file__), filename)
    if not os.path.exists(fullpath):
        log.info("Could not find " + filename + ", copying default")
        shutil.copy2(fullpath + '.example', fullpath)
def get_args():
    configpath = os.path.join(os.path.dirname(__file__), '../config/config.ini')
    parser = configargparse.ArgParser(default_config_files=[configpath])
    parser.add_argument('-a', '--auth-service', type=str.lower,
                        help='Auth Service', default='ptc')
    parser.add_argument('-u', '--username', help='Username')
    parser.add_argument('-p', '--password', help='Password')
    parser.add_argument('-l', '--location', type=parse_unicode,
                        help='Location, can be an address or coordinates')
    parser.add_argument('-st', '--step-limit', help='Steps', type=int,
                        default=12)
    parser.add_argument('-sd', '--scan-delay',
                        help='Time delay between requests in scan threads',
                        type=float, default=5)
    parser.add_argument('-td', '--thread-delay',
                        help='Time delay between each scan thread loop',
                        type=float, default=5)
    parser.add_argument('-ld', '--login-delay',
                        help='Time delay between each login attempt',
                        type=float, default=5)
    parser.add_argument('-dc', '--display-in-console',
                        help='Display Found Pokemon in Console',
                        action='store_true', default=False)
    parser.add_argument('-H', '--host', help='Set web server listening host',
                        default='127.0.0.1')
    parser.add_argument('-P', '--port', type=int,
                        help='Set web server listening port', default=5000)
    parser.add_argument('-L', '--locale',
                        help='Locale for Pokemon names (default: {},\
                        check {} for more)'.
                        format(config['LOCALE'], config['LOCALES_DIR']), default='en')
    parser.add_argument('-c', '--china',
                        help='Coordinates transformer for China',
                        action='store_true')
    parser.add_argument('-d', '--debug', help='Debug Mode', action='store_true')
    parser.add_argument('-m', '--mock',
                        help='Mock mode. Starts the web server but not the background thread.',
                        action='store_true', default=False)
    parser.add_argument('-ns', '--no-server',
                        help='No-Server Mode. Starts the searcher but not the Webserver.',
                        action='store_true', default=False)
    parser.add_argument('-os', '--only-server',
                        help='Server-Only Mode. Starts only the Webserver without the searcher.',
                        action='store_true', default=False)
    parser.add_argument('-fl', '--fixed-location',
                        help='Hides the search bar for use in shared maps.',
                        action='store_true', default=False)
    parser.add_argument('-k', '--gmaps-key',
                        help='Google Maps Javascript API Key',
                        required=True)
    parser.add_argument('-C', '--cors', help='Enable CORS on web server',
                        action='store_true', default=False)
    parser.add_argument('-D', '--db', help='Database filename',
                        default='pogom.db')
    parser.add_argument('-t', '--num-threads', help='Number of search threads', type=int, default=1)
    parser.add_argument('-np', '--no-pokemon',
                        help='Disables Pokemon from the map (including parsing them into local db)',
                        action='store_true', default=False)
    parser.add_argument('-ng', '--no-gyms',
                        help='Disables Gyms from the map (including parsing them into local db)',
                        action='store_true', default=False)
    parser.add_argument('-nk', '--no-pokestops',
                        help='Disables PokeStops from the map (including parsing them into local db)',
                        action='store_true', default=False)
    parser.add_argument('--db-type', help='Type of database to be used (default: sqlite)',
                        default='sqlite')
    parser.add_argument('--db-name', help='Name of the database to be used')
    parser.add_argument('--db-user', help='Username for the database')
    parser.add_argument('--db-pass', help='Password for the database')
    parser.add_argument('--db-host', help='IP or hostname for the database')
    parser.add_argument('-wh', '--webhook', help='Define URL(s) to POST webhook information to',
                        nargs='*', default=False, dest='webhooks')
    parser.set_defaults(DEBUG=False)
    args = parser.parse_args()
    if args.only_server:
        if args.location is None:
            parser.print_usage()
            print sys.argv[0] + ': error: arguments -l/--location is required'
            sys.exit(1)
    else:
        if (args.username is None or args.location is None or args.step_limit is None):
            parser.print_usage()
            print sys.argv[0] + ': error: arguments -u/--username, -l/--location, -st/--step-limit are required'
            sys.exit(1)
        if config["PASSWORD"] is None and args.password is None:
            config["PASSWORD"] = args.password = getpass.getpass()
        elif args.password is None:
            args.password = config["PASSWORD"]
    return args
def insert_mock_data():
    num_pokemon = 6
    num_pokestop = 6
    num_gym = 6
    log.info('Creating fake: {} pokemon, {} pokestops, {} gyms'.format(
        num_pokemon, num_pokestop, num_gym))
    from .models import Pokemon, Pokestop, Gym
    from .search import generate_location_steps
    latitude, longitude = float(config['ORIGINAL_LATITUDE']),\
        float(config['ORIGINAL_LONGITUDE'])
    locations = [l for l in generate_location_steps((latitude, longitude),
                 num_pokemon)]
    disappear_time = datetime.now() + timedelta(hours=1)
    detect_time = datetime.now()
    for i in range(num_pokemon):
        Pokemon.create(encounter_id=uuid.uuid4(),
                       spawnpoint_id='sp{}'.format(i),
                       pokemon_id=(i+1) % 150,
                       latitude=locations[i][0],
                       longitude=locations[i][1],
                       disappear_time=disappear_time,
                       detect_time=detect_time)
    for i in range(num_pokestop):
        Pokestop.create(pokestop_id=uuid.uuid4(),
                        enabled=True,
                        latitude=locations[i+num_pokemon][0],
                        longitude=locations[i+num_pokemon][1],
                        last_modified=datetime.now(),
                        lure_expiration=disappear_time if (i % 2 == 0) else None,
                        active_pokemon_id=i
                        )
    for i in range(num_gym):
        Gym.create(gym_id=uuid.uuid4(),
                   team_id=i % 3,
                   guard_pokemon_id=(i+1) % 150,
                   latitude=locations[i + num_pokemon + num_pokestop][0],
                   longitude=locations[i + num_pokemon + num_pokestop][1],
                   last_modified=datetime.now(),
                   enabled=True,
                   gym_points=1000
                   )
def get_pokemon_name(pokemon_id):
    if not hasattr(get_pokemon_name, 'names'):
        file_path = os.path.join(
            config['ROOT_PATH'],
            config['LOCALES_DIR'],
            'pokemon.{}.json'.format(config['LOCALE']))
        with open(file_path, 'r') as f:
            get_pokemon_name.names = json.loads(f.read())
    return get_pokemon_name.names[str(pokemon_id)]
def send_to_webhook(message_type, message):
    args = get_args()
    data = {
        'type': message_type,
        'message': message
    }
    if args.webhooks:
        webhooks = args.webhooks
        for w in webhooks:
            try:
                requests.post(w, json=data, timeout=(None, 1))
            except requests.exceptions.ReadTimeout:
                log.debug('Could not receive response from webhook')
            except requests.exceptions.RequestException as e:
                log.debug(e)
from pgoapi      import *
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
import logging
class Auth:
    def __init__(self):
        self.log = logging.getLogger(__name__)
        
        self._auth_provider = None
        
        self._login = False
        self._auth_token = None
        
        self._ticket_expire = None
        self._ticket_start = None
        self._ticket_end = None
    
    def get_name(self):
        return self._auth_provider
    
    def is_login(self):
        return self._login
        
    def get_token(self):
        return self._auth_token
        
    def has_ticket(self):
        if self._ticket_expire and self._ticket_start and self._ticket_end:
            return True
        else:
            return False
       
    def set_ticket(self, params):
        self._ticket_expire, self._ticket_start, self._ticket_end = params
    
    def get_ticket(self):
        if self.has_ticket():
            return (self._ticket_expire, self._ticket_start, self._ticket_end)
        else:
            return False
from auth import Auth
from gpsoauth import perform_master_login, perform_oauth
class AuthGoogle(Auth):
    GOOGLE_LOGIN_ANDROID_ID = '9774d56d682e549c'
    GOOGLE_LOGIN_SERVICE= 'audience:server:client_id:848232511240-7so421jotr2609rmqakceuu1luuq0ptb.apps.googleusercontent.com'
    GOOGLE_LOGIN_APP = 'com.nianticlabs.pokemongo'
    GOOGLE_LOGIN_CLIENT_SIG = '321187995bc7cdc2b5fc91b11a96e2baa8602c62'
    def __init__(self):
        Auth.__init__(self)
        
        self._auth_provider = 'google'
    def login(self, username, password):
        self.log.info('Google login for: {}'.format(username))
        login = perform_master_login(username, password, self.GOOGLE_LOGIN_ANDROID_ID)
        login = perform_oauth(username, login.get('Token', ''), self.GOOGLE_LOGIN_ANDROID_ID, self.GOOGLE_LOGIN_SERVICE, self.GOOGLE_LOGIN_APP,
            self.GOOGLE_LOGIN_CLIENT_SIG)
            
        self._auth_token = login.get('Auth')
        
        if self._auth_token is None:
            self.log.info('Google Login failed.')
            return False
        
        self._login = True
            
        self.log.info('Google Login successful.')
        self.log.debug('Google Session Token: %s', self._auth_token[:25])
        return True
import re
import json
import requests
from auth import Auth
class AuthPtc(Auth):
    PTC_LOGIN_URL = 'https://sso.pokemon.com/sso/login?service=https%3A%2F%2Fsso.pokemon.com%2Fsso%2Foauth2.0%2FcallbackAuthorize'
    PTC_LOGIN_OAUTH = 'https://sso.pokemon.com/sso/oauth2.0/accessToken'
    PTC_LOGIN_CLIENT_SECRET = 'w8ScCUXJQc6kXKw8FiOhd8Fixzht18Dq3PEVkUCP5ZPxtgyWsbTvWHFLm2wNY0JR'
    def __init__(self):
        Auth.__init__(self)
        
        self._auth_provider = 'ptc'
        
        self._session = requests.session()
        self._session.verify = True
    def login(self, username, password):
        self.log.info('PTC login for: %s', username)
        head = {'User-Agent': 'niantic'}
        r = self._session.get(self.PTC_LOGIN_URL, headers=head)
        
        try:
            jdata = json.loads(r.content)
        except ValueError as e:
            self.log.error('{}... server seems to be down :('.format(str(e)))
            return False
            
        data = {
            'lt': jdata['lt'],
            'execution': jdata['execution'],
            '_eventId': 'submit',
            'username': username,
            'password': password[:15],
        }
        r1 = self._session.post(self.PTC_LOGIN_URL, data=data, headers=head)
        ticket = None
        try:
            ticket = re.sub('.*ticket=', '', r1.history[0].headers['Location'])
        except Exception,e:
            try:
                self.log.error('Could not retrieve token: %s', r1.json()['errors'][0])
            except Exception as e:
                self.log.error('Could not retrieve token! (%s)', str(e))
            return False
        data1 = {
            'client_id': 'mobile-app_pokemon-go',
            'redirect_uri': 'https://www.nianticlabs.com/pokemongo/error',
            'client_secret': self.PTC_LOGIN_CLIENT_SECRET,
            'grant_type': 'refresh_token',
            'code': ticket,
        }
        
        r2 = self._session.post(self.PTC_LOGIN_OAUTH, data=data1)
        access_token = re.sub('&expires.*', '', r2.content)
        access_token = re.sub('.*access_token=', '', access_token)
        if '-sso.pokemon.com' in access_token:
            self.log.info('PTC Login successful')
            self.log.debug('PTC Session Token: %s', access_token[:25])
            self._auth_token = access_token
        else:
            self.log.info('Seems not to be a PTC Session Token... login failed :(')
            return False
        
        self._login = True
        
        return True
        
class AuthException(Exception):
    pass
class NotLoggedInException(Exception):
    pass
class ServerBusyOrOfflineException(Exception):
    pass
import logging
from utilities import f2i
from rpc_api import RpcApi
from auth_ptc import AuthPtc
from auth_google import AuthGoogle
from exceptions import AuthException, ServerBusyOrOfflineException
import protos.RpcEnum_pb2 as RpcEnum
logger = logging.getLogger(__name__)
class PGoApi:
    API_ENTRY = 'https://pgorelease.nianticlabs.com/plfe/rpc'
    def __init__(self):
    
        self.log = logging.getLogger(__name__)
        self._auth_provider = None
        self._api_endpoint = None
        
        self._position_lat = 0
        self._position_lng = 0
        self._position_alt = 0
        self._req_method_list = []
    def copy(self):
        other = PGoApi()
        other.log = self.log
        other._auth_provider = self._auth_provider
        other._api_endpoint = self._api_endpoint
        other._position_lat = self._position_lat
        other._position_lng = self._position_lng
        other._position_alt = self._position_alt
        other._req_method_list = list(self._req_method_list)
        return other
        
    def call(self):
        if not self._req_method_list:
            return False
        
        if self._auth_provider is None or not self._auth_provider.is_login():
            self.log.info('Not logged in')
            return False
        
        player_position = self.get_position()
        
        request = RpcApi(self._auth_provider)
        
        if self._api_endpoint:
            api_endpoint = self._api_endpoint
        else:
            api_endpoint = self.API_ENTRY
        
        self.log.info('Execution of RPC')
        response = None
        try:
            response = request.request(api_endpoint, self._req_method_list, player_position)
        except ServerBusyOrOfflineException as e:
            self.log.info('Server seems to be busy or offline - try again!')
        
        self.log.info('Cleanup of request!')
        self._req_method_list = []
        
        return response
    
    
    def list_curr_methods(self):
        for i in self._req_method_list:
            print("{} ({})".format(RpcEnum.RequestMethod.Name(i),i))
    
    def set_logger(self, logger):
        self._ = logger or logging.getLogger(__name__)
    def get_position(self):
        return (self._position_lat, self._position_lng, self._position_alt)
    def set_position(self, lat, lng, alt):   
        self.log.debug('Set Position - Lat: %s Long: %s Alt: %s', lat, lng, alt)
        
        self._position_lat = f2i(lat)
        self._position_lng = f2i(lng)
        self._position_alt = f2i(alt)
    def __getattr__(self, func):
        def function(**kwargs):
        
            if not self._req_method_list:
                self.log.info('Create new request...')
        
            name = func.upper()
            if kwargs:
                self._req_method_list.append( { RpcEnum.RequestMethod.Value(name): kwargs } )
                self.log.info("Adding '%s' to RPC request including arguments", name)
                self.log.debug("Arguments of '%s': \n\r%s", name, kwargs)
            else:
                self._req_method_list.append( RpcEnum.RequestMethod.Value(name) )
                self.log.info("Adding '%s' to RPC request", name)
   
            return self
   
        if func.upper() in RpcEnum.RequestMethod.keys():
            return function
        else:
            raise AttributeError
            
        
    def login(self, provider, username, password):
    
        if not isinstance(username, basestring) or not isinstance(password, basestring):
            raise AuthException("Username/password not correctly specified")
        
        if provider == 'ptc':
            self._auth_provider = AuthPtc()
        elif provider == 'google':
            self._auth_provider = AuthGoogle()
        else:
            raise AuthException("Invalid authentication provider - only ptc/google available.")
            
        self.log.debug('Auth provider: %s', provider)
        
        if not self._auth_provider.login(username, password):
            self.log.info('Login process failed') 
            return False
        
        self.log.info('Starting RPC login sequence (app simulation)')
        
        self.get_player()
        self.get_hatched_eggs()
        self.get_inventory()
        self.check_awarded_badges()
        self.download_settings(hash="4a2e9bc330dae60e7b74fc85b98868ab4700802e")
        
        response = self.call()
        
        if not response: 
            self.log.info('Login failed!') 
            return False
        
        if 'api_url' in response:
            self._api_endpoint = ('https://{}/rpc'.format(response['api_url']))
            self.log.debug('Setting API endpoint to: %s', self._api_endpoint)
        
        elif 'auth_ticket' in response:
            auth_ticket = response['auth_ticket']
            self._auth_provider.set_ticket([auth_ticket['expire_timestamp_ms'], auth_ticket['start'], auth_ticket['end']])
        else:
            self.log.error('Login failed - unexpected server response!')
            return False
        
        self.log.info('Finished RPC login sequence (app simulation)')
        self.log.info('Login process completed') 
        
        return True
        
import logging
import requests
import subprocess
from exceptions import NotLoggedInException, ServerBusyOrOfflineException
from google.protobuf.message import DecodeError
from protobuf_to_dict import protobuf_to_dict
from utilities   import h2f, to_camel_case, get_class
import protos.RpcEnum_pb2 as RpcEnum
import protos.RpcEnvelope_pb2 as RpcEnvelope
class RpcApi:
    
    def __init__(self, auth_provider):
    
        self.log = logging.getLogger(__name__)
    
        self._session = requests.session()
        self._session.headers.update({'User-Agent': 'Niantic App'})
        self._session.verify = True
        
        self._auth_provider = auth_provider
    
    def get_rpc_id(self):
        return 8145806132888207460
    def decode_raw(self, raw):
        process = subprocess.Popen(['protoc', '--decode_raw'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output = error = None
        try:
            output, error = process.communicate(raw)
        except:
            pass
        
        return output
        
    def _make_rpc(self, endpoint, request_proto_plain):
        self.log.debug('Execution of RPC')
        
        request_proto_serialized = request_proto_plain.SerializeToString()
        try:
            http_response = self._session.post(endpoint, data=request_proto_serialized)
        except requests.exceptions.ConnectionError as e:
            raise ServerBusyOrOfflineException
        
        return http_response
    
    def request(self, endpoint, subrequests, player_position):
    
        if not self._auth_provider or self._auth_provider.is_login() is False:
            raise NotLoggedInException()
    
        request_proto = self._build_main_request(subrequests, player_position)
        response = self._make_rpc(endpoint, request_proto)
        
        response_dict = self._parse_main_request(response, subrequests)
        
        return response_dict
    
    def _build_main_request(self, subrequests, player_position = None):
        self.log.debug('Generating main RPC request...')
        
        request = RpcEnvelope.Request()
        request.direction = RpcEnum.REQUEST
        request.rpc_id = self.get_rpc_id()
        
        if player_position is not None:
            request.latitude, request.longitude, request.altitude = player_position
        
        request.auth.provider = self._auth_provider.get_name()
        request.auth.token.contents = self._auth_provider.get_token()
        request.auth.token.unknown13 = 59
        
        request.unknown12 = 989
        
        request = self._build_sub_requests(request, subrequests)
        
        self.log.debug('Generated protobuf request: \n\r%s', request )
        
        return request
    
    def _build_sub_requests(self, mainrequest, subrequest_list):
        self.log.debug('Generating sub RPC requests...')
            
        for entry in subrequest_list:
            if isinstance(entry, dict):
            
                entry_id = entry.items()[0][0]
                entry_content = entry[entry_id]
                entry_name = RpcEnum.RequestMethod.Name(entry_id)
                
                proto_name = to_camel_case(entry_name.lower()) + 'Request'
                proto_classname = 'pogom.pgoapi.protos.RpcSub_pb2.' + proto_name
                subrequest_extension = get_class(proto_classname)()
                for (key, value) in entry_content.items():
                    try:
                        setattr(subrequest_extension, key, value)
                    except Exception as e:
                        self.log.info('Argument %s with value %s unknown inside %s', key, value, proto_name)
                subrequest = mainrequest.requests.add()
                subrequest.type = entry_id
                subrequest.parameters = subrequest_extension.SerializeToString()
                
            elif isinstance(entry, int):
                subrequest = mainrequest.requests.add()
                subrequest.type = entry
            else:
                raise Exception('Unknown value in request list')
    
        return mainrequest
        
    
    def _parse_main_request(self, response_raw, subrequests):
        self.log.debug('Parsing main RPC response...')
        
        if response_raw.status_code != 200:
            self.log.warning('Unexpected HTTP server response - needs 200 got %s', response_raw.status_code)
            self.log.debug('HTTP output: \n%s', response_raw.content)
            return False
        
        if response_raw.content is None:
            self.log.warning('Empty server response!')
            return False
    
        response_proto = RpcEnvelope.Response()
        try:
            response_proto.ParseFromString(response_raw.content)
        except DecodeError as e:
            self.log.warning('Could not parse response: %s', str(e))
            return False
        
        self.log.debug('Protobuf structure of rpc response:\n\r%s', response_proto)
       
        response_proto_dict = protobuf_to_dict(response_proto)
        response_proto_dict = self._parse_sub_responses(response_proto, subrequests, response_proto_dict)
        
        return response_proto_dict
    
    def _parse_sub_responses(self, response_proto, subrequests_list, response_proto_dict):
        self.log.debug('Parsing sub RPC responses...')
        response_proto_dict['responses'] = {}
        list_len = len(subrequests_list) -1
        i = 0
        for subresponse in response_proto.responses:
            
            if i > list_len:
                self.log.info("Error - something strange happend...")
            
            request_entry = subrequests_list[i]
            if isinstance(request_entry, int):
                entry_id = request_entry
            else:
                entry_id =  request_entry.items()[0][0]
                
            entry_name = RpcEnum.RequestMethod.Name(entry_id)
            proto_name = to_camel_case(entry_name.lower()) + 'Response'
            proto_classname = 'pogom.pgoapi.protos.RpcSub_pb2.' + proto_name
            
            subresponse_return = None
            try:
                subresponse_extension = get_class(proto_classname)()            
            except Exception as e:
                subresponse_extension = None
                error = 'Protobuf definition for {} not found'.format(proto_classname)
                subresponse_return = error
                self.log.debug(error)
            
            if subresponse_extension:
                try: 
                    subresponse_extension.ParseFromString(subresponse)
                    subresponse_return = protobuf_to_dict(subresponse_extension)
                except:
                    error = "Protobuf definition for {} seems not to match".format(proto_classname)
                    subresponse_return = error
                    self.log.debug(error)
            
            response_proto_dict['responses'][entry_name] = subresponse_return
            i += 1
           
        return response_proto_dict
import struct
import re
from importlib import import_module
from s2sphere import CellId, LatLng
from google.protobuf.internal import encoder
from geopy.geocoders import GoogleV3
def f2i(float):
    return struct.unpack('<Q', struct.pack('<d', float))[0]
def f2h(float):
    return hex(struct.unpack('<Q', struct.pack('<d', float))[0])
def h2f(hex):
    return struct.unpack('<d', struct.pack('<Q', int(hex,16)))[0]
  
def to_camel_case(value):
    def camelcase():
        while True:
            yield str.capitalize
    c = camelcase()
    return "".join(c.next()(x) if x else '_' for x in value.split("_"))
def get_pos_by_name(location_name):
    prog = re.compile("^(\-?\d+\.\d+)?,\s*(\-?\d+\.\d+?)$")
    res = prog.match(location_name)
    latitude, longitude, altitude = None, None, None
    if res:
        latitude, longitude, altitude = float(res.group(1)), float(res.group(2)), 0
    elif location_name:
        geolocator = GoogleV3()
        loc = geolocator.geocode(location_name)
        if loc:
            latitude, longitude, altitude = loc.latitude, loc.longitude, loc.altitude
    
    return (latitude, longitude, altitude)
    
def get_class(cls):
    module_, class_ = cls.rsplit('.', 1)
    class_ = getattr(import_module(module_), class_)
    return class_
    
def get_cellid(lat, long):
    origin = CellId.from_lat_lng(LatLng.from_degrees(lat, long)).parent(15)
    walk = [origin.id()]
    next = origin.next()
    prev = origin.prev()
    for i in range(10):
        walk.append(prev.id())
        walk.append(next.id())
        next = next.next()
        prev = prev.prev()
    return ''.join(map(encode, sorted(walk)))
def encode(cellid):
    output = []
    encoder._VarintEncoder()(output.append, cellid)
    return ''.join(output)
import sys
_b=sys.version_info[0]<3 and (lambda x:x) or (lambda x:x.encode('latin1'))
from google.protobuf.internal import enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import symbol_database as _symbol_database
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor.FileDescriptor(
  name='RpcEnum.proto',
  package='RpcEnum',
  serialized_pb=_b('\n\rRpcEnum.proto\x12\x07RpcEnum*6\n\x0cRpcDirection\x12\x0b\n\x07UNKNOWN\x10\x00\x12\x0c\n\x08RESPONSE\x10\x01\x12\x0b\n\x07REQUEST\x10\x02*7\n\tTeamColor\x12\x0b\n\x07NEUTRAL\x10\x00\x12\x08\n\x04\x42LUE\x10\x01\x12\x07\n\x03RED\x10\x02\x12\n\n\x06YELLOW\x10\x03*\xc3\x0c\n\rRequestMethod\x12\x10\n\x0cMETHOD_UNSET\x10\x00\x12\x11\n\rPLAYER_UPDATE\x10\x01\x12\x0e\n\nGET_PLAYER\x10\x02\x12\x11\n\rGET_INVENTORY\x10\x04\x12\x15\n\x11\x44OWNLOAD_SETTINGS\x10\x05\x12\x1b\n\x17\x44OWNLOAD_ITEM_TEMPLATES\x10\x06\x12\"\n\x1e\x44OWNLOAD_REMOTE_CONFIG_VERSION\x10\x07\x12\x0f\n\x0b\x46ORT_SEARCH\x10\x65\x12\r\n\tENCOUNTER\x10\x66\x12\x11\n\rCATCH_POKEMON\x10g\x12\x10\n\x0c\x46ORT_DETAILS\x10h\x12\x0c\n\x08ITEM_USE\x10i\x12\x13\n\x0fGET_MAP_OBJECTS\x10j\x12\x17\n\x13\x46ORT_DEPLOY_POKEMON\x10n\x12\x17\n\x13\x46ORT_RECALL_POKEMON\x10o\x12\x13\n\x0fRELEASE_POKEMON\x10p\x12\x13\n\x0fUSE_ITEM_POTION\x10q\x12\x14\n\x10USE_ITEM_CAPTURE\x10r\x12\x11\n\rUSE_ITEM_FLEE\x10s\x12\x13\n\x0fUSE_ITEM_REVIVE\x10t\x12\x10\n\x0cTRADE_SEARCH\x10u\x12\x0f\n\x0bTRADE_OFFER\x10v\x12\x12\n\x0eTRADE_RESPONSE\x10w\x12\x10\n\x0cTRADE_RESULT\x10x\x12\x16\n\x12GET_PLAYER_PROFILE\x10y\x12\x11\n\rGET_ITEM_PACK\x10z\x12\x11\n\rBUY_ITEM_PACK\x10{\x12\x10\n\x0c\x42UY_GEM_PACK\x10|\x12\x12\n\x0e\x45VOLVE_POKEMON\x10}\x12\x14\n\x10GET_HATCHED_EGGS\x10~\x12\x1f\n\x1b\x45NCOUNTER_TUTORIAL_COMPLETE\x10\x7f\x12\x15\n\x10LEVEL_UP_REWARDS\x10\x80\x01\x12\x19\n\x14\x43HECK_AWARDED_BADGES\x10\x81\x01\x12\x11\n\x0cUSE_ITEM_GYM\x10\x85\x01\x12\x14\n\x0fGET_GYM_DETAILS\x10\x86\x01\x12\x15\n\x10START_GYM_BATTLE\x10\x87\x01\x12\x0f\n\nATTACK_GYM\x10\x88\x01\x12\x1b\n\x16RECYCLE_INVENTORY_ITEM\x10\x89\x01\x12\x18\n\x13\x43OLLECT_DAILY_BONUS\x10\x8a\x01\x12\x16\n\x11USE_ITEM_XP_BOOST\x10\x8b\x01\x12\x1b\n\x16USE_ITEM_EGG_INCUBATOR\x10\x8c\x01\x12\x10\n\x0bUSE_INCENSE\x10\x8d\x01\x12\x18\n\x13GET_INCENSE_POKEMON\x10\x8e\x01\x12\x16\n\x11INCENSE_ENCOUNTER\x10\x8f\x01\x12\x16\n\x11\x41\x44\x44_FORT_MODIFIER\x10\x90\x01\x12\x13\n\x0e\x44ISK_ENCOUNTER\x10\x91\x01\x12!\n\x1c\x43OLLECT_DAILY_DEFENDER_BONUS\x10\x92\x01\x12\x14\n\x0fUPGRADE_POKEMON\x10\x93\x01\x12\x19\n\x14SET_FAVORITE_POKEMON\x10\x94\x01\x12\x15\n\x10NICKNAME_POKEMON\x10\x95\x01\x12\x10\n\x0b\x45QUIP_BADGE\x10\x96\x01\x12\x19\n\x14SET_CONTACT_SETTINGS\x10\x97\x01\x12\x15\n\x10GET_ASSET_DIGEST\x10\xac\x02\x12\x16\n\x11GET_DOWNLOAD_URLS\x10\xad\x02\x12\x1c\n\x17GET_SUGGESTED_CODENAMES\x10\x91\x03\x12\x1d\n\x18\x43HECK_CODENAME_AVAILABLE\x10\x92\x03\x12\x13\n\x0e\x43LAIM_CODENAME\x10\x93\x03\x12\x0f\n\nSET_AVATAR\x10\x94\x03\x12\x14\n\x0fSET_PLAYER_TEAM\x10\x95\x03\x12\x1b\n\x16MARK_TUTORIAL_COMPLETE\x10\x96\x03\x12\x16\n\x11LOAD_SPAWN_POINTS\x10\xf4\x03\x12\t\n\x04\x45\x43HO\x10\x9a\x05\x12\x1b\n\x16\x44\x45\x42UG_UPDATE_INVENTORY\x10\xbc\x05\x12\x18\n\x13\x44\x45\x42UG_DELETE_PLAYER\x10\xbd\x05\x12\x17\n\x12SFIDA_REGISTRATION\x10\xa0\x06\x12\x15\n\x10SFIDA_ACTION_LOG\x10\xa1\x06\x12\x18\n\x13SFIDA_CERTIFICATION\x10\xa2\x06\x12\x11\n\x0cSFIDA_UPDATE\x10\xa3\x06\x12\x11\n\x0cSFIDA_ACTION\x10\xa4\x06\x12\x11\n\x0cSFIDA_DOWSER\x10\xa5\x06\x12\x12\n\rSFIDA_CAPTURE\x10\xa6\x06*\xce\x17\n\x0bPokemonMove\x12\x0e\n\nMOVE_UNSET\x10\x00\x12\x11\n\rTHUNDER_SHOCK\x10\x01\x12\x10\n\x0cQUICK_ATTACK\x10\x02\x12\x0b\n\x07SCRATCH\x10\x03\x12\t\n\x05\x45MBER\x10\x04\x12\r\n\tVINE_WHIP\x10\x05\x12\n\n\x06TACKLE\x10\x06\x12\x0e\n\nRAZOR_LEAF\x10\x07\x12\r\n\tTAKE_DOWN\x10\x08\x12\r\n\tWATER_GUN\x10\t\x12\x08\n\x04\x42ITE\x10\n\x12\t\n\x05POUND\x10\x0b\x12\x0f\n\x0b\x44OUBLE_SLAP\x10\x0c\x12\x08\n\x04WRAP\x10\r\x12\x0e\n\nHYPER_BEAM\x10\x0e\x12\x08\n\x04LICK\x10\x0f\x12\x0e\n\nDARK_PULSE\x10\x10\x12\x08\n\x04SMOG\x10\x11\x12\n\n\x06SLUDGE\x10\x12\x12\x0e\n\nMETAL_CLAW\x10\x13\x12\r\n\tVICE_GRIP\x10\x14\x12\x0f\n\x0b\x46LAME_WHEEL\x10\x15\x12\x0c\n\x08MEGAHORN\x10\x16\x12\x0f\n\x0bWING_ATTACK\x10\x17\x12\x10\n\x0c\x46LAMETHROWER\x10\x18\x12\x10\n\x0cSUCKER_PUNCH\x10\x19\x12\x07\n\x03\x44IG\x10\x1a\x12\x0c\n\x08LOW_KICK\x10\x1b\x12\x0e\n\nCROSS_CHOP\x10\x1c\x12\x0e\n\nPSYCHO_CUT\x10\x1d\x12\x0b\n\x07PSYBEAM\x10\x1e\x12\x0e\n\nEARTHQUAKE\x10\x1f\x12\x0e\n\nSTONE_EDGE\x10 \x12\r\n\tICE_PUNCH\x10!\x12\x0f\n\x0bHEART_STAMP\x10\"\x12\r\n\tDISCHARGE\x10#\x12\x10\n\x0c\x46LASH_CANNON\x10$\x12\x08\n\x04PECK\x10%\x12\x0e\n\nDRILL_PECK\x10&\x12\x0c\n\x08ICE_BEAM\x10\'\x12\x0c\n\x08\x42LIZZARD\x10(\x12\r\n\tAIR_SLASH\x10)\x12\r\n\tHEAT_WAVE\x10*\x12\r\n\tTWINEEDLE\x10+\x12\x0e\n\nPOISON_JAB\x10,\x12\x0e\n\nAERIAL_ACE\x10-\x12\r\n\tDRILL_RUN\x10.\x12\x12\n\x0ePETAL_BLIZZARD\x10/\x12\x0e\n\nMEGA_DRAIN\x10\x30\x12\x0c\n\x08\x42UG_BUZZ\x10\x31\x12\x0f\n\x0bPOISON_FANG\x10\x32\x12\x0f\n\x0bNIGHT_SLASH\x10\x33\x12\t\n\x05SLASH\x10\x34\x12\x0f\n\x0b\x42UBBLE_BEAM\x10\x35\x12\x0e\n\nSUBMISSION\x10\x36\x12\x0f\n\x0bKARATE_CHOP\x10\x37\x12\r\n\tLOW_SWEEP\x10\x38\x12\x0c\n\x08\x41QUA_JET\x10\x39\x12\r\n\tAQUA_TAIL\x10:\x12\r\n\tSEED_BOMB\x10;\x12\x0c\n\x08PSYSHOCK\x10<\x12\x0e\n\nROCK_THROW\x10=\x12\x11\n\rANCIENT_POWER\x10>\x12\r\n\tROCK_TOMB\x10?\x12\x0e\n\nROCK_SLIDE\x10@\x12\r\n\tPOWER_GEM\x10\x41\x12\x10\n\x0cSHADOW_SNEAK\x10\x42\x12\x10\n\x0cSHADOW_PUNCH\x10\x43\x12\x0f\n\x0bSHADOW_CLAW\x10\x44\x12\x10\n\x0cOMINOUS_WIND\x10\x45\x12\x0f\n\x0bSHADOW_BALL\x10\x46\x12\x10\n\x0c\x42ULLET_PUNCH\x10G\x12\x0f\n\x0bMAGNET_BOMB\x10H\x12\x0e\n\nSTEEL_WING\x10I\x12\r\n\tIRON_HEAD\x10J\x12\x14\n\x10PARABOLIC_CHARGE\x10K\x12\t\n\x05SPARK\x10L\x12\x11\n\rTHUNDER_PUNCH\x10M\x12\x0b\n\x07THUNDER\x10N\x12\x0f\n\x0bTHUNDERBOLT\x10O\x12\x0b\n\x07TWISTER\x10P\x12\x11\n\rDRAGON_BREATH\x10Q\x12\x10\n\x0c\x44RAGON_PULSE\x10R\x12\x0f\n\x0b\x44RAGON_CLAW\x10S\x12\x13\n\x0f\x44ISARMING_VOICE\x10T\x12\x11\n\rDRAINING_KISS\x10U\x12\x12\n\x0e\x44\x41ZZLING_GLEAM\x10V\x12\r\n\tMOONBLAST\x10W\x12\x0e\n\nPLAY_ROUGH\x10X\x12\x10\n\x0c\x43ROSS_POISON\x10Y\x12\x0f\n\x0bSLUDGE_BOMB\x10Z\x12\x0f\n\x0bSLUDGE_WAVE\x10[\x12\r\n\tGUNK_SHOT\x10\\\x12\x0c\n\x08MUD_SHOT\x10]\x12\r\n\tBONE_CLUB\x10^\x12\x0c\n\x08\x42ULLDOZE\x10_\x12\x0c\n\x08MUD_BOMB\x10`\x12\x0f\n\x0b\x46URY_CUTTER\x10\x61\x12\x0c\n\x08\x42UG_BITE\x10\x62\x12\x0f\n\x0bSIGNAL_BEAM\x10\x63\x12\r\n\tX_SCISSOR\x10\x64\x12\x10\n\x0c\x46LAME_CHARGE\x10\x65\x12\x0f\n\x0b\x46LAME_BURST\x10\x66\x12\x0e\n\nFIRE_BLAST\x10g\x12\t\n\x05\x42RINE\x10h\x12\x0f\n\x0bWATER_PULSE\x10i\x12\t\n\x05SCALD\x10j\x12\x0e\n\nHYDRO_PUMP\x10k\x12\x0b\n\x07PSYCHIC\x10l\x12\r\n\tPSYSTRIKE\x10m\x12\r\n\tICE_SHARD\x10n\x12\x0c\n\x08ICY_WIND\x10o\x12\x10\n\x0c\x46ROST_BREATH\x10p\x12\n\n\x06\x41\x42SORB\x10q\x12\x0e\n\nGIGA_DRAIN\x10r\x12\x0e\n\nFIRE_PUNCH\x10s\x12\x0e\n\nSOLAR_BEAM\x10t\x12\x0e\n\nLEAF_BLADE\x10u\x12\x0e\n\nPOWER_WHIP\x10v\x12\n\n\x06SPLASH\x10w\x12\x08\n\x04\x41\x43ID\x10x\x12\x0e\n\nAIR_CUTTER\x10y\x12\r\n\tHURRICANE\x10z\x12\x0f\n\x0b\x42RICK_BREAK\x10{\x12\x07\n\x03\x43UT\x10|\x12\t\n\x05SWIFT\x10}\x12\x0f\n\x0bHORN_ATTACK\x10~\x12\t\n\x05STOMP\x10\x7f\x12\r\n\x08HEADBUTT\x10\x80\x01\x12\x0f\n\nHYPER_FANG\x10\x81\x01\x12\t\n\x04SLAM\x10\x82\x01\x12\x0e\n\tBODY_SLAM\x10\x83\x01\x12\t\n\x04REST\x10\x84\x01\x12\r\n\x08STRUGGLE\x10\x85\x01\x12\x14\n\x0fSCALD_BLASTOISE\x10\x86\x01\x12\x19\n\x14HYDRO_PUMP_BLASTOISE\x10\x87\x01\x12\x0f\n\nWRAP_GREEN\x10\x88\x01\x12\x0e\n\tWRAP_PINK\x10\x89\x01\x12\x15\n\x10\x46URY_CUTTER_FAST\x10\xc8\x01\x12\x12\n\rBUG_BITE_FAST\x10\xc9\x01\x12\x0e\n\tBITE_FAST\x10\xca\x01\x12\x16\n\x11SUCKER_PUNCH_FAST\x10\xcb\x01\x12\x17\n\x12\x44RAGON_BREATH_FAST\x10\xcc\x01\x12\x17\n\x12THUNDER_SHOCK_FAST\x10\xcd\x01\x12\x0f\n\nSPARK_FAST\x10\xce\x01\x12\x12\n\rLOW_KICK_FAST\x10\xcf\x01\x12\x15\n\x10KARATE_CHOP_FAST\x10\xd0\x01\x12\x0f\n\nEMBER_FAST\x10\xd1\x01\x12\x15\n\x10WING_ATTACK_FAST\x10\xd2\x01\x12\x0e\n\tPECK_FAST\x10\xd3\x01\x12\x0e\n\tLICK_FAST\x10\xd4\x01\x12\x15\n\x10SHADOW_CLAW_FAST\x10\xd5\x01\x12\x13\n\x0eVINE_WHIP_FAST\x10\xd6\x01\x12\x14\n\x0fRAZOR_LEAF_FAST\x10\xd7\x01\x12\x12\n\rMUD_SHOT_FAST\x10\xd8\x01\x12\x13\n\x0eICE_SHARD_FAST\x10\xd9\x01\x12\x16\n\x11\x46ROST_BREATH_FAST\x10\xda\x01\x12\x16\n\x11QUICK_ATTACK_FAST\x10\xdb\x01\x12\x11\n\x0cSCRATCH_FAST\x10\xdc\x01\x12\x10\n\x0bTACKLE_FAST\x10\xdd\x01\x12\x0f\n\nPOUND_FAST\x10\xde\x01\x12\r\n\x08\x43UT_FAST\x10\xdf\x01\x12\x14\n\x0fPOISON_JAB_FAST\x10\xe0\x01\x12\x0e\n\tACID_FAST\x10\xe1\x01\x12\x14\n\x0fPSYCHO_CUT_FAST\x10\xe2\x01\x12\x14\n\x0fROCK_THROW_FAST\x10\xe3\x01\x12\x14\n\x0fMETAL_CLAW_FAST\x10\xe4\x01\x12\x16\n\x11\x42ULLET_PUNCH_FAST\x10\xe5\x01\x12\x13\n\x0eWATER_GUN_FAST\x10\xe6\x01\x12\x10\n\x0bSPLASH_FAST\x10\xe7\x01\x12\x1d\n\x18WATER_GUN_FAST_BLASTOISE\x10\xe8\x01\x12\x12\n\rMUD_SLAP_FAST\x10\xe9\x01\x12\x16\n\x11ZEN_HEADBUTT_FAST\x10\xea\x01\x12\x13\n\x0e\x43ONFUSION_FAST\x10\xeb\x01\x12\x16\n\x11POISON_STING_FAST\x10\xec\x01\x12\x10\n\x0b\x42UBBLE_FAST\x10\xed\x01\x12\x16\n\x11\x46\x45INT_ATTACK_FAST\x10\xee\x01\x12\x14\n\x0fSTEEL_WING_FAST\x10\xef\x01\x12\x13\n\x0e\x46IRE_FANG_FAST\x10\xf0\x01\x12\x14\n\x0fROCK_SMASH_FAST\x10\xf1\x01*\xc9\x05\n\x08ItemType\x12\x10\n\x0cITEM_UNKNOWN\x10\x00\x12\x12\n\x0eITEM_POKE_BALL\x10\x01\x12\x13\n\x0fITEM_GREAT_BALL\x10\x02\x12\x13\n\x0fITEM_ULTRA_BALL\x10\x03\x12\x14\n\x10ITEM_MASTER_BALL\x10\x04\x12\x0f\n\x0bITEM_POTION\x10\x65\x12\x15\n\x11ITEM_SUPER_POTION\x10\x66\x12\x15\n\x11ITEM_HYPER_POTION\x10g\x12\x13\n\x0fITEM_MAX_POTION\x10h\x12\x10\n\x0bITEM_REVIVE\x10\xc9\x01\x12\x14\n\x0fITEM_MAX_REVIVE\x10\xca\x01\x12\x13\n\x0eITEM_LUCKY_EGG\x10\xad\x02\x12\x1a\n\x15ITEM_INCENSE_ORDINARY\x10\x91\x03\x12\x17\n\x12ITEM_INCENSE_SPICY\x10\x92\x03\x12\x16\n\x11ITEM_INCENSE_COOL\x10\x93\x03\x12\x18\n\x13ITEM_INCENSE_FLORAL\x10\x94\x03\x12\x13\n\x0eITEM_TROY_DISK\x10\xf5\x03\x12\x12\n\rITEM_X_ATTACK\x10\xda\x04\x12\x13\n\x0eITEM_X_DEFENSE\x10\xdb\x04\x12\x13\n\x0eITEM_X_MIRACLE\x10\xdc\x04\x12\x14\n\x0fITEM_RAZZ_BERRY\x10\xbd\x05\x12\x14\n\x0fITEM_BLUK_BERRY\x10\xbe\x05\x12\x15\n\x10ITEM_NANAB_BERRY\x10\xbf\x05\x12\x15\n\x10ITEM_WEPAR_BERRY\x10\xc0\x05\x12\x15\n\x10ITEM_PINAP_BERRY\x10\xc1\x05\x12\x18\n\x13ITEM_SPECIAL_CAMERA\x10\xa1\x06\x12#\n\x1eITEM_INCUBATOR_BASIC_UNLIMITED\x10\x85\x07\x12\x19\n\x14ITEM_INCUBATOR_BASIC\x10\x86\x07\x12!\n\x1cITEM_POKEMON_STORAGE_UPGRADE\x10\xe9\x07\x12\x1e\n\x19ITEM_ITEM_STORAGE_UPGRADE\x10\xea\x07*b\n\x14InventoryUpgradeType\x12\x11\n\rUPGRADE_UNSET\x10\x00\x12\x19\n\x15INCREASE_ITEM_STORAGE\x10\x01\x12\x1c\n\x18INCREASE_POKEMON_STORAGE\x10\x02*\xba\x02\n\x10ItemTypeCategory\x12\x12\n\x0eITEM_TYPE_NONE\x10\x00\x12\x16\n\x12ITEM_TYPE_POKEBALL\x10\x01\x12\x14\n\x10ITEM_TYPE_POTION\x10\x02\x12\x14\n\x10ITEM_TYPE_REVIVE\x10\x03\x12\x11\n\rITEM_TYPE_MAP\x10\x04\x12\x14\n\x10ITEM_TYPE_BATTLE\x10\x05\x12\x12\n\x0eITEM_TYPE_FOOD\x10\x06\x12\x14\n\x10ITEM_TYPE_CAMERA\x10\x07\x12\x12\n\x0eITEM_TYPE_DISK\x10\x08\x12\x17\n\x13ITEM_TYPE_INCUBATOR\x10\t\x12\x15\n\x11ITEM_TYPE_INCENSE\x10\n\x12\x16\n\x12ITEM_TYPE_XP_BOOST\x10\x0b\x12\x1f\n\x1bITEM_TYPE_INVENTORY_UPGRADE\x10\x0c*?\n\x10\x45ggIncubatorType\x12\x13\n\x0fINCUBATOR_UNSET\x10\x00\x12\x16\n\x12INCUBATOR_DISTANCE\x10\x01*\xdd\x0c\n\x0fPokemonFamilyId\x12\x10\n\x0c\x46\x41MILY_UNSET\x10\x00\x12\x14\n\x10\x46\x41MILY_BULBASAUR\x10\x01\x12\x15\n\x11\x46\x41MILY_CHARMANDER\x10\x04\x12\x13\n\x0f\x46\x41MILY_SQUIRTLE\x10\x07\x12\x13\n\x0f\x46\x41MILY_CATERPIE\x10\n\x12\x11\n\rFAMILY_WEEDLE\x10\r\x12\x11\n\rFAMILY_PIDGEY\x10\x10\x12\x12\n\x0e\x46\x41MILY_RATTATA\x10\x13\x12\x12\n\x0e\x46\x41MILY_SPEAROW\x10\x15\x12\x10\n\x0c\x46\x41MILY_EKANS\x10\x17\x12\x12\n\x0e\x46\x41MILY_PIKACHU\x10\x19\x12\x14\n\x10\x46\x41MILY_SANDSHREW\x10\x1b\x12\x12\n\x0e\x46\x41MILY_NIDORAN\x10\x1d\x12\x13\n\x0f\x46\x41MILY_NIDORAN2\x10 \x12\x13\n\x0f\x46\x41MILY_CLEFAIRY\x10#\x12\x11\n\rFAMILY_VULPIX\x10%\x12\x15\n\x11\x46\x41MILY_JIGGLYPUFF\x10\'\x12\x10\n\x0c\x46\x41MILY_ZUBAT\x10)\x12\x11\n\rFAMILY_ODDISH\x10+\x12\x10\n\x0c\x46\x41MILY_PARAS\x10.\x12\x12\n\x0e\x46\x41MILY_VENONAT\x10\x30\x12\x12\n\x0e\x46\x41MILY_DIGLETT\x10\x32\x12\x11\n\rFAMILY_MEOWTH\x10\x34\x12\x12\n\x0e\x46\x41MILY_PSYDUCK\x10\x36\x12\x11\n\rFAMILY_MANKEY\x10\x38\x12\x14\n\x10\x46\x41MILY_GROWLITHE\x10:\x12\x12\n\x0e\x46\x41MILY_POLIWAG\x10<\x12\x0f\n\x0b\x46\x41MILY_ABRA\x10?\x12\x11\n\rFAMILY_MACHOP\x10\x42\x12\x15\n\x11\x46\x41MILY_BELLSPROUT\x10\x45\x12\x14\n\x10\x46\x41MILY_TENTACOOL\x10H\x12\x12\n\x0e\x46\x41MILY_GEODUDE\x10J\x12\x11\n\rFAMILY_PONYTA\x10M\x12\x13\n\x0f\x46\x41MILY_SLOWPOKE\x10O\x12\x14\n\x10\x46\x41MILY_MAGNEMITE\x10Q\x12\x14\n\x10\x46\x41MILY_FARFETCHD\x10S\x12\x10\n\x0c\x46\x41MILY_DODUO\x10T\x12\x0f\n\x0b\x46\x41MILY_SEEL\x10V\x12\x11\n\rFAMILY_GRIMER\x10X\x12\x13\n\x0f\x46\x41MILY_SHELLDER\x10Z\x12\x11\n\rFAMILY_GASTLY\x10\\\x12\x0f\n\x0b\x46\x41MILY_ONIX\x10_\x12\x12\n\x0e\x46\x41MILY_DROWZEE\x10`\x12\x11\n\rFAMILY_KRABBY\x10\x62\x12\x12\n\x0e\x46\x41MILY_VOLTORB\x10\x64\x12\x14\n\x10\x46\x41MILY_EXEGGCUTE\x10\x66\x12\x11\n\rFAMILY_CUBONE\x10h\x12\x14\n\x10\x46\x41MILY_HITMONLEE\x10j\x12\x15\n\x11\x46\x41MILY_HITMONCHAN\x10k\x12\x14\n\x10\x46\x41MILY_LICKITUNG\x10l\x12\x12\n\x0e\x46\x41MILY_KOFFING\x10m\x12\x12\n\x0e\x46\x41MILY_RHYHORN\x10o\x12\x12\n\x0e\x46\x41MILY_CHANSEY\x10q\x12\x12\n\x0e\x46\x41MILY_TANGELA\x10r\x12\x15\n\x11\x46\x41MILY_KANGASKHAN\x10s\x12\x11\n\rFAMILY_HORSEA\x10t\x12\x12\n\x0e\x46\x41MILY_GOLDEEN\x10v\x12\x11\n\rFAMILY_STARYU\x10x\x12\x12\n\x0e\x46\x41MILY_MR_MIME\x10z\x12\x12\n\x0e\x46\x41MILY_SCYTHER\x10{\x12\x0f\n\x0b\x46\x41MILY_JYNX\x10|\x12\x15\n\x11\x46\x41MILY_ELECTABUZZ\x10}\x12\x11\n\rFAMILY_MAGMAR\x10~\x12\x11\n\rFAMILY_PINSIR\x10\x7f\x12\x12\n\rFAMILY_TAUROS\x10\x80\x01\x12\x14\n\x0f\x46\x41MILY_MAGIKARP\x10\x81\x01\x12\x12\n\rFAMILY_LAPRAS\x10\x83\x01\x12\x11\n\x0c\x46\x41MILY_DITTO\x10\x84\x01\x12\x11\n\x0c\x46\x41MILY_EEVEE\x10\x85\x01\x12\x13\n\x0e\x46\x41MILY_PORYGON\x10\x89\x01\x12\x13\n\x0e\x46\x41MILY_OMANYTE\x10\x8a\x01\x12\x12\n\rFAMILY_KABUTO\x10\x8c\x01\x12\x16\n\x11\x46\x41MILY_AERODACTYL\x10\x8e\x01\x12\x13\n\x0e\x46\x41MILY_SNORLAX\x10\x8f\x01\x12\x14\n\x0f\x46\x41MILY_ARTICUNO\x10\x90\x01\x12\x12\n\rFAMILY_ZAPDOS\x10\x91\x01\x12\x13\n\x0e\x46\x41MILY_MOLTRES\x10\x92\x01\x12\x13\n\x0e\x46\x41MILY_DRATINI\x10\x93\x01\x12\x12\n\rFAMILY_MEWTWO\x10\x96\x01\x12\x0f\n\nFAMILY_MEW\x10\x97\x01*E\n\x10MapObjectsStatus\x12\x10\n\x0cUNSET_STATUS\x10\x00\x12\x0b\n\x07SUCCESS\x10\x01\x12\x12\n\x0eLOCATION_UNSET\x10\x02*#\n\x08\x46ortType\x12\x07\n\x03GYM\x10\x00\x12\x0e\n\nCHECKPOINT\x10\x01*\x93\x10\n\tPokemonId\x12\r\n\tMISSINGNO\x10\x00\x12\r\n\tBULBASAUR\x10\x01\x12\x0b\n\x07IVYSAUR\x10\x02\x12\x0c\n\x08VENUSAUR\x10\x03\x12\x0e\n\nCHARMENDER\x10\x04\x12\x0e\n\nCHARMELEON\x10\x05\x12\r\n\tCHARIZARD\x10\x06\x12\x0c\n\x08SQUIRTLE\x10\x07\x12\r\n\tWARTORTLE\x10\x08\x12\r\n\tBLASTOISE\x10\t\x12\x0c\n\x08\x43\x41TERPIE\x10\n\x12\x0b\n\x07METAPOD\x10\x0b\x12\x0e\n\nBUTTERFREE\x10\x0c\x12\n\n\x06WEEDLE\x10\r\x12\n\n\x06KAKUNA\x10\x0e\x12\x0c\n\x08\x42\x45\x45\x44RILL\x10\x0f\x12\n\n\x06PIDGEY\x10\x10\x12\r\n\tPIDGEOTTO\x10\x11\x12\x0b\n\x07PIDGEOT\x10\x12\x12\x0b\n\x07RATTATA\x10\x13\x12\x0c\n\x08RATICATE\x10\x14\x12\x0b\n\x07SPEAROW\x10\x15\x12\n\n\x06\x46\x45\x41ROW\x10\x16\x12\t\n\x05\x45KANS\x10\x17\x12\t\n\x05\x41RBOK\x10\x18\x12\x0b\n\x07PIKACHU\x10\x19\x12\n\n\x06RAICHU\x10\x1a\x12\r\n\tSANDSHREW\x10\x1b\x12\x0c\n\x08SANDLASH\x10\x1c\x12\x12\n\x0eNIDORAN_FEMALE\x10\x1d\x12\x0c\n\x08NIDORINA\x10\x1e\x12\r\n\tNIDOQUEEN\x10\x1f\x12\x10\n\x0cNIDORAN_MALE\x10 \x12\x0c\n\x08NIDORINO\x10!\x12\x0c\n\x08NIDOKING\x10\"\x12\x0b\n\x07\x43LEFARY\x10#\x12\x0c\n\x08\x43LEFABLE\x10$\x12\n\n\x06VULPIX\x10%\x12\r\n\tNINETALES\x10&\x12\x0e\n\nJIGGLYPUFF\x10\'\x12\x0e\n\nWIGGLYTUFF\x10(\x12\t\n\x05ZUBAT\x10)\x12\n\n\x06GOLBAT\x10*\x12\n\n\x06ODDISH\x10+\x12\t\n\x05GLOOM\x10,\x12\r\n\tVILEPLUME\x10-\x12\t\n\x05PARAS\x10.\x12\x0c\n\x08PARASECT\x10/\x12\x0b\n\x07VENONAT\x10\x30\x12\x0c\n\x08VENOMOTH\x10\x31\x12\x0b\n\x07\x44IGLETT\x10\x32\x12\x0b\n\x07\x44UGTRIO\x10\x33\x12\n\n\x06MEOWTH\x10\x34\x12\x0b\n\x07PERSIAN\x10\x35\x12\x0b\n\x07PSYDUCK\x10\x36\x12\x0b\n\x07GOLDUCK\x10\x37\x12\n\n\x06MANKEY\x10\x38\x12\x0c\n\x08PRIMEAPE\x10\x39\x12\r\n\tGROWLITHE\x10:\x12\x0c\n\x08\x41RCANINE\x10;\x12\x0b\n\x07POLIWAG\x10<\x12\r\n\tPOLIWHIRL\x10=\x12\r\n\tPOLIWRATH\x10>\x12\x08\n\x04\x41\x42RA\x10?\x12\x0b\n\x07KADABRA\x10@\x12\r\n\tALAKHAZAM\x10\x41\x12\n\n\x06MACHOP\x10\x42\x12\x0b\n\x07MACHOKE\x10\x43\x12\x0b\n\x07MACHAMP\x10\x44\x12\x0e\n\nBELLSPROUT\x10\x45\x12\x0e\n\nWEEPINBELL\x10\x46\x12\x0f\n\x0bVICTREEBELL\x10G\x12\r\n\tTENTACOOL\x10H\x12\x0e\n\nTENTACRUEL\x10I\x12\x0b\n\x07GEODUGE\x10J\x12\x0c\n\x08GRAVELER\x10K\x12\t\n\x05GOLEM\x10L\x12\n\n\x06PONYTA\x10M\x12\x0c\n\x08RAPIDASH\x10N\x12\x0c\n\x08SLOWPOKE\x10O\x12\x0b\n\x07SLOWBRO\x10P\x12\r\n\tMAGNEMITE\x10Q\x12\x0c\n\x08MAGNETON\x10R\x12\r\n\tFARFETCHD\x10S\x12\t\n\x05\x44ODUO\x10T\x12\n\n\x06\x44ODRIO\x10U\x12\x08\n\x04SEEL\x10V\x12\x0b\n\x07\x44\x45WGONG\x10W\x12\n\n\x06GRIMER\x10X\x12\x07\n\x03MUK\x10Y\x12\x0c\n\x08SHELLDER\x10Z\x12\x0c\n\x08\x43LOYSTER\x10[\x12\n\n\x06GASTLY\x10\\\x12\x0b\n\x07HAUNTER\x10]\x12\n\n\x06GENGAR\x10^\x12\x08\n\x04ONIX\x10_\x12\x0b\n\x07\x44ROWZEE\x10`\x12\t\n\x05HYPNO\x10\x61\x12\n\n\x06KRABBY\x10\x62\x12\x0b\n\x07KINGLER\x10\x63\x12\x0b\n\x07VOLTORB\x10\x64\x12\r\n\tELECTRODE\x10\x65\x12\r\n\tEXEGGCUTE\x10\x66\x12\r\n\tEXEGGUTOR\x10g\x12\n\n\x06\x43UBONE\x10h\x12\x0b\n\x07MAROWAK\x10i\x12\r\n\tHITMONLEE\x10j\x12\x0e\n\nHITMONCHAN\x10k\x12\r\n\tLICKITUNG\x10l\x12\x0b\n\x07KOFFING\x10m\x12\x0b\n\x07WEEZING\x10n\x12\x0b\n\x07RHYHORN\x10o\x12\n\n\x06RHYDON\x10p\x12\x0b\n\x07\x43HANSEY\x10q\x12\x0b\n\x07TANGELA\x10r\x12\x0e\n\nKANGASKHAN\x10s\x12\n\n\x06HORSEA\x10t\x12\n\n\x06SEADRA\x10u\x12\x0b\n\x07GOLDEEN\x10v\x12\x0b\n\x07SEAKING\x10w\x12\n\n\x06STARYU\x10x\x12\x0b\n\x07STARMIE\x10y\x12\x0b\n\x07MR_MIME\x10z\x12\x0b\n\x07SCYTHER\x10{\x12\x08\n\x04JYNX\x10|\x12\x0e\n\nELECTABUZZ\x10}\x12\n\n\x06MAGMAR\x10~\x12\n\n\x06PINSIR\x10\x7f\x12\x0b\n\x06TAUROS\x10\x80\x01\x12\r\n\x08MAGIKARP\x10\x81\x01\x12\r\n\x08GYARADOS\x10\x82\x01\x12\x0b\n\x06LAPRAS\x10\x83\x01\x12\n\n\x05\x44ITTO\x10\x84\x01\x12\n\n\x05\x45\x45VEE\x10\x85\x01\x12\r\n\x08VAPOREON\x10\x86\x01\x12\x0c\n\x07JOLTEON\x10\x87\x01\x12\x0c\n\x07\x46LAREON\x10\x88\x01\x12\x0c\n\x07PORYGON\x10\x89\x01\x12\x0c\n\x07OMANYTE\x10\x8a\x01\x12\x0c\n\x07OMASTAR\x10\x8b\x01\x12\x0b\n\x06KABUTO\x10\x8c\x01\x12\r\n\x08KABUTOPS\x10\x8d\x01\x12\x0f\n\nAERODACTYL\x10\x8e\x01\x12\x0c\n\x07SNORLAX\x10\x8f\x01\x12\r\n\x08\x41RTICUNO\x10\x90\x01\x12\x0b\n\x06ZAPDOS\x10\x91\x01\x12\x0c\n\x07MOLTRES\x10\x92\x01\x12\x0c\n\x07\x44RATINI\x10\x93\x01\x12\x0e\n\tDRAGONAIR\x10\x94\x01\x12\x0e\n\tDRAGONITE\x10\x95\x01\x12\x0b\n\x06MEWTWO\x10\x96\x01\x12\x08\n\x03MEW\x10\x97\x01*B\n\x0b\x46ortSponsor\x12\x11\n\rUNSET_SPONSOR\x10\x00\x12\r\n\tMCDONALDS\x10\x01\x12\x11\n\rPOKEMON_STORE\x10\x02*3\n\x11\x46ortRenderingType\x12\x0b\n\x07\x44\x45\x46\x41ULT\x10\x00\x12\x11\n\rINTERNAL_TEST\x10\x01')
)
_sym_db.RegisterFileDescriptor(DESCRIPTOR)
_RPCDIRECTION = _descriptor.EnumDescriptor(
  name='RpcDirection',
  full_name='RpcEnum.RpcDirection',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='UNKNOWN', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RESPONSE', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='REQUEST', index=2, number=2,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=26,
  serialized_end=80,
)
_sym_db.RegisterEnumDescriptor(_RPCDIRECTION)
RpcDirection = enum_type_wrapper.EnumTypeWrapper(_RPCDIRECTION)
_TEAMCOLOR = _descriptor.EnumDescriptor(
  name='TeamColor',
  full_name='RpcEnum.TeamColor',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='NEUTRAL', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BLUE', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RED', index=2, number=2,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='YELLOW', index=3, number=3,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=82,
  serialized_end=137,
)
_sym_db.RegisterEnumDescriptor(_TEAMCOLOR)
TeamColor = enum_type_wrapper.EnumTypeWrapper(_TEAMCOLOR)
_REQUESTMETHOD = _descriptor.EnumDescriptor(
  name='RequestMethod',
  full_name='RpcEnum.RequestMethod',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='METHOD_UNSET', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PLAYER_UPDATE', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_PLAYER', index=2, number=2,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_INVENTORY', index=3, number=4,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DOWNLOAD_SETTINGS', index=4, number=5,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DOWNLOAD_ITEM_TEMPLATES', index=5, number=6,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DOWNLOAD_REMOTE_CONFIG_VERSION', index=6, number=7,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FORT_SEARCH', index=7, number=101,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ENCOUNTER', index=8, number=102,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CATCH_POKEMON', index=9, number=103,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FORT_DETAILS', index=10, number=104,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_USE', index=11, number=105,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_MAP_OBJECTS', index=12, number=106,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FORT_DEPLOY_POKEMON', index=13, number=110,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FORT_RECALL_POKEMON', index=14, number=111,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RELEASE_POKEMON', index=15, number=112,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='USE_ITEM_POTION', index=16, number=113,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='USE_ITEM_CAPTURE', index=17, number=114,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='USE_ITEM_FLEE', index=18, number=115,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='USE_ITEM_REVIVE', index=19, number=116,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TRADE_SEARCH', index=20, number=117,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TRADE_OFFER', index=21, number=118,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TRADE_RESPONSE', index=22, number=119,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TRADE_RESULT', index=23, number=120,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_PLAYER_PROFILE', index=24, number=121,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_ITEM_PACK', index=25, number=122,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BUY_ITEM_PACK', index=26, number=123,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BUY_GEM_PACK', index=27, number=124,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='EVOLVE_POKEMON', index=28, number=125,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_HATCHED_EGGS', index=29, number=126,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ENCOUNTER_TUTORIAL_COMPLETE', index=30, number=127,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LEVEL_UP_REWARDS', index=31, number=128,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CHECK_AWARDED_BADGES', index=32, number=129,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='USE_ITEM_GYM', index=33, number=133,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_GYM_DETAILS', index=34, number=134,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='START_GYM_BATTLE', index=35, number=135,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ATTACK_GYM', index=36, number=136,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RECYCLE_INVENTORY_ITEM', index=37, number=137,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='COLLECT_DAILY_BONUS', index=38, number=138,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='USE_ITEM_XP_BOOST', index=39, number=139,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='USE_ITEM_EGG_INCUBATOR', index=40, number=140,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='USE_INCENSE', index=41, number=141,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_INCENSE_POKEMON', index=42, number=142,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='INCENSE_ENCOUNTER', index=43, number=143,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ADD_FORT_MODIFIER', index=44, number=144,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DISK_ENCOUNTER', index=45, number=145,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='COLLECT_DAILY_DEFENDER_BONUS', index=46, number=146,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='UPGRADE_POKEMON', index=47, number=147,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SET_FAVORITE_POKEMON', index=48, number=148,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='NICKNAME_POKEMON', index=49, number=149,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='EQUIP_BADGE', index=50, number=150,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SET_CONTACT_SETTINGS', index=51, number=151,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_ASSET_DIGEST', index=52, number=300,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_DOWNLOAD_URLS', index=53, number=301,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GET_SUGGESTED_CODENAMES', index=54, number=401,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CHECK_CODENAME_AVAILABLE', index=55, number=402,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CLAIM_CODENAME', index=56, number=403,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SET_AVATAR', index=57, number=404,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SET_PLAYER_TEAM', index=58, number=405,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MARK_TUTORIAL_COMPLETE', index=59, number=406,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LOAD_SPAWN_POINTS', index=60, number=500,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ECHO', index=61, number=666,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DEBUG_UPDATE_INVENTORY', index=62, number=700,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DEBUG_DELETE_PLAYER', index=63, number=701,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SFIDA_REGISTRATION', index=64, number=800,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SFIDA_ACTION_LOG', index=65, number=801,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SFIDA_CERTIFICATION', index=66, number=802,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SFIDA_UPDATE', index=67, number=803,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SFIDA_ACTION', index=68, number=804,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SFIDA_DOWSER', index=69, number=805,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SFIDA_CAPTURE', index=70, number=806,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=140,
  serialized_end=1743,
)
_sym_db.RegisterEnumDescriptor(_REQUESTMETHOD)
RequestMethod = enum_type_wrapper.EnumTypeWrapper(_REQUESTMETHOD)
_POKEMONMOVE = _descriptor.EnumDescriptor(
  name='PokemonMove',
  full_name='RpcEnum.PokemonMove',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='MOVE_UNSET', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='THUNDER_SHOCK', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='QUICK_ATTACK', index=2, number=2,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SCRATCH', index=3, number=3,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='EMBER', index=4, number=4,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VINE_WHIP', index=5, number=5,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TACKLE', index=6, number=6,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RAZOR_LEAF', index=7, number=7,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TAKE_DOWN', index=8, number=8,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WATER_GUN', index=9, number=9,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BITE', index=10, number=10,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POUND', index=11, number=11,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DOUBLE_SLAP', index=12, number=12,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WRAP', index=13, number=13,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HYPER_BEAM', index=14, number=14,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LICK', index=15, number=15,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DARK_PULSE', index=16, number=16,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SMOG', index=17, number=17,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SLUDGE', index=18, number=18,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='METAL_CLAW', index=19, number=19,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VICE_GRIP', index=20, number=20,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FLAME_WHEEL', index=21, number=21,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MEGAHORN', index=22, number=22,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WING_ATTACK', index=23, number=23,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FLAMETHROWER', index=24, number=24,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SUCKER_PUNCH', index=25, number=25,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DIG', index=26, number=26,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LOW_KICK', index=27, number=27,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CROSS_CHOP', index=28, number=28,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PSYCHO_CUT', index=29, number=29,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PSYBEAM', index=30, number=30,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='EARTHQUAKE', index=31, number=31,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='STONE_EDGE', index=32, number=32,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ICE_PUNCH', index=33, number=33,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HEART_STAMP', index=34, number=34,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DISCHARGE', index=35, number=35,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FLASH_CANNON', index=36, number=36,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PECK', index=37, number=37,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DRILL_PECK', index=38, number=38,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ICE_BEAM', index=39, number=39,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BLIZZARD', index=40, number=40,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='AIR_SLASH', index=41, number=41,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HEAT_WAVE', index=42, number=42,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TWINEEDLE', index=43, number=43,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POISON_JAB', index=44, number=44,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='AERIAL_ACE', index=45, number=45,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DRILL_RUN', index=46, number=46,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PETAL_BLIZZARD', index=47, number=47,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MEGA_DRAIN', index=48, number=48,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BUG_BUZZ', index=49, number=49,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POISON_FANG', index=50, number=50,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='NIGHT_SLASH', index=51, number=51,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SLASH', index=52, number=52,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BUBBLE_BEAM', index=53, number=53,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SUBMISSION', index=54, number=54,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='KARATE_CHOP', index=55, number=55,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LOW_SWEEP', index=56, number=56,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='AQUA_JET', index=57, number=57,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='AQUA_TAIL', index=58, number=58,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SEED_BOMB', index=59, number=59,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PSYSHOCK', index=60, number=60,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ROCK_THROW', index=61, number=61,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ANCIENT_POWER', index=62, number=62,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ROCK_TOMB', index=63, number=63,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ROCK_SLIDE', index=64, number=64,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POWER_GEM', index=65, number=65,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SHADOW_SNEAK', index=66, number=66,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SHADOW_PUNCH', index=67, number=67,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SHADOW_CLAW', index=68, number=68,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='OMINOUS_WIND', index=69, number=69,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SHADOW_BALL', index=70, number=70,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BULLET_PUNCH', index=71, number=71,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MAGNET_BOMB', index=72, number=72,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='STEEL_WING', index=73, number=73,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='IRON_HEAD', index=74, number=74,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PARABOLIC_CHARGE', index=75, number=75,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SPARK', index=76, number=76,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='THUNDER_PUNCH', index=77, number=77,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='THUNDER', index=78, number=78,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='THUNDERBOLT', index=79, number=79,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TWISTER', index=80, number=80,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DRAGON_BREATH', index=81, number=81,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DRAGON_PULSE', index=82, number=82,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DRAGON_CLAW', index=83, number=83,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DISARMING_VOICE', index=84, number=84,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DRAINING_KISS', index=85, number=85,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DAZZLING_GLEAM', index=86, number=86,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MOONBLAST', index=87, number=87,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PLAY_ROUGH', index=88, number=88,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CROSS_POISON', index=89, number=89,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SLUDGE_BOMB', index=90, number=90,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SLUDGE_WAVE', index=91, number=91,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GUNK_SHOT', index=92, number=92,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MUD_SHOT', index=93, number=93,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BONE_CLUB', index=94, number=94,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BULLDOZE', index=95, number=95,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MUD_BOMB', index=96, number=96,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FURY_CUTTER', index=97, number=97,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BUG_BITE', index=98, number=98,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SIGNAL_BEAM', index=99, number=99,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='X_SCISSOR', index=100, number=100,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FLAME_CHARGE', index=101, number=101,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FLAME_BURST', index=102, number=102,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FIRE_BLAST', index=103, number=103,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BRINE', index=104, number=104,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WATER_PULSE', index=105, number=105,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SCALD', index=106, number=106,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HYDRO_PUMP', index=107, number=107,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PSYCHIC', index=108, number=108,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PSYSTRIKE', index=109, number=109,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ICE_SHARD', index=110, number=110,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ICY_WIND', index=111, number=111,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FROST_BREATH', index=112, number=112,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ABSORB', index=113, number=113,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GIGA_DRAIN', index=114, number=114,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FIRE_PUNCH', index=115, number=115,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SOLAR_BEAM', index=116, number=116,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LEAF_BLADE', index=117, number=117,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POWER_WHIP', index=118, number=118,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SPLASH', index=119, number=119,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ACID', index=120, number=120,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='AIR_CUTTER', index=121, number=121,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HURRICANE', index=122, number=122,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BRICK_BREAK', index=123, number=123,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CUT', index=124, number=124,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SWIFT', index=125, number=125,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HORN_ATTACK', index=126, number=126,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='STOMP', index=127, number=127,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HEADBUTT', index=128, number=128,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HYPER_FANG', index=129, number=129,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SLAM', index=130, number=130,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BODY_SLAM', index=131, number=131,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='REST', index=132, number=132,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='STRUGGLE', index=133, number=133,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SCALD_BLASTOISE', index=134, number=134,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HYDRO_PUMP_BLASTOISE', index=135, number=135,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WRAP_GREEN', index=136, number=136,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WRAP_PINK', index=137, number=137,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FURY_CUTTER_FAST', index=138, number=200,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BUG_BITE_FAST', index=139, number=201,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BITE_FAST', index=140, number=202,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SUCKER_PUNCH_FAST', index=141, number=203,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DRAGON_BREATH_FAST', index=142, number=204,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='THUNDER_SHOCK_FAST', index=143, number=205,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SPARK_FAST', index=144, number=206,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LOW_KICK_FAST', index=145, number=207,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='KARATE_CHOP_FAST', index=146, number=208,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='EMBER_FAST', index=147, number=209,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WING_ATTACK_FAST', index=148, number=210,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PECK_FAST', index=149, number=211,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LICK_FAST', index=150, number=212,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SHADOW_CLAW_FAST', index=151, number=213,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VINE_WHIP_FAST', index=152, number=214,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RAZOR_LEAF_FAST', index=153, number=215,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MUD_SHOT_FAST', index=154, number=216,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ICE_SHARD_FAST', index=155, number=217,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FROST_BREATH_FAST', index=156, number=218,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='QUICK_ATTACK_FAST', index=157, number=219,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SCRATCH_FAST', index=158, number=220,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TACKLE_FAST', index=159, number=221,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POUND_FAST', index=160, number=222,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CUT_FAST', index=161, number=223,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POISON_JAB_FAST', index=162, number=224,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ACID_FAST', index=163, number=225,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PSYCHO_CUT_FAST', index=164, number=226,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ROCK_THROW_FAST', index=165, number=227,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='METAL_CLAW_FAST', index=166, number=228,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BULLET_PUNCH_FAST', index=167, number=229,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WATER_GUN_FAST', index=168, number=230,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SPLASH_FAST', index=169, number=231,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WATER_GUN_FAST_BLASTOISE', index=170, number=232,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MUD_SLAP_FAST', index=171, number=233,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ZEN_HEADBUTT_FAST', index=172, number=234,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CONFUSION_FAST', index=173, number=235,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POISON_STING_FAST', index=174, number=236,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BUBBLE_FAST', index=175, number=237,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FEINT_ATTACK_FAST', index=176, number=238,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='STEEL_WING_FAST', index=177, number=239,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FIRE_FANG_FAST', index=178, number=240,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ROCK_SMASH_FAST', index=179, number=241,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=1746,
  serialized_end=4768,
)
_sym_db.RegisterEnumDescriptor(_POKEMONMOVE)
PokemonMove = enum_type_wrapper.EnumTypeWrapper(_POKEMONMOVE)
_ITEMTYPE = _descriptor.EnumDescriptor(
  name='ItemType',
  full_name='RpcEnum.ItemType',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='ITEM_UNKNOWN', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_POKE_BALL', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_GREAT_BALL', index=2, number=2,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_ULTRA_BALL', index=3, number=3,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_MASTER_BALL', index=4, number=4,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_POTION', index=5, number=101,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_SUPER_POTION', index=6, number=102,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_HYPER_POTION', index=7, number=103,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_MAX_POTION', index=8, number=104,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_REVIVE', index=9, number=201,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_MAX_REVIVE', index=10, number=202,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_LUCKY_EGG', index=11, number=301,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_INCENSE_ORDINARY', index=12, number=401,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_INCENSE_SPICY', index=13, number=402,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_INCENSE_COOL', index=14, number=403,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_INCENSE_FLORAL', index=15, number=404,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TROY_DISK', index=16, number=501,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_X_ATTACK', index=17, number=602,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_X_DEFENSE', index=18, number=603,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_X_MIRACLE', index=19, number=604,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_RAZZ_BERRY', index=20, number=701,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_BLUK_BERRY', index=21, number=702,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_NANAB_BERRY', index=22, number=703,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_WEPAR_BERRY', index=23, number=704,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_PINAP_BERRY', index=24, number=705,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_SPECIAL_CAMERA', index=25, number=801,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_INCUBATOR_BASIC_UNLIMITED', index=26, number=901,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_INCUBATOR_BASIC', index=27, number=902,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_POKEMON_STORAGE_UPGRADE', index=28, number=1001,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_ITEM_STORAGE_UPGRADE', index=29, number=1002,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=4771,
  serialized_end=5484,
)
_sym_db.RegisterEnumDescriptor(_ITEMTYPE)
ItemType = enum_type_wrapper.EnumTypeWrapper(_ITEMTYPE)
_INVENTORYUPGRADETYPE = _descriptor.EnumDescriptor(
  name='InventoryUpgradeType',
  full_name='RpcEnum.InventoryUpgradeType',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='UPGRADE_UNSET', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='INCREASE_ITEM_STORAGE', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='INCREASE_POKEMON_STORAGE', index=2, number=2,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=5486,
  serialized_end=5584,
)
_sym_db.RegisterEnumDescriptor(_INVENTORYUPGRADETYPE)
InventoryUpgradeType = enum_type_wrapper.EnumTypeWrapper(_INVENTORYUPGRADETYPE)
_ITEMTYPECATEGORY = _descriptor.EnumDescriptor(
  name='ItemTypeCategory',
  full_name='RpcEnum.ItemTypeCategory',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_NONE', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_POKEBALL', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_POTION', index=2, number=2,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_REVIVE', index=3, number=3,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_MAP', index=4, number=4,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_BATTLE', index=5, number=5,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_FOOD', index=6, number=6,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_CAMERA', index=7, number=7,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_DISK', index=8, number=8,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_INCUBATOR', index=9, number=9,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_INCENSE', index=10, number=10,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_XP_BOOST', index=11, number=11,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ITEM_TYPE_INVENTORY_UPGRADE', index=12, number=12,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=5587,
  serialized_end=5901,
)
_sym_db.RegisterEnumDescriptor(_ITEMTYPECATEGORY)
ItemTypeCategory = enum_type_wrapper.EnumTypeWrapper(_ITEMTYPECATEGORY)
_EGGINCUBATORTYPE = _descriptor.EnumDescriptor(
  name='EggIncubatorType',
  full_name='RpcEnum.EggIncubatorType',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='INCUBATOR_UNSET', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='INCUBATOR_DISTANCE', index=1, number=1,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=5903,
  serialized_end=5966,
)
_sym_db.RegisterEnumDescriptor(_EGGINCUBATORTYPE)
EggIncubatorType = enum_type_wrapper.EnumTypeWrapper(_EGGINCUBATORTYPE)
_POKEMONFAMILYID = _descriptor.EnumDescriptor(
  name='PokemonFamilyId',
  full_name='RpcEnum.PokemonFamilyId',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='FAMILY_UNSET', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_BULBASAUR', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_CHARMANDER', index=2, number=4,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_SQUIRTLE', index=3, number=7,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_CATERPIE', index=4, number=10,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_WEEDLE', index=5, number=13,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_PIDGEY', index=6, number=16,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_RATTATA', index=7, number=19,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_SPEAROW', index=8, number=21,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_EKANS', index=9, number=23,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_PIKACHU', index=10, number=25,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_SANDSHREW', index=11, number=27,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_NIDORAN', index=12, number=29,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_NIDORAN2', index=13, number=32,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_CLEFAIRY', index=14, number=35,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_VULPIX', index=15, number=37,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_JIGGLYPUFF', index=16, number=39,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_ZUBAT', index=17, number=41,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_ODDISH', index=18, number=43,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_PARAS', index=19, number=46,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_VENONAT', index=20, number=48,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_DIGLETT', index=21, number=50,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_MEOWTH', index=22, number=52,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_PSYDUCK', index=23, number=54,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_MANKEY', index=24, number=56,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_GROWLITHE', index=25, number=58,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_POLIWAG', index=26, number=60,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_ABRA', index=27, number=63,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_MACHOP', index=28, number=66,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_BELLSPROUT', index=29, number=69,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_TENTACOOL', index=30, number=72,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_GEODUDE', index=31, number=74,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_PONYTA', index=32, number=77,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_SLOWPOKE', index=33, number=79,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_MAGNEMITE', index=34, number=81,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_FARFETCHD', index=35, number=83,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_DODUO', index=36, number=84,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_SEEL', index=37, number=86,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_GRIMER', index=38, number=88,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_SHELLDER', index=39, number=90,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_GASTLY', index=40, number=92,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_ONIX', index=41, number=95,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_DROWZEE', index=42, number=96,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_KRABBY', index=43, number=98,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_VOLTORB', index=44, number=100,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_EXEGGCUTE', index=45, number=102,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_CUBONE', index=46, number=104,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_HITMONLEE', index=47, number=106,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_HITMONCHAN', index=48, number=107,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_LICKITUNG', index=49, number=108,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_KOFFING', index=50, number=109,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_RHYHORN', index=51, number=111,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_CHANSEY', index=52, number=113,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_TANGELA', index=53, number=114,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_KANGASKHAN', index=54, number=115,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_HORSEA', index=55, number=116,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_GOLDEEN', index=56, number=118,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_STARYU', index=57, number=120,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_MR_MIME', index=58, number=122,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_SCYTHER', index=59, number=123,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_JYNX', index=60, number=124,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_ELECTABUZZ', index=61, number=125,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_MAGMAR', index=62, number=126,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_PINSIR', index=63, number=127,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_TAUROS', index=64, number=128,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_MAGIKARP', index=65, number=129,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_LAPRAS', index=66, number=131,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_DITTO', index=67, number=132,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_EEVEE', index=68, number=133,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_PORYGON', index=69, number=137,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_OMANYTE', index=70, number=138,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_KABUTO', index=71, number=140,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_AERODACTYL', index=72, number=142,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_SNORLAX', index=73, number=143,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_ARTICUNO', index=74, number=144,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_ZAPDOS', index=75, number=145,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_MOLTRES', index=76, number=146,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_DRATINI', index=77, number=147,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_MEWTWO', index=78, number=150,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FAMILY_MEW', index=79, number=151,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=5969,
  serialized_end=7598,
)
_sym_db.RegisterEnumDescriptor(_POKEMONFAMILYID)
PokemonFamilyId = enum_type_wrapper.EnumTypeWrapper(_POKEMONFAMILYID)
_MAPOBJECTSSTATUS = _descriptor.EnumDescriptor(
  name='MapObjectsStatus',
  full_name='RpcEnum.MapObjectsStatus',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='UNSET_STATUS', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SUCCESS', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LOCATION_UNSET', index=2, number=2,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=7600,
  serialized_end=7669,
)
_sym_db.RegisterEnumDescriptor(_MAPOBJECTSSTATUS)
MapObjectsStatus = enum_type_wrapper.EnumTypeWrapper(_MAPOBJECTSSTATUS)
_FORTTYPE = _descriptor.EnumDescriptor(
  name='FortType',
  full_name='RpcEnum.FortType',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='GYM', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CHECKPOINT', index=1, number=1,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=7671,
  serialized_end=7706,
)
_sym_db.RegisterEnumDescriptor(_FORTTYPE)
FortType = enum_type_wrapper.EnumTypeWrapper(_FORTTYPE)
_POKEMONID = _descriptor.EnumDescriptor(
  name='PokemonId',
  full_name='RpcEnum.PokemonId',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='MISSINGNO', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BULBASAUR', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='IVYSAUR', index=2, number=2,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VENUSAUR', index=3, number=3,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CHARMENDER', index=4, number=4,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CHARMELEON', index=5, number=5,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CHARIZARD', index=6, number=6,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SQUIRTLE', index=7, number=7,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WARTORTLE', index=8, number=8,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BLASTOISE', index=9, number=9,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CATERPIE', index=10, number=10,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='METAPOD', index=11, number=11,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BUTTERFREE', index=12, number=12,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WEEDLE', index=13, number=13,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='KAKUNA', index=14, number=14,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BEEDRILL', index=15, number=15,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PIDGEY', index=16, number=16,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PIDGEOTTO', index=17, number=17,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PIDGEOT', index=18, number=18,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RATTATA', index=19, number=19,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RATICATE', index=20, number=20,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SPEAROW', index=21, number=21,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FEAROW', index=22, number=22,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='EKANS', index=23, number=23,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ARBOK', index=24, number=24,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PIKACHU', index=25, number=25,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RAICHU', index=26, number=26,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SANDSHREW', index=27, number=27,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SANDLASH', index=28, number=28,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='NIDORAN_FEMALE', index=29, number=29,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='NIDORINA', index=30, number=30,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='NIDOQUEEN', index=31, number=31,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='NIDORAN_MALE', index=32, number=32,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='NIDORINO', index=33, number=33,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='NIDOKING', index=34, number=34,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CLEFARY', index=35, number=35,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CLEFABLE', index=36, number=36,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VULPIX', index=37, number=37,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='NINETALES', index=38, number=38,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='JIGGLYPUFF', index=39, number=39,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WIGGLYTUFF', index=40, number=40,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ZUBAT', index=41, number=41,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GOLBAT', index=42, number=42,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ODDISH', index=43, number=43,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GLOOM', index=44, number=44,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VILEPLUME', index=45, number=45,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PARAS', index=46, number=46,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PARASECT', index=47, number=47,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VENONAT', index=48, number=48,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VENOMOTH', index=49, number=49,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DIGLETT', index=50, number=50,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DUGTRIO', index=51, number=51,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MEOWTH', index=52, number=52,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PERSIAN', index=53, number=53,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PSYDUCK', index=54, number=54,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GOLDUCK', index=55, number=55,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MANKEY', index=56, number=56,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PRIMEAPE', index=57, number=57,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GROWLITHE', index=58, number=58,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ARCANINE', index=59, number=59,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POLIWAG', index=60, number=60,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POLIWHIRL', index=61, number=61,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POLIWRATH', index=62, number=62,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ABRA', index=63, number=63,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='KADABRA', index=64, number=64,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ALAKHAZAM', index=65, number=65,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MACHOP', index=66, number=66,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MACHOKE', index=67, number=67,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MACHAMP', index=68, number=68,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='BELLSPROUT', index=69, number=69,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WEEPINBELL', index=70, number=70,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VICTREEBELL', index=71, number=71,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TENTACOOL', index=72, number=72,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TENTACRUEL', index=73, number=73,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GEODUGE', index=74, number=74,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GRAVELER', index=75, number=75,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GOLEM', index=76, number=76,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PONYTA', index=77, number=77,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RAPIDASH', index=78, number=78,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SLOWPOKE', index=79, number=79,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SLOWBRO', index=80, number=80,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MAGNEMITE', index=81, number=81,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MAGNETON', index=82, number=82,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FARFETCHD', index=83, number=83,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DODUO', index=84, number=84,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DODRIO', index=85, number=85,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SEEL', index=86, number=86,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DEWGONG', index=87, number=87,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GRIMER', index=88, number=88,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MUK', index=89, number=89,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SHELLDER', index=90, number=90,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CLOYSTER', index=91, number=91,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GASTLY', index=92, number=92,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HAUNTER', index=93, number=93,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GENGAR', index=94, number=94,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ONIX', index=95, number=95,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DROWZEE', index=96, number=96,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HYPNO', index=97, number=97,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='KRABBY', index=98, number=98,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='KINGLER', index=99, number=99,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VOLTORB', index=100, number=100,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ELECTRODE', index=101, number=101,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='EXEGGCUTE', index=102, number=102,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='EXEGGUTOR', index=103, number=103,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CUBONE', index=104, number=104,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MAROWAK', index=105, number=105,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HITMONLEE', index=106, number=106,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HITMONCHAN', index=107, number=107,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LICKITUNG', index=108, number=108,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='KOFFING', index=109, number=109,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='WEEZING', index=110, number=110,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RHYHORN', index=111, number=111,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='RHYDON', index=112, number=112,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='CHANSEY', index=113, number=113,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TANGELA', index=114, number=114,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='KANGASKHAN', index=115, number=115,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='HORSEA', index=116, number=116,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SEADRA', index=117, number=117,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GOLDEEN', index=118, number=118,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SEAKING', index=119, number=119,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='STARYU', index=120, number=120,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='STARMIE', index=121, number=121,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MR_MIME', index=122, number=122,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SCYTHER', index=123, number=123,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='JYNX', index=124, number=124,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ELECTABUZZ', index=125, number=125,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MAGMAR', index=126, number=126,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PINSIR', index=127, number=127,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='TAUROS', index=128, number=128,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MAGIKARP', index=129, number=129,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='GYARADOS', index=130, number=130,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='LAPRAS', index=131, number=131,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DITTO', index=132, number=132,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='EEVEE', index=133, number=133,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='VAPOREON', index=134, number=134,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='JOLTEON', index=135, number=135,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='FLAREON', index=136, number=136,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='PORYGON', index=137, number=137,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='OMANYTE', index=138, number=138,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='OMASTAR', index=139, number=139,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='KABUTO', index=140, number=140,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='KABUTOPS', index=141, number=141,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='AERODACTYL', index=142, number=142,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='SNORLAX', index=143, number=143,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ARTICUNO', index=144, number=144,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='ZAPDOS', index=145, number=145,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MOLTRES', index=146, number=146,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DRATINI', index=147, number=147,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DRAGONAIR', index=148, number=148,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='DRAGONITE', index=149, number=149,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MEWTWO', index=150, number=150,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MEW', index=151, number=151,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=7709,
  serialized_end=9776,
)
_sym_db.RegisterEnumDescriptor(_POKEMONID)
PokemonId = enum_type_wrapper.EnumTypeWrapper(_POKEMONID)
_FORTSPONSOR = _descriptor.EnumDescriptor(
  name='FortSponsor',
  full_name='RpcEnum.FortSponsor',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='UNSET_SPONSOR', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='MCDONALDS', index=1, number=1,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='POKEMON_STORE', index=2, number=2,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=9778,
  serialized_end=9844,
)
_sym_db.RegisterEnumDescriptor(_FORTSPONSOR)
FortSponsor = enum_type_wrapper.EnumTypeWrapper(_FORTSPONSOR)
_FORTRENDERINGTYPE = _descriptor.EnumDescriptor(
  name='FortRenderingType',
  full_name='RpcEnum.FortRenderingType',
  filename=None,
  file=DESCRIPTOR,
  values=[
    _descriptor.EnumValueDescriptor(
      name='DEFAULT', index=0, number=0,
      options=None,
      type=None),
    _descriptor.EnumValueDescriptor(
      name='INTERNAL_TEST', index=1, number=1,
      options=None,
      type=None),
  ],
  containing_type=None,
  options=None,
  serialized_start=9846,
  serialized_end=9897,
)
_sym_db.RegisterEnumDescriptor(_FORTRENDERINGTYPE)
FortRenderingType = enum_type_wrapper.EnumTypeWrapper(_FORTRENDERINGTYPE)
UNKNOWN = 0
RESPONSE = 1
REQUEST = 2
NEUTRAL = 0
BLUE = 1
RED = 2
YELLOW = 3
METHOD_UNSET = 0
PLAYER_UPDATE = 1
GET_PLAYER = 2
GET_INVENTORY = 4
DOWNLOAD_SETTINGS = 5
DOWNLOAD_ITEM_TEMPLATES = 6
DOWNLOAD_REMOTE_CONFIG_VERSION = 7
FORT_SEARCH = 101
ENCOUNTER = 102
CATCH_POKEMON = 103
FORT_DETAILS = 104
ITEM_USE = 105
GET_MAP_OBJECTS = 106
FORT_DEPLOY_POKEMON = 110
FORT_RECALL_POKEMON = 111
RELEASE_POKEMON = 112
USE_ITEM_POTION = 113
USE_ITEM_CAPTURE = 114
USE_ITEM_FLEE = 115
USE_ITEM_REVIVE = 116
TRADE_SEARCH = 117
TRADE_OFFER = 118
TRADE_RESPONSE = 119
TRADE_RESULT = 120
GET_PLAYER_PROFILE = 121
GET_ITEM_PACK = 122
BUY_ITEM_PACK = 123
BUY_GEM_PACK = 124
EVOLVE_POKEMON = 125
GET_HATCHED_EGGS = 126
ENCOUNTER_TUTORIAL_COMPLETE = 127
LEVEL_UP_REWARDS = 128
CHECK_AWARDED_BADGES = 129
USE_ITEM_GYM = 133
GET_GYM_DETAILS = 134
START_GYM_BATTLE = 135
ATTACK_GYM = 136
RECYCLE_INVENTORY_ITEM = 137
COLLECT_DAILY_BONUS = 138
USE_ITEM_XP_BOOST = 139
USE_ITEM_EGG_INCUBATOR = 140
USE_INCENSE = 141
GET_INCENSE_POKEMON = 142
INCENSE_ENCOUNTER = 143
ADD_FORT_MODIFIER = 144
DISK_ENCOUNTER = 145
COLLECT_DAILY_DEFENDER_BONUS = 146
UPGRADE_POKEMON = 147
SET_FAVORITE_POKEMON = 148
NICKNAME_POKEMON = 149
EQUIP_BADGE = 150
SET_CONTACT_SETTINGS = 151
GET_ASSET_DIGEST = 300
GET_DOWNLOAD_URLS = 301
GET_SUGGESTED_CODENAMES = 401
CHECK_CODENAME_AVAILABLE = 402
CLAIM_CODENAME = 403
SET_AVATAR = 404
SET_PLAYER_TEAM = 405
MARK_TUTORIAL_COMPLETE = 406
LOAD_SPAWN_POINTS = 500
ECHO = 666
DEBUG_UPDATE_INVENTORY = 700
DEBUG_DELETE_PLAYER = 701
SFIDA_REGISTRATION = 800
SFIDA_ACTION_LOG = 801
SFIDA_CERTIFICATION = 802
SFIDA_UPDATE = 803
SFIDA_ACTION = 804
SFIDA_DOWSER = 805
SFIDA_CAPTURE = 806
MOVE_UNSET = 0
THUNDER_SHOCK = 1
QUICK_ATTACK = 2
SCRATCH = 3
EMBER = 4
VINE_WHIP = 5
TACKLE = 6
RAZOR_LEAF = 7
TAKE_DOWN = 8
WATER_GUN = 9
BITE = 10
POUND = 11
DOUBLE_SLAP = 12
WRAP = 13
HYPER_BEAM = 14
LICK = 15
DARK_PULSE = 16
SMOG = 17
SLUDGE = 18
METAL_CLAW = 19
VICE_GRIP = 20
FLAME_WHEEL = 21
MEGAHORN = 22
WING_ATTACK = 23
FLAMETHROWER = 24
SUCKER_PUNCH = 25
DIG = 26
LOW_KICK = 27
CROSS_CHOP = 28
PSYCHO_CUT = 29
PSYBEAM = 30
EARTHQUAKE = 31
STONE_EDGE = 32
ICE_PUNCH = 33
HEART_STAMP = 34
DISCHARGE = 35
FLASH_CANNON = 36
PECK = 37
DRILL_PECK = 38
ICE_BEAM = 39
BLIZZARD = 40
AIR_SLASH = 41
HEAT_WAVE = 42
TWINEEDLE = 43
POISON_JAB = 44
AERIAL_ACE = 45
DRILL_RUN = 46
PETAL_BLIZZARD = 47
MEGA_DRAIN = 48
BUG_BUZZ = 49
POISON_FANG = 50
NIGHT_SLASH = 51
SLASH = 52
BUBBLE_BEAM = 53
SUBMISSION = 54
KARATE_CHOP = 55
LOW_SWEEP = 56
AQUA_JET = 57
AQUA_TAIL = 58
SEED_BOMB = 59
PSYSHOCK = 60
ROCK_THROW = 61
ANCIENT_POWER = 62
ROCK_TOMB = 63
ROCK_SLIDE = 64
POWER_GEM = 65
SHADOW_SNEAK = 66
SHADOW_PUNCH = 67
SHADOW_CLAW = 68
OMINOUS_WIND = 69
SHADOW_BALL = 70
BULLET_PUNCH = 71
MAGNET_BOMB = 72
STEEL_WING = 73
IRON_HEAD = 74
PARABOLIC_CHARGE = 75
SPARK = 76
THUNDER_PUNCH = 77
THUNDER = 78
THUNDERBOLT = 79
TWISTER = 80
DRAGON_BREATH = 81
DRAGON_PULSE = 82
DRAGON_CLAW = 83
DISARMING_VOICE = 84
DRAINING_KISS = 85
DAZZLING_GLEAM = 86
MOONBLAST = 87
PLAY_ROUGH = 88
CROSS_POISON = 89
SLUDGE_BOMB = 90
SLUDGE_WAVE = 91
GUNK_SHOT = 92
MUD_SHOT = 93
BONE_CLUB = 94
BULLDOZE = 95
MUD_BOMB = 96
FURY_CUTTER = 97
BUG_BITE = 98
SIGNAL_BEAM = 99
X_SCISSOR = 100
FLAME_CHARGE = 101
FLAME_BURST = 102
FIRE_BLAST = 103
BRINE = 104
WATER_PULSE = 105
SCALD = 106
HYDRO_PUMP = 107
PSYCHIC = 108
PSYSTRIKE = 109
ICE_SHARD = 110
ICY_WIND = 111
FROST_BREATH = 112
ABSORB = 113
GIGA_DRAIN = 114
FIRE_PUNCH = 115
SOLAR_BEAM = 116
LEAF_BLADE = 117
POWER_WHIP = 118
SPLASH = 119
ACID = 120
AIR_CUTTER = 121
HURRICANE = 122
BRICK_BREAK = 123
CUT = 124
SWIFT = 125
HORN_ATTACK = 126
STOMP = 127
HEADBUTT = 128
HYPER_FANG = 129
SLAM = 130
BODY_SLAM = 131
REST = 132
STRUGGLE = 133
SCALD_BLASTOISE = 134
HYDRO_PUMP_BLASTOISE = 135
WRAP_GREEN = 136
WRAP_PINK = 137
FURY_CUTTER_FAST = 200
BUG_BITE_FAST = 201
BITE_FAST = 202
SUCKER_PUNCH_FAST = 203
DRAGON_BREATH_FAST = 204
THUNDER_SHOCK_FAST = 205
SPARK_FAST = 206
LOW_KICK_FAST = 207
KARATE_CHOP_FAST = 208
EMBER_FAST = 209
WING_ATTACK_FAST = 210
PECK_FAST = 211
LICK_FAST = 212
SHADOW_CLAW_FAST = 213
VINE_WHIP_FAST = 214
RAZOR_LEAF_FAST = 215
MUD_SHOT_FAST = 216
ICE_SHARD_FAST = 217
FROST_BREATH_FAST = 218
QUICK_ATTACK_FAST = 219
SCRATCH_FAST = 220
TACKLE_FAST = 221
POUND_FAST = 222
CUT_FAST = 223
POISON_JAB_FAST = 224
ACID_FAST = 225
PSYCHO_CUT_FAST = 226
ROCK_THROW_FAST = 227
METAL_CLAW_FAST = 228
BULLET_PUNCH_FAST = 229
WATER_GUN_FAST = 230
SPLASH_FAST = 231
WATER_GUN_FAST_BLASTOISE = 232
MUD_SLAP_FAST = 233
ZEN_HEADBUTT_FAST = 234
CONFUSION_FAST = 235
POISON_STING_FAST = 236
BUBBLE_FAST = 237
FEINT_ATTACK_FAST = 238
STEEL_WING_FAST = 239
FIRE_FANG_FAST = 240
ROCK_SMASH_FAST = 241
ITEM_UNKNOWN = 0
ITEM_POKE_BALL = 1
ITEM_GREAT_BALL = 2
ITEM_ULTRA_BALL = 3
ITEM_MASTER_BALL = 4
ITEM_POTION = 101
ITEM_SUPER_POTION = 102
ITEM_HYPER_POTION = 103
ITEM_MAX_POTION = 104
ITEM_REVIVE = 201
ITEM_MAX_REVIVE = 202
ITEM_LUCKY_EGG = 301
ITEM_INCENSE_ORDINARY = 401
ITEM_INCENSE_SPICY = 402
ITEM_INCENSE_COOL = 403
ITEM_INCENSE_FLORAL = 404
ITEM_TROY_DISK = 501
ITEM_X_ATTACK = 602
ITEM_X_DEFENSE = 603
ITEM_X_MIRACLE = 604
ITEM_RAZZ_BERRY = 701
ITEM_BLUK_BERRY = 702
ITEM_NANAB_BERRY = 703
ITEM_WEPAR_BERRY = 704
ITEM_PINAP_BERRY = 705
ITEM_SPECIAL_CAMERA = 801
ITEM_INCUBATOR_BASIC_UNLIMITED = 901
ITEM_INCUBATOR_BASIC = 902
ITEM_POKEMON_STORAGE_UPGRADE = 1001
ITEM_ITEM_STORAGE_UPGRADE = 1002
UPGRADE_UNSET = 0
INCREASE_ITEM_STORAGE = 1
INCREASE_POKEMON_STORAGE = 2
ITEM_TYPE_NONE = 0
ITEM_TYPE_POKEBALL = 1
ITEM_TYPE_POTION = 2
ITEM_TYPE_REVIVE = 3
ITEM_TYPE_MAP = 4
ITEM_TYPE_BATTLE = 5
ITEM_TYPE_FOOD = 6
ITEM_TYPE_CAMERA = 7
ITEM_TYPE_DISK = 8
ITEM_TYPE_INCUBATOR = 9
ITEM_TYPE_INCENSE = 10
ITEM_TYPE_XP_BOOST = 11
ITEM_TYPE_INVENTORY_UPGRADE = 12
INCUBATOR_UNSET = 0
INCUBATOR_DISTANCE = 1
FAMILY_UNSET = 0
FAMILY_BULBASAUR = 1
FAMILY_CHARMANDER = 4
FAMILY_SQUIRTLE = 7
FAMILY_CATERPIE = 10
FAMILY_WEEDLE = 13
FAMILY_PIDGEY = 16
FAMILY_RATTATA = 19
FAMILY_SPEAROW = 21
FAMILY_EKANS = 23
FAMILY_PIKACHU = 25
FAMILY_SANDSHREW = 27
FAMILY_NIDORAN = 29
FAMILY_NIDORAN2 = 32
FAMILY_CLEFAIRY = 35
FAMILY_VULPIX = 37
FAMILY_JIGGLYPUFF = 39
FAMILY_ZUBAT = 41
FAMILY_ODDISH = 43
FAMILY_PARAS = 46
FAMILY_VENONAT = 48
FAMILY_DIGLETT = 50
FAMILY_MEOWTH = 52
FAMILY_PSYDUCK = 54
FAMILY_MANKEY = 56
FAMILY_GROWLITHE = 58
FAMILY_POLIWAG = 60
FAMILY_ABRA = 63
FAMILY_MACHOP = 66
FAMILY_BELLSPROUT = 69
FAMILY_TENTACOOL = 72
FAMILY_GEODUDE = 74
FAMILY_PONYTA = 77
FAMILY_SLOWPOKE = 79
FAMILY_MAGNEMITE = 81
FAMILY_FARFETCHD = 83
FAMILY_DODUO = 84
FAMILY_SEEL = 86
FAMILY_GRIMER = 88
FAMILY_SHELLDER = 90
FAMILY_GASTLY = 92
FAMILY_ONIX = 95
FAMILY_DROWZEE = 96
FAMILY_KRABBY = 98
FAMILY_VOLTORB = 100
FAMILY_EXEGGCUTE = 102
FAMILY_CUBONE = 104
FAMILY_HITMONLEE = 106
FAMILY_HITMONCHAN = 107
FAMILY_LICKITUNG = 108
FAMILY_KOFFING = 109
FAMILY_RHYHORN = 111
FAMILY_CHANSEY = 113
FAMILY_TANGELA = 114
FAMILY_KANGASKHAN = 115
FAMILY_HORSEA = 116
FAMILY_GOLDEEN = 118
FAMILY_STARYU = 120
FAMILY_MR_MIME = 122
FAMILY_SCYTHER = 123
FAMILY_JYNX = 124
FAMILY_ELECTABUZZ = 125
FAMILY_MAGMAR = 126
FAMILY_PINSIR = 127
FAMILY_TAUROS = 128
FAMILY_MAGIKARP = 129
FAMILY_LAPRAS = 131
FAMILY_DITTO = 132
FAMILY_EEVEE = 133
FAMILY_PORYGON = 137
FAMILY_OMANYTE = 138
FAMILY_KABUTO = 140
FAMILY_AERODACTYL = 142
FAMILY_SNORLAX = 143
FAMILY_ARTICUNO = 144
FAMILY_ZAPDOS = 145
FAMILY_MOLTRES = 146
FAMILY_DRATINI = 147
FAMILY_MEWTWO = 150
FAMILY_MEW = 151
UNSET_STATUS = 0
SUCCESS = 1
LOCATION_UNSET = 2
GYM = 0
CHECKPOINT = 1
MISSINGNO = 0
BULBASAUR = 1
IVYSAUR = 2
VENUSAUR = 3
CHARMENDER = 4
CHARMELEON = 5
CHARIZARD = 6
SQUIRTLE = 7
WARTORTLE = 8
BLASTOISE = 9
CATERPIE = 10
METAPOD = 11
BUTTERFREE = 12
WEEDLE = 13
KAKUNA = 14
BEEDRILL = 15
PIDGEY = 16
PIDGEOTTO = 17
PIDGEOT = 18
RATTATA = 19
RATICATE = 20
SPEAROW = 21
FEAROW = 22
EKANS = 23
ARBOK = 24
PIKACHU = 25
RAICHU = 26
SANDSHREW = 27
SANDLASH = 28
NIDORAN_FEMALE = 29
NIDORINA = 30
NIDOQUEEN = 31
NIDORAN_MALE = 32
NIDORINO = 33
NIDOKING = 34
CLEFARY = 35
CLEFABLE = 36
VULPIX = 37
NINETALES = 38
JIGGLYPUFF = 39
WIGGLYTUFF = 40
ZUBAT = 41
GOLBAT = 42
ODDISH = 43
GLOOM = 44
VILEPLUME = 45
PARAS = 46
PARASECT = 47
VENONAT = 48
VENOMOTH = 49
DIGLETT = 50
DUGTRIO = 51
MEOWTH = 52
PERSIAN = 53
PSYDUCK = 54
GOLDUCK = 55
MANKEY = 56
PRIMEAPE = 57
GROWLITHE = 58
ARCANINE = 59
POLIWAG = 60
POLIWHIRL = 61
POLIWRATH = 62
ABRA = 63
KADABRA = 64
ALAKHAZAM = 65
MACHOP = 66
MACHOKE = 67
MACHAMP = 68
BELLSPROUT = 69
WEEPINBELL = 70
VICTREEBELL = 71
TENTACOOL = 72
TENTACRUEL = 73
GEODUGE = 74
GRAVELER = 75
GOLEM = 76
PONYTA = 77
RAPIDASH = 78
SLOWPOKE = 79
SLOWBRO = 80
MAGNEMITE = 81
MAGNETON = 82
FARFETCHD = 83
DODUO = 84
DODRIO = 85
SEEL = 86
DEWGONG = 87
GRIMER = 88
MUK = 89
SHELLDER = 90
CLOYSTER = 91
GASTLY = 92
HAUNTER = 93
GENGAR = 94
ONIX = 95
DROWZEE = 96
HYPNO = 97
KRABBY = 98
KINGLER = 99
VOLTORB = 100
ELECTRODE = 101
EXEGGCUTE = 102
EXEGGUTOR = 103
CUBONE = 104
MAROWAK = 105
HITMONLEE = 106
HITMONCHAN = 107
LICKITUNG = 108
KOFFING = 109
WEEZING = 110
RHYHORN = 111
RHYDON = 112
CHANSEY = 113
TANGELA = 114
KANGASKHAN = 115
HORSEA = 116
SEADRA = 117
GOLDEEN = 118
SEAKING = 119
STARYU = 120
STARMIE = 121
MR_MIME = 122
SCYTHER = 123
JYNX = 124
ELECTABUZZ = 125
MAGMAR = 126
PINSIR = 127
TAUROS = 128
MAGIKARP = 129
GYARADOS = 130
LAPRAS = 131
DITTO = 132
EEVEE = 133
VAPOREON = 134
JOLTEON = 135
FLAREON = 136
PORYGON = 137
OMANYTE = 138
OMASTAR = 139
KABUTO = 140
KABUTOPS = 141
AERODACTYL = 142
SNORLAX = 143
ARTICUNO = 144
ZAPDOS = 145
MOLTRES = 146
DRATINI = 147
DRAGONAIR = 148
DRAGONITE = 149
MEWTWO = 150
MEW = 151
UNSET_SPONSOR = 0
MCDONALDS = 1
POKEMON_STORE = 2
DEFAULT = 0
INTERNAL_TEST = 1
DESCRIPTOR.enum_types_by_name['RpcDirection'] = _RPCDIRECTION
DESCRIPTOR.enum_types_by_name['TeamColor'] = _TEAMCOLOR
DESCRIPTOR.enum_types_by_name['RequestMethod'] = _REQUESTMETHOD
DESCRIPTOR.enum_types_by_name['PokemonMove'] = _POKEMONMOVE
DESCRIPTOR.enum_types_by_name['ItemType'] = _ITEMTYPE
DESCRIPTOR.enum_types_by_name['InventoryUpgradeType'] = _INVENTORYUPGRADETYPE
DESCRIPTOR.enum_types_by_name['ItemTypeCategory'] = _ITEMTYPECATEGORY
DESCRIPTOR.enum_types_by_name['EggIncubatorType'] = _EGGINCUBATORTYPE
DESCRIPTOR.enum_types_by_name['PokemonFamilyId'] = _POKEMONFAMILYID
DESCRIPTOR.enum_types_by_name['MapObjectsStatus'] = _MAPOBJECTSSTATUS
DESCRIPTOR.enum_types_by_name['FortType'] = _FORTTYPE
DESCRIPTOR.enum_types_by_name['PokemonId'] = _POKEMONID
DESCRIPTOR.enum_types_by_name['FortSponsor'] = _FORTSPONSOR
DESCRIPTOR.enum_types_by_name['FortRenderingType'] = _FORTRENDERINGTYPE
import sys
_b=sys.version_info[0]<3 and (lambda x:x) or (lambda x:x.encode('latin1'))
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from google.protobuf import reflection as _reflection
from google.protobuf import symbol_database as _symbol_database
_sym_db = _symbol_database.Default()
import RpcEnum_pb2
DESCRIPTOR = _descriptor.FileDescriptor(
  name='RpcEnvelope.proto',
  package='',
  serialized_pb=_b('\n\x11RpcEnvelope.proto\x1a\rRpcEnum.proto\"\xd8\x04\n\x07Request\x12(\n\tdirection\x18\x01 \x02(\x0e\x32\x15.RpcEnum.RpcDirection\x12\x0e\n\x06rpc_id\x18\x03 \x01(\x03\x12#\n\x08requests\x18\x04 \x03(\x0b\x32\x11.Request.Requests\x12#\n\x08unknown6\x18\x06 \x01(\x0b\x32\x11.Request.Unknown6\x12\x10\n\x08latitude\x18\x07 \x01(\x06\x12\x11\n\tlongitude\x18\x08 \x01(\x06\x12\x10\n\x08\x61ltitude\x18\t \x01(\x06\x12\x1f\n\x04\x61uth\x18\n \x01(\x0b\x32\x11.Request.AuthInfo\x12 \n\x0b\x61uth_ticket\x18\x0b \x01(\x0b\x32\x0b.AuthTicket\x12\x11\n\tunknown12\x18\x0c \x01(\x03\x1a\x44\n\x08Requests\x12$\n\x04type\x18\x01 \x02(\x0e\x32\x16.RpcEnum.RequestMethod\x12\x12\n\nparameters\x18\x02 \x01(\x0c\x1an\n\x08\x41uthInfo\x12\x10\n\x08provider\x18\x01 \x02(\t\x12$\n\x05token\x18\x02 \x02(\x0b\x32\x15.Request.AuthInfo.JWT\x1a*\n\x03JWT\x12\x10\n\x08\x63ontents\x18\x01 \x02(\t\x12\x11\n\tunknown13\x18\x02 \x02(\x05\x1a\x1c\n\x08Unknown3\x12\x10\n\x08unknown4\x18\x01 \x02(\t\x1ah\n\x08Unknown6\x12\x10\n\x08unknown1\x18\x01 \x02(\x05\x12,\n\x08unknown2\x18\x02 \x02(\x0b\x32\x1a.Request.Unknown6.Unknown2\x1a\x1c\n\x08Unknown2\x12\x10\n\x08unknown1\x18\x01 \x02(\x0c\"\xe2\x02\n\x08Response\x12(\n\tdirection\x18\x01 \x02(\x0e\x32\x15.RpcEnum.RpcDirection\x12\x10\n\x08unknown2\x18\x02 \x01(\x03\x12\x0f\n\x07\x61pi_url\x18\x03 \x01(\t\x12$\n\x08unknown6\x18\x06 \x02(\x0b\x32\x12.Response.Unknown6\x12 \n\x0b\x61uth_ticket\x18\x07 \x01(\x0b\x32\x0b.AuthTicket\x12\x11\n\tresponses\x18\x64 \x03(\x0c\x1ai\n\x08Unknown6\x12\x10\n\x08unknown1\x18\x01 \x02(\x05\x12-\n\x08unknown2\x18\x02 \x02(\x0b\x32\x1b.Response.Unknown6.Unknown2\x1a\x1c\n\x08Unknown2\x12\x10\n\x08unknown1\x18\x01 \x02(\x0c\x1a\x43\n\x08Unknown7\x12\x11\n\tunknown71\x18\x01 \x01(\x0c\x12\x11\n\tunknown72\x18\x02 \x01(\x03\x12\x11\n\tunknown73\x18\x03 \x01(\x0c\"E\n\nAuthTicket\x12\r\n\x05start\x18\x01 \x01(\x0c\x12\x1b\n\x13\x65xpire_timestamp_ms\x18\x02 \x01(\x04\x12\x0b\n\x03\x65nd\x18\x03 \x01(\x0c')
  ,
  dependencies=[RpcEnum_pb2.DESCRIPTOR,])
_sym_db.RegisterFileDescriptor(DESCRIPTOR)
_REQUEST_REQUESTS = _descriptor.Descriptor(
  name='Requests',
  full_name='Request.Requests',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='type', full_name='Request.Requests.type', index=0,
      number=1, type=14, cpp_type=8, label=2,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='parameters', full_name='Request.Requests.parameters', index=1,
      number=2, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=321,
  serialized_end=389,
)
_REQUEST_AUTHINFO_JWT = _descriptor.Descriptor(
  name='JWT',
  full_name='Request.AuthInfo.JWT',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='contents', full_name='Request.AuthInfo.JWT.contents', index=0,
      number=1, type=9, cpp_type=9, label=2,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown13', full_name='Request.AuthInfo.JWT.unknown13', index=1,
      number=2, type=5, cpp_type=1, label=2,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=459,
  serialized_end=501,
)
_REQUEST_AUTHINFO = _descriptor.Descriptor(
  name='AuthInfo',
  full_name='Request.AuthInfo',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='provider', full_name='Request.AuthInfo.provider', index=0,
      number=1, type=9, cpp_type=9, label=2,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='token', full_name='Request.AuthInfo.token', index=1,
      number=2, type=11, cpp_type=10, label=2,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[_REQUEST_AUTHINFO_JWT, ],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=391,
  serialized_end=501,
)
_REQUEST_UNKNOWN3 = _descriptor.Descriptor(
  name='Unknown3',
  full_name='Request.Unknown3',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='unknown4', full_name='Request.Unknown3.unknown4', index=0,
      number=1, type=9, cpp_type=9, label=2,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=503,
  serialized_end=531,
)
_REQUEST_UNKNOWN6_UNKNOWN2 = _descriptor.Descriptor(
  name='Unknown2',
  full_name='Request.Unknown6.Unknown2',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='unknown1', full_name='Request.Unknown6.Unknown2.unknown1', index=0,
      number=1, type=12, cpp_type=9, label=2,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=609,
  serialized_end=637,
)
_REQUEST_UNKNOWN6 = _descriptor.Descriptor(
  name='Unknown6',
  full_name='Request.Unknown6',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='unknown1', full_name='Request.Unknown6.unknown1', index=0,
      number=1, type=5, cpp_type=1, label=2,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown2', full_name='Request.Unknown6.unknown2', index=1,
      number=2, type=11, cpp_type=10, label=2,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[_REQUEST_UNKNOWN6_UNKNOWN2, ],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=533,
  serialized_end=637,
)
_REQUEST = _descriptor.Descriptor(
  name='Request',
  full_name='Request',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='direction', full_name='Request.direction', index=0,
      number=1, type=14, cpp_type=8, label=2,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='rpc_id', full_name='Request.rpc_id', index=1,
      number=3, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='requests', full_name='Request.requests', index=2,
      number=4, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown6', full_name='Request.unknown6', index=3,
      number=6, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='latitude', full_name='Request.latitude', index=4,
      number=7, type=6, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='longitude', full_name='Request.longitude', index=5,
      number=8, type=6, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='altitude', full_name='Request.altitude', index=6,
      number=9, type=6, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='auth', full_name='Request.auth', index=7,
      number=10, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='auth_ticket', full_name='Request.auth_ticket', index=8,
      number=11, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown12', full_name='Request.unknown12', index=9,
      number=12, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[_REQUEST_REQUESTS, _REQUEST_AUTHINFO, _REQUEST_UNKNOWN3, _REQUEST_UNKNOWN6, ],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=37,
  serialized_end=637,
)
_RESPONSE_UNKNOWN6_UNKNOWN2 = _descriptor.Descriptor(
  name='Unknown2',
  full_name='Response.Unknown6.Unknown2',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='unknown1', full_name='Response.Unknown6.Unknown2.unknown1', index=0,
      number=1, type=12, cpp_type=9, label=2,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=609,
  serialized_end=637,
)
_RESPONSE_UNKNOWN6 = _descriptor.Descriptor(
  name='Unknown6',
  full_name='Response.Unknown6',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='unknown1', full_name='Response.Unknown6.unknown1', index=0,
      number=1, type=5, cpp_type=1, label=2,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown2', full_name='Response.Unknown6.unknown2', index=1,
      number=2, type=11, cpp_type=10, label=2,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[_RESPONSE_UNKNOWN6_UNKNOWN2, ],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=820,
  serialized_end=925,
)
_RESPONSE_UNKNOWN7 = _descriptor.Descriptor(
  name='Unknown7',
  full_name='Response.Unknown7',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='unknown71', full_name='Response.Unknown7.unknown71', index=0,
      number=1, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown72', full_name='Response.Unknown7.unknown72', index=1,
      number=2, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown73', full_name='Response.Unknown7.unknown73', index=2,
      number=3, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=927,
  serialized_end=994,
)
_RESPONSE = _descriptor.Descriptor(
  name='Response',
  full_name='Response',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='direction', full_name='Response.direction', index=0,
      number=1, type=14, cpp_type=8, label=2,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown2', full_name='Response.unknown2', index=1,
      number=2, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='api_url', full_name='Response.api_url', index=2,
      number=3, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown6', full_name='Response.unknown6', index=3,
      number=6, type=11, cpp_type=10, label=2,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='auth_ticket', full_name='Response.auth_ticket', index=4,
      number=7, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='responses', full_name='Response.responses', index=5,
      number=100, type=12, cpp_type=9, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[_RESPONSE_UNKNOWN6, _RESPONSE_UNKNOWN7, ],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=640,
  serialized_end=994,
)
_AUTHTICKET = _descriptor.Descriptor(
  name='AuthTicket',
  full_name='AuthTicket',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='start', full_name='AuthTicket.start', index=0,
      number=1, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='expire_timestamp_ms', full_name='AuthTicket.expire_timestamp_ms', index=1,
      number=2, type=4, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='end', full_name='AuthTicket.end', index=2,
      number=3, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=996,
  serialized_end=1065,
)
_REQUEST_REQUESTS.fields_by_name['type'].enum_type = RpcEnum_pb2._REQUESTMETHOD
_REQUEST_REQUESTS.containing_type = _REQUEST
_REQUEST_AUTHINFO_JWT.containing_type = _REQUEST_AUTHINFO
_REQUEST_AUTHINFO.fields_by_name['token'].message_type = _REQUEST_AUTHINFO_JWT
_REQUEST_AUTHINFO.containing_type = _REQUEST
_REQUEST_UNKNOWN3.containing_type = _REQUEST
_REQUEST_UNKNOWN6_UNKNOWN2.containing_type = _REQUEST_UNKNOWN6
_REQUEST_UNKNOWN6.fields_by_name['unknown2'].message_type = _REQUEST_UNKNOWN6_UNKNOWN2
_REQUEST_UNKNOWN6.containing_type = _REQUEST
_REQUEST.fields_by_name['direction'].enum_type = RpcEnum_pb2._RPCDIRECTION
_REQUEST.fields_by_name['requests'].message_type = _REQUEST_REQUESTS
_REQUEST.fields_by_name['unknown6'].message_type = _REQUEST_UNKNOWN6
_REQUEST.fields_by_name['auth'].message_type = _REQUEST_AUTHINFO
_REQUEST.fields_by_name['auth_ticket'].message_type = _AUTHTICKET
_RESPONSE_UNKNOWN6_UNKNOWN2.containing_type = _RESPONSE_UNKNOWN6
_RESPONSE_UNKNOWN6.fields_by_name['unknown2'].message_type = _RESPONSE_UNKNOWN6_UNKNOWN2
_RESPONSE_UNKNOWN6.containing_type = _RESPONSE
_RESPONSE_UNKNOWN7.containing_type = _RESPONSE
_RESPONSE.fields_by_name['direction'].enum_type = RpcEnum_pb2._RPCDIRECTION
_RESPONSE.fields_by_name['unknown6'].message_type = _RESPONSE_UNKNOWN6
_RESPONSE.fields_by_name['auth_ticket'].message_type = _AUTHTICKET
DESCRIPTOR.message_types_by_name['Request'] = _REQUEST
DESCRIPTOR.message_types_by_name['Response'] = _RESPONSE
DESCRIPTOR.message_types_by_name['AuthTicket'] = _AUTHTICKET
Request = _reflection.GeneratedProtocolMessageType('Request', (_message.Message,), dict(
  Requests = _reflection.GeneratedProtocolMessageType('Requests', (_message.Message,), dict(
    DESCRIPTOR = _REQUEST_REQUESTS,
    __module__ = 'RpcEnvelope_pb2'
    ))
  ,
  AuthInfo = _reflection.GeneratedProtocolMessageType('AuthInfo', (_message.Message,), dict(
    JWT = _reflection.GeneratedProtocolMessageType('JWT', (_message.Message,), dict(
      DESCRIPTOR = _REQUEST_AUTHINFO_JWT,
      __module__ = 'RpcEnvelope_pb2'
      ))
    ,
    DESCRIPTOR = _REQUEST_AUTHINFO,
    __module__ = 'RpcEnvelope_pb2'
    ))
  ,
  Unknown3 = _reflection.GeneratedProtocolMessageType('Unknown3', (_message.Message,), dict(
    DESCRIPTOR = _REQUEST_UNKNOWN3,
    __module__ = 'RpcEnvelope_pb2'
    ))
  ,
  Unknown6 = _reflection.GeneratedProtocolMessageType('Unknown6', (_message.Message,), dict(
    Unknown2 = _reflection.GeneratedProtocolMessageType('Unknown2', (_message.Message,), dict(
      DESCRIPTOR = _REQUEST_UNKNOWN6_UNKNOWN2,
      __module__ = 'RpcEnvelope_pb2'
      ))
    ,
    DESCRIPTOR = _REQUEST_UNKNOWN6,
    __module__ = 'RpcEnvelope_pb2'
    ))
  ,
  DESCRIPTOR = _REQUEST,
  __module__ = 'RpcEnvelope_pb2'
  ))
_sym_db.RegisterMessage(Request)
_sym_db.RegisterMessage(Request.Requests)
_sym_db.RegisterMessage(Request.AuthInfo)
_sym_db.RegisterMessage(Request.AuthInfo.JWT)
_sym_db.RegisterMessage(Request.Unknown3)
_sym_db.RegisterMessage(Request.Unknown6)
_sym_db.RegisterMessage(Request.Unknown6.Unknown2)
Response = _reflection.GeneratedProtocolMessageType('Response', (_message.Message,), dict(
  Unknown6 = _reflection.GeneratedProtocolMessageType('Unknown6', (_message.Message,), dict(
    Unknown2 = _reflection.GeneratedProtocolMessageType('Unknown2', (_message.Message,), dict(
      DESCRIPTOR = _RESPONSE_UNKNOWN6_UNKNOWN2,
      __module__ = 'RpcEnvelope_pb2'
      ))
    ,
    DESCRIPTOR = _RESPONSE_UNKNOWN6,
    __module__ = 'RpcEnvelope_pb2'
    ))
  ,
  Unknown7 = _reflection.GeneratedProtocolMessageType('Unknown7', (_message.Message,), dict(
    DESCRIPTOR = _RESPONSE_UNKNOWN7,
    __module__ = 'RpcEnvelope_pb2'
    ))
  ,
  DESCRIPTOR = _RESPONSE,
  __module__ = 'RpcEnvelope_pb2'
  ))
_sym_db.RegisterMessage(Response)
_sym_db.RegisterMessage(Response.Unknown6)
_sym_db.RegisterMessage(Response.Unknown6.Unknown2)
_sym_db.RegisterMessage(Response.Unknown7)
AuthTicket = _reflection.GeneratedProtocolMessageType('AuthTicket', (_message.Message,), dict(
  DESCRIPTOR = _AUTHTICKET,
  __module__ = 'RpcEnvelope_pb2'
  ))
_sym_db.RegisterMessage(AuthTicket)
import sys
_b=sys.version_info[0]<3 and (lambda x:x) or (lambda x:x.encode('latin1'))
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from google.protobuf import reflection as _reflection
from google.protobuf import symbol_database as _symbol_database
_sym_db = _symbol_database.Default()
import RpcEnum_pb2
DESCRIPTOR = _descriptor.FileDescriptor(
  name='RpcSub.proto',
  package='RpcSub',
  serialized_pb=_b('\n\x0cRpcSub.proto\x12\x06RpcSub\x1a\rRpcEnum.proto\"G\n\x11GetPlayerResponse\x12\x10\n\x08unknown1\x18\x01 \x01(\x05\x12 \n\x07profile\x18\x02 \x01(\x0b\x32\x0f.RpcSub.Profile\"\xac\x02\n\x07Profile\x12\x15\n\rcreation_time\x18\x01 \x02(\x03\x12\x10\n\x08username\x18\x02 \x01(\t\x12 \n\x04team\x18\x05 \x01(\x0e\x32\x12.RpcEnum.TeamColor\x12\x10\n\x08tutorial\x18\x07 \x01(\x0c\x12%\n\x06\x61vatar\x18\x08 \x01(\x0b\x32\x15.RpcSub.AvatarDetails\x12\x14\n\x0cpoke_storage\x18\t \x01(\x05\x12\x14\n\x0citem_storage\x18\n \x01(\x05\x12\'\n\x0b\x64\x61ily_bonus\x18\x0b \x01(\x0b\x32\x12.RpcSub.DailyBonus\x12\x11\n\tunknown12\x18\x0c \x01(\x0c\x12\x11\n\tunknown13\x18\r \x01(\x0c\x12\"\n\x08\x63urrency\x18\x0e \x03(\x0b\x32\x10.RpcSub.Currency\"Y\n\nDailyBonus\x12\x1e\n\x16NextCollectTimestampMs\x18\x01 \x01(\x03\x12+\n#NextDefenderBonusCollectTimestampMs\x18\x02 \x01(\x03\"(\n\x08\x43urrency\x12\x0c\n\x04type\x18\x01 \x02(\t\x12\x0e\n\x06\x61mount\x18\x02 \x01(\x05\"X\n\rAvatarDetails\x12\x10\n\x08unknown2\x18\x02 \x01(\x05\x12\x10\n\x08unknown3\x18\x03 \x01(\x05\x12\x10\n\x08unknown9\x18\t \x01(\x05\x12\x11\n\tunknown10\x18\n \x01(\x05\"\'\n\x17\x44ownloadSettingsRequest\x12\x0c\n\x04hash\x18\x01 \x01(\t\"X\n\x14GetInventoryResponse\x12\x0f\n\x07success\x18\x01 \x01(\x08\x12/\n\x0finventory_delta\x18\x02 \x01(\x0b\x32\x16.RpcSub.InventoryDelta\"y\n\x0eInventoryDelta\x12\x1d\n\x15original_timestamp_ms\x18\x01 \x01(\x03\x12\x18\n\x10new_timestamp_ms\x18\x02 \x01(\x03\x12.\n\x0finventory_items\x18\x03 \x03(\x0b\x32\x15.RpcSub.InventoryItem\"\x80\x01\n\rInventoryItem\x12\x1d\n\x15modified_timestamp_ms\x18\x01 \x01(\x03\x12\x18\n\x10\x64\x65leted_item_key\x18\x02 \x01(\x03\x12\x36\n\x13inventory_item_data\x18\x03 \x01(\x0b\x32\x19.RpcSub.InventoryItemData\"\xc9\x03\n\x11InventoryItemData\x12 \n\x07pokemon\x18\x01 \x01(\x0b\x32\x0f.RpcSub.Pokemon\x12\x1a\n\x04item\x18\x02 \x01(\x0b\x32\x0c.RpcSub.Item\x12+\n\rpokedex_entry\x18\x03 \x01(\x0b\x32\x14.RpcSub.PokedexEntry\x12)\n\x0cplayer_stats\x18\x04 \x01(\x0b\x32\x13.RpcSub.PlayerStats\x12/\n\x0fplayer_currency\x18\x05 \x01(\x0b\x32\x16.RpcSub.PlayerCurrency\x12+\n\rplayer_camera\x18\x06 \x01(\x0b\x32\x14.RpcSub.PlayerCamera\x12\x35\n\x12inventory_upgrades\x18\x07 \x01(\x0b\x32\x19.RpcSub.InventoryUpgrades\x12+\n\rapplied_items\x18\x08 \x01(\x0b\x32\x14.RpcSub.AppliedItems\x12-\n\x0e\x65gg_incubators\x18\t \x01(\x0b\x32\x15.RpcSub.EggIncubators\x12-\n\x0epokemon_family\x18\n \x01(\x0b\x32\x15.RpcSub.PokemonFamily\"\xd8\x05\n\x07Pokemon\x12\n\n\x02id\x18\x01 \x01(\x05\x12(\n\x0cpokemon_type\x18\x02 \x01(\x0e\x32\x12.RpcEnum.PokemonId\x12\n\n\x02\x63p\x18\x03 \x01(\x05\x12\x0f\n\x07stamina\x18\x04 \x01(\x05\x12\x13\n\x0bstamina_max\x18\x05 \x01(\x05\x12$\n\x06move_1\x18\x06 \x01(\x0e\x32\x14.RpcEnum.PokemonMove\x12$\n\x06move_2\x18\x07 \x01(\x0e\x32\x14.RpcEnum.PokemonMove\x12\x18\n\x10\x64\x65ployed_fort_id\x18\x08 \x01(\x05\x12\x12\n\nowner_name\x18\t \x01(\t\x12\x0e\n\x06is_egg\x18\n \x01(\x08\x12\x1c\n\x14\x65gg_km_walked_target\x18\x0b \x01(\x05\x12\x1b\n\x13\x65gg_km_walked_start\x18\x0c \x01(\x05\x12\x0e\n\x06origin\x18\x0e \x01(\x05\x12\x10\n\x08height_m\x18\x0f \x01(\x02\x12\x11\n\tweight_kg\x18\x10 \x01(\x02\x12\x19\n\x11individual_attack\x18\x11 \x01(\x05\x12\x1a\n\x12individual_defense\x18\x12 \x01(\x05\x12\x1a\n\x12individual_stamina\x18\x13 \x01(\x05\x12\x15\n\rcp_multiplier\x18\x14 \x01(\x05\x12\x10\n\x08pokeball\x18\x15 \x01(\x05\x12\x18\n\x10\x63\x61ptured_cell_id\x18\x16 \x01(\x04\x12\x18\n\x10\x62\x61ttles_attacked\x18\x17 \x01(\x05\x12\x18\n\x10\x62\x61ttles_defended\x18\x18 \x01(\x05\x12\x18\n\x10\x65gg_incubator_id\x18\x19 \x01(\x05\x12\x18\n\x10\x63reation_time_ms\x18\x1a \x01(\x04\x12\x14\n\x0cnum_upgrades\x18\x1b \x01(\x05\x12 \n\x18\x61\x64\x64itional_cp_multiplier\x18\x1c \x01(\x05\x12\x10\n\x08\x66\x61vorite\x18\x1d \x01(\x05\x12\x10\n\x08nickname\x18\x1e \x01(\t\x12\x11\n\tfrom_fort\x18\x1f \x01(\x05\"F\n\x04Item\x12\x1f\n\x04item\x18\x01 \x01(\x0e\x32\x11.RpcEnum.ItemType\x12\r\n\x05\x63ount\x18\x02 \x01(\x05\x12\x0e\n\x06unseen\x18\x03 \x01(\x08\"\x99\x01\n\x0cPokedexEntry\x12\x1c\n\x14pokedex_entry_number\x18\x01 \x01(\x05\x12\x19\n\x11times_encountered\x18\x02 \x01(\x05\x12\x16\n\x0etimes_captured\x18\x03 \x01(\x05\x12\x1e\n\x16\x65volution_stone_pieces\x18\x04 \x01(\x05\x12\x18\n\x10\x65volution_stones\x18\x05 \x01(\x05\"\xed\x04\n\x0bPlayerStats\x12\r\n\x05level\x18\x01 \x01(\x05\x12\x12\n\nexperience\x18\x02 \x01(\x03\x12\x15\n\rprev_level_xp\x18\x03 \x01(\x03\x12\x15\n\rnext_level_xp\x18\x04 \x01(\x03\x12\x11\n\tkm_walked\x18\x05 \x01(\x02\x12\x1c\n\x14pokemons_encountered\x18\x06 \x01(\x05\x12\x1e\n\x16unique_pokedex_entries\x18\x07 \x01(\x05\x12\x19\n\x11pokemons_captured\x18\x08 \x01(\x05\x12\x12\n\nevolutions\x18\t \x01(\x05\x12\x18\n\x10poke_stop_visits\x18\n \x01(\x05\x12\x18\n\x10pokeballs_thrown\x18\x0b \x01(\x05\x12\x14\n\x0c\x65ggs_hatched\x18\x0c \x01(\x05\x12\x1b\n\x13\x62ig_magikarp_caught\x18\r \x01(\x05\x12\x19\n\x11\x62\x61ttle_attack_won\x18\x0e \x01(\x05\x12\x1b\n\x13\x62\x61ttle_attack_total\x18\x0f \x01(\x05\x12\x1b\n\x13\x62\x61ttle_defended_won\x18\x10 \x01(\x05\x12\x1b\n\x13\x62\x61ttle_training_won\x18\x11 \x01(\x05\x12\x1d\n\x15\x62\x61ttle_training_total\x18\x12 \x01(\x05\x12\x1d\n\x15prestige_raised_total\x18\x13 \x01(\x05\x12\x1e\n\x16prestige_dropped_total\x18\x14 \x01(\x05\x12\x18\n\x10pokemon_deployed\x18\x15 \x01(\x05\x12\x1e\n\x16pokemon_caught_by_type\x18\x16 \x01(\x0c\x12\x1c\n\x14small_rattata_caught\x18\x17 \x01(\x05\"\x1e\n\x0ePlayerCurrency\x12\x0c\n\x04gems\x18\x01 \x01(\x05\")\n\x0cPlayerCamera\x12\x19\n\x11is_default_camera\x18\x01 \x01(\x08\"I\n\x11InventoryUpgrades\x12\x34\n\x12inventory_upgrades\x18\x01 \x03(\x0b\x32\x18.RpcSub.InventoryUpgrade\"\x84\x01\n\x10InventoryUpgrade\x12\x1f\n\x04item\x18\x01 \x01(\x0e\x32\x11.RpcEnum.ItemType\x12\x33\n\x0cupgrade_type\x18\x02 \x01(\x0e\x32\x1d.RpcEnum.InventoryUpgradeType\x12\x1a\n\x12\x61\x64\x64itional_storage\x18\x03 \x01(\x05\"1\n\x0c\x41ppliedItems\x12!\n\x04item\x18\x04 \x01(\x0b\x32\x13.RpcSub.AppliedItem\"\x91\x01\n\x0b\x41ppliedItem\x12$\n\titem_type\x18\x01 \x01(\x0e\x32\x11.RpcEnum.ItemType\x12\x35\n\x12item_type_category\x18\x02 \x01(\x0e\x32\x19.RpcEnum.ItemTypeCategory\x12\x11\n\texpire_ms\x18\x03 \x01(\x03\x12\x12\n\napplied_ms\x18\x04 \x01(\x03\"<\n\rEggIncubators\x12+\n\regg_incubator\x18\x01 \x01(\x0b\x32\x14.RpcSub.EggIncubator\"\xd7\x01\n\x0c\x45ggIncubator\x12\x0f\n\x07item_id\x18\x01 \x01(\t\x12$\n\titem_type\x18\x02 \x01(\x0e\x32\x11.RpcEnum.ItemType\x12\x31\n\x0eincubator_type\x18\x03 \x01(\x0e\x32\x19.RpcEnum.EggIncubatorType\x12\x16\n\x0euses_remaining\x18\x04 \x01(\x05\x12\x12\n\npokemon_id\x18\x05 \x01(\x03\x12\x17\n\x0fstart_km_walked\x18\x06 \x01(\x01\x12\x18\n\x10target_km_walked\x18\x07 \x01(\x01\"K\n\rPokemonFamily\x12+\n\tfamily_id\x18\x01 \x01(\x0e\x32\x18.RpcEnum.PokemonFamilyId\x12\r\n\x05\x63\x61ndy\x18\x02 \x01(\x05\"h\n\x14GetMapObjectsRequest\x12\x0f\n\x07\x63\x65ll_id\x18\x01 \x01(\x0c\x12\x1a\n\x12since_timestamp_ms\x18\x02 \x01(\x0c\x12\x10\n\x08latitude\x18\x03 \x01(\x01\x12\x11\n\tlongitude\x18\x04 \x01(\x01\"f\n\x15GetMapObjectsResponse\x12\"\n\tmap_cells\x18\x01 \x03(\x0b\x32\x0f.RpcSub.MapCell\x12)\n\x06status\x18\x02 \x01(\x0e\x32\x19.RpcEnum.MapObjectsStatus\"\xa7\x03\n\x07MapCell\x12\x12\n\ns2_cell_id\x18\x01 \x01(\x04\x12\x1c\n\x14\x63urrent_timestamp_ms\x18\x02 \x01(\x03\x12\x1f\n\x05\x66orts\x18\x03 \x03(\x0b\x32\x10.RpcSub.FortData\x12(\n\x0cspawn_points\x18\x04 \x03(\x0b\x32\x12.RpcSub.SpawnPoint\x12\x17\n\x0f\x64\x65leted_objects\x18\x06 \x03(\t\x12\x19\n\x11is_truncated_list\x18\x07 \x01(\x08\x12+\n\x0e\x66ort_summaries\x18\x08 \x03(\x0b\x32\x13.RpcSub.FortSummary\x12\x32\n\x16\x64\x65\x63imated_spawn_points\x18\t \x03(\x0b\x32\x12.RpcSub.SpawnPoint\x12*\n\rwild_pokemons\x18\x05 \x03(\x0b\x32\x13.RpcSub.WildPokemon\x12.\n\x12\x63\x61tchable_pokemons\x18\n \x03(\x0b\x32\x12.RpcSub.MapPokemon\x12.\n\x0fnearby_pokemons\x18\x0b \x03(\x0b\x32\x15.RpcSub.NearbyPokemon\"\xf8\x03\n\x08\x46ortData\x12\n\n\x02id\x18\x01 \x01(\t\x12\"\n\x1alast_modified_timestamp_ms\x18\x02 \x01(\x03\x12\x10\n\x08latitude\x18\x03 \x01(\x01\x12\x11\n\tlongitude\x18\x04 \x01(\x01\x12\x0f\n\x07\x65nabled\x18\x08 \x01(\x08\x12\x1f\n\x04type\x18\t \x01(\x0e\x32\x11.RpcEnum.FortType\x12)\n\rowned_by_team\x18\x05 \x01(\x0e\x32\x12.RpcEnum.TeamColor\x12,\n\x10guard_pokemon_id\x18\x06 \x01(\x0e\x32\x12.RpcEnum.PokemonId\x12\x18\n\x10guard_pokemon_cp\x18\x07 \x01(\x05\x12\x12\n\ngym_points\x18\n \x01(\x03\x12\x14\n\x0cis_in_battle\x18\x0b \x01(\x08\x12&\n\x1e\x63ooldown_complete_timestamp_ms\x18\x0e \x01(\x03\x12%\n\x07sponsor\x18\x0f \x01(\x0e\x32\x14.RpcEnum.FortSponsor\x12\x32\n\x0erendering_type\x18\x10 \x01(\x0e\x32\x1a.RpcEnum.FortRenderingType\x12\x1c\n\x14\x61\x63tive_fort_modifier\x18\x0c \x01(\x0c\x12\'\n\tlure_info\x18\r \x01(\x0b\x32\x14.RpcSub.FortLureInfo\"\x83\x01\n\x0c\x46ortLureInfo\x12\x0f\n\x07\x66ort_id\x18\x01 \x01(\t\x12\x10\n\x08unknown2\x18\x02 \x01(\x01\x12-\n\x11\x61\x63tive_pokemon_id\x18\x03 \x01(\x0e\x32\x12.RpcEnum.PokemonId\x12!\n\x19lure_expires_timestamp_ms\x18\x04 \x01(\x03\"1\n\nSpawnPoint\x12\x10\n\x08latitude\x18\x02 \x01(\x01\x12\x11\n\tlongitude\x18\x03 \x01(\x01\"o\n\x0b\x46ortSummary\x12\x17\n\x0f\x66ort_summary_id\x18\x01 \x01(\x05\x12\"\n\x1alast_modified_timestamp_ms\x18\x02 \x01(\x05\x12\x10\n\x08latitude\x18\x03 \x01(\x05\x12\x11\n\tlongitude\x18\x04 \x01(\x05\"\xcb\x01\n\x0bWildPokemon\x12\x14\n\x0c\x65ncounter_id\x18\x01 \x01(\x06\x12\"\n\x1alast_modified_timestamp_ms\x18\x02 \x01(\x03\x12\x10\n\x08latitude\x18\x03 \x01(\x01\x12\x11\n\tlongitude\x18\x04 \x01(\x01\x12\x15\n\rspawnpoint_id\x18\x05 \x01(\t\x12)\n\x0cpokemon_data\x18\x07 \x01(\x0b\x32\x13.RpcSub.PokemonData\x12\x1b\n\x13time_till_hidden_ms\x18\x0b \x01(\x05\"\xda\x05\n\x0bPokemonData\x12\n\n\x02id\x18\x01 \x01(\x05\x12&\n\npokemon_id\x18\x02 \x01(\x0e\x32\x12.RpcEnum.PokemonId\x12\n\n\x02\x63p\x18\x03 \x01(\x05\x12\x0f\n\x07stamina\x18\x04 \x01(\x05\x12\x13\n\x0bstamina_max\x18\x05 \x01(\x05\x12$\n\x06move_1\x18\x06 \x01(\x0e\x32\x14.RpcEnum.PokemonMove\x12$\n\x06move_2\x18\x07 \x01(\x0e\x32\x14.RpcEnum.PokemonMove\x12\x18\n\x10\x64\x65ployed_fort_id\x18\x08 \x01(\x05\x12\x12\n\nowner_name\x18\t \x01(\t\x12\x0e\n\x06is_egg\x18\n \x01(\x08\x12\x1c\n\x14\x65gg_km_walked_target\x18\x0b \x01(\x05\x12\x1b\n\x13\x65gg_km_walked_start\x18\x0c \x01(\x05\x12\x0e\n\x06origin\x18\x0e \x01(\x05\x12\x10\n\x08height_m\x18\x0f \x01(\x02\x12\x11\n\tweight_kg\x18\x10 \x01(\x02\x12\x19\n\x11individual_attack\x18\x11 \x01(\x05\x12\x1a\n\x12individual_defense\x18\x12 \x01(\x05\x12\x1a\n\x12individual_stamina\x18\x13 \x01(\x05\x12\x15\n\rcp_multiplier\x18\x14 \x01(\x05\x12\x10\n\x08pokeball\x18\x15 \x01(\x05\x12\x18\n\x10\x63\x61ptured_cell_id\x18\x16 \x01(\x04\x12\x18\n\x10\x62\x61ttles_attacked\x18\x17 \x01(\x05\x12\x18\n\x10\x62\x61ttles_defended\x18\x18 \x01(\x05\x12\x18\n\x10\x65gg_incubator_id\x18\x19 \x01(\x05\x12\x18\n\x10\x63reation_time_ms\x18\x1a \x01(\x04\x12\x14\n\x0cnum_upgrades\x18\x1b \x01(\x05\x12 \n\x18\x61\x64\x64itional_cp_multiplier\x18\x1c \x01(\x05\x12\x10\n\x08\x66\x61vorite\x18\x1d \x01(\x05\x12\x10\n\x08nickname\x18\x1e \x01(\t\x12\x11\n\tfrom_fort\x18\x1f \x01(\x05\"\xa7\x01\n\nMapPokemon\x12\x15\n\rspawnpoint_id\x18\x01 \x01(\t\x12\x14\n\x0c\x65ncounter_id\x18\x02 \x01(\x06\x12&\n\npokemon_id\x18\x03 \x01(\x0e\x32\x12.RpcEnum.PokemonId\x12\x1f\n\x17\x65xpiration_timestamp_ms\x18\x04 \x01(\x03\x12\x10\n\x08latitude\x18\x05 \x01(\x01\x12\x11\n\tlongitude\x18\x06 \x01(\x01\"i\n\rNearbyPokemon\x12&\n\npokemon_id\x18\x01 \x01(\x0e\x32\x12.RpcEnum.PokemonId\x12\x1a\n\x12\x64istance_in_meters\x18\x02 \x01(\x02\x12\x14\n\x0c\x65ncounter_id\x18\x03 \x01(\x06\"a\n\x18\x44ownloadSettingsResponse\x12\r\n\x05\x65rror\x18\x01 \x01(\t\x12\x0c\n\x04hash\x18\x02 \x01(\t\x12(\n\x08settings\x18\x03 \x01(\x0b\x32\x16.RpcSub.GlobalSettings\"\xee\x01\n\x0eGlobalSettings\x12+\n\rfort_settings\x18\x02 \x01(\x0b\x32\x14.RpcSub.FortSettings\x12)\n\x0cmap_settings\x18\x03 \x01(\x0b\x32\x13.RpcSub.MapSettings\x12-\n\x0elevel_settings\x18\x04 \x01(\x0b\x32\x15.RpcSub.LevelSettings\x12\x35\n\x12inventory_settings\x18\x05 \x01(\x0b\x32\x19.RpcSub.InventorySettings\x12\x1e\n\x16minimum_client_version\x18\x06 \x01(\t\"\xe4\x01\n\x0c\x46ortSettings\x12 \n\x18interaction_range_meters\x18\x01 \x01(\x01\x12\"\n\x1amax_total_deployed_pokemon\x18\x02 \x01(\x05\x12#\n\x1bmax_player_deployed_pokemon\x18\x03 \x01(\x05\x12!\n\x19\x64\x65ploy_stamina_multiplier\x18\x04 \x01(\x01\x12 \n\x18\x64\x65ploy_attack_multiplier\x18\x05 \x01(\x01\x12$\n\x1c\x66\x61r_interaction_range_meters\x18\x06 \x01(\x01\"\x8f\x02\n\x0bMapSettings\x12\x1d\n\x15pokemon_visible_range\x18\x01 \x01(\x01\x12\x1d\n\x15poke_nav_range_meters\x18\x02 \x01(\x01\x12\x1e\n\x16\x65ncounter_range_meters\x18\x03 \x01(\x01\x12+\n#get_map_objects_min_refresh_seconds\x18\x04 \x01(\x02\x12+\n#get_map_objects_max_refresh_seconds\x18\x05 \x01(\x02\x12+\n#get_map_objects_min_distance_meters\x18\x06 \x01(\x02\x12\x1b\n\x13google_maps_api_key\x18\x07 \x01(\t\"Q\n\rLevelSettings\x12\x1b\n\x13trainer_cp_modifier\x18\x02 \x01(\x01\x12#\n\x1btrainer_difficulty_modifier\x18\x03 \x01(\x01\"\x80\x01\n\x11InventorySettings\x12\x13\n\x0bmax_pokemon\x18\x01 \x01(\x05\x12\x15\n\rmax_bag_items\x18\x02 \x01(\x05\x12\x14\n\x0c\x62\x61se_pokemon\x18\x03 \x01(\x05\x12\x16\n\x0e\x62\x61se_bag_items\x18\x04 \x01(\x05\x12\x11\n\tbase_eggs\x18\x05 \x01(\x05')
  ,
  dependencies=[RpcEnum_pb2.DESCRIPTOR,])
_sym_db.RegisterFileDescriptor(DESCRIPTOR)
_GETPLAYERRESPONSE = _descriptor.Descriptor(
  name='GetPlayerResponse',
  full_name='RpcSub.GetPlayerResponse',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='unknown1', full_name='RpcSub.GetPlayerResponse.unknown1', index=0,
      number=1, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='profile', full_name='RpcSub.GetPlayerResponse.profile', index=1,
      number=2, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=39,
  serialized_end=110,
)
_PROFILE = _descriptor.Descriptor(
  name='Profile',
  full_name='RpcSub.Profile',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='creation_time', full_name='RpcSub.Profile.creation_time', index=0,
      number=1, type=3, cpp_type=2, label=2,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='username', full_name='RpcSub.Profile.username', index=1,
      number=2, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='team', full_name='RpcSub.Profile.team', index=2,
      number=5, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='tutorial', full_name='RpcSub.Profile.tutorial', index=3,
      number=7, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='avatar', full_name='RpcSub.Profile.avatar', index=4,
      number=8, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='poke_storage', full_name='RpcSub.Profile.poke_storage', index=5,
      number=9, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='item_storage', full_name='RpcSub.Profile.item_storage', index=6,
      number=10, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='daily_bonus', full_name='RpcSub.Profile.daily_bonus', index=7,
      number=11, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown12', full_name='RpcSub.Profile.unknown12', index=8,
      number=12, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown13', full_name='RpcSub.Profile.unknown13', index=9,
      number=13, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='currency', full_name='RpcSub.Profile.currency', index=10,
      number=14, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=113,
  serialized_end=413,
)
_DAILYBONUS = _descriptor.Descriptor(
  name='DailyBonus',
  full_name='RpcSub.DailyBonus',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='NextCollectTimestampMs', full_name='RpcSub.DailyBonus.NextCollectTimestampMs', index=0,
      number=1, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='NextDefenderBonusCollectTimestampMs', full_name='RpcSub.DailyBonus.NextDefenderBonusCollectTimestampMs', index=1,
      number=2, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=415,
  serialized_end=504,
)
_CURRENCY = _descriptor.Descriptor(
  name='Currency',
  full_name='RpcSub.Currency',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='type', full_name='RpcSub.Currency.type', index=0,
      number=1, type=9, cpp_type=9, label=2,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='amount', full_name='RpcSub.Currency.amount', index=1,
      number=2, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=506,
  serialized_end=546,
)
_AVATARDETAILS = _descriptor.Descriptor(
  name='AvatarDetails',
  full_name='RpcSub.AvatarDetails',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='unknown2', full_name='RpcSub.AvatarDetails.unknown2', index=0,
      number=2, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown3', full_name='RpcSub.AvatarDetails.unknown3', index=1,
      number=3, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown9', full_name='RpcSub.AvatarDetails.unknown9', index=2,
      number=9, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown10', full_name='RpcSub.AvatarDetails.unknown10', index=3,
      number=10, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=548,
  serialized_end=636,
)
_DOWNLOADSETTINGSREQUEST = _descriptor.Descriptor(
  name='DownloadSettingsRequest',
  full_name='RpcSub.DownloadSettingsRequest',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='hash', full_name='RpcSub.DownloadSettingsRequest.hash', index=0,
      number=1, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=638,
  serialized_end=677,
)
_GETINVENTORYRESPONSE = _descriptor.Descriptor(
  name='GetInventoryResponse',
  full_name='RpcSub.GetInventoryResponse',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='success', full_name='RpcSub.GetInventoryResponse.success', index=0,
      number=1, type=8, cpp_type=7, label=1,
      has_default_value=False, default_value=False,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='inventory_delta', full_name='RpcSub.GetInventoryResponse.inventory_delta', index=1,
      number=2, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=679,
  serialized_end=767,
)
_INVENTORYDELTA = _descriptor.Descriptor(
  name='InventoryDelta',
  full_name='RpcSub.InventoryDelta',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='original_timestamp_ms', full_name='RpcSub.InventoryDelta.original_timestamp_ms', index=0,
      number=1, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='new_timestamp_ms', full_name='RpcSub.InventoryDelta.new_timestamp_ms', index=1,
      number=2, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='inventory_items', full_name='RpcSub.InventoryDelta.inventory_items', index=2,
      number=3, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=769,
  serialized_end=890,
)
_INVENTORYITEM = _descriptor.Descriptor(
  name='InventoryItem',
  full_name='RpcSub.InventoryItem',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='modified_timestamp_ms', full_name='RpcSub.InventoryItem.modified_timestamp_ms', index=0,
      number=1, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='deleted_item_key', full_name='RpcSub.InventoryItem.deleted_item_key', index=1,
      number=2, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='inventory_item_data', full_name='RpcSub.InventoryItem.inventory_item_data', index=2,
      number=3, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=893,
  serialized_end=1021,
)
_INVENTORYITEMDATA = _descriptor.Descriptor(
  name='InventoryItemData',
  full_name='RpcSub.InventoryItemData',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='pokemon', full_name='RpcSub.InventoryItemData.pokemon', index=0,
      number=1, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='item', full_name='RpcSub.InventoryItemData.item', index=1,
      number=2, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokedex_entry', full_name='RpcSub.InventoryItemData.pokedex_entry', index=2,
      number=3, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='player_stats', full_name='RpcSub.InventoryItemData.player_stats', index=3,
      number=4, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='player_currency', full_name='RpcSub.InventoryItemData.player_currency', index=4,
      number=5, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='player_camera', full_name='RpcSub.InventoryItemData.player_camera', index=5,
      number=6, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='inventory_upgrades', full_name='RpcSub.InventoryItemData.inventory_upgrades', index=6,
      number=7, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='applied_items', full_name='RpcSub.InventoryItemData.applied_items', index=7,
      number=8, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='egg_incubators', full_name='RpcSub.InventoryItemData.egg_incubators', index=8,
      number=9, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokemon_family', full_name='RpcSub.InventoryItemData.pokemon_family', index=9,
      number=10, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=1024,
  serialized_end=1481,
)
_POKEMON = _descriptor.Descriptor(
  name='Pokemon',
  full_name='RpcSub.Pokemon',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='id', full_name='RpcSub.Pokemon.id', index=0,
      number=1, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokemon_type', full_name='RpcSub.Pokemon.pokemon_type', index=1,
      number=2, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='cp', full_name='RpcSub.Pokemon.cp', index=2,
      number=3, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='stamina', full_name='RpcSub.Pokemon.stamina', index=3,
      number=4, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='stamina_max', full_name='RpcSub.Pokemon.stamina_max', index=4,
      number=5, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='move_1', full_name='RpcSub.Pokemon.move_1', index=5,
      number=6, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='move_2', full_name='RpcSub.Pokemon.move_2', index=6,
      number=7, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='deployed_fort_id', full_name='RpcSub.Pokemon.deployed_fort_id', index=7,
      number=8, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='owner_name', full_name='RpcSub.Pokemon.owner_name', index=8,
      number=9, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='is_egg', full_name='RpcSub.Pokemon.is_egg', index=9,
      number=10, type=8, cpp_type=7, label=1,
      has_default_value=False, default_value=False,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='egg_km_walked_target', full_name='RpcSub.Pokemon.egg_km_walked_target', index=10,
      number=11, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='egg_km_walked_start', full_name='RpcSub.Pokemon.egg_km_walked_start', index=11,
      number=12, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='origin', full_name='RpcSub.Pokemon.origin', index=12,
      number=14, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='height_m', full_name='RpcSub.Pokemon.height_m', index=13,
      number=15, type=2, cpp_type=6, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='weight_kg', full_name='RpcSub.Pokemon.weight_kg', index=14,
      number=16, type=2, cpp_type=6, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='individual_attack', full_name='RpcSub.Pokemon.individual_attack', index=15,
      number=17, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='individual_defense', full_name='RpcSub.Pokemon.individual_defense', index=16,
      number=18, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='individual_stamina', full_name='RpcSub.Pokemon.individual_stamina', index=17,
      number=19, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='cp_multiplier', full_name='RpcSub.Pokemon.cp_multiplier', index=18,
      number=20, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokeball', full_name='RpcSub.Pokemon.pokeball', index=19,
      number=21, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='captured_cell_id', full_name='RpcSub.Pokemon.captured_cell_id', index=20,
      number=22, type=4, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='battles_attacked', full_name='RpcSub.Pokemon.battles_attacked', index=21,
      number=23, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='battles_defended', full_name='RpcSub.Pokemon.battles_defended', index=22,
      number=24, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='egg_incubator_id', full_name='RpcSub.Pokemon.egg_incubator_id', index=23,
      number=25, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='creation_time_ms', full_name='RpcSub.Pokemon.creation_time_ms', index=24,
      number=26, type=4, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='num_upgrades', full_name='RpcSub.Pokemon.num_upgrades', index=25,
      number=27, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='additional_cp_multiplier', full_name='RpcSub.Pokemon.additional_cp_multiplier', index=26,
      number=28, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='favorite', full_name='RpcSub.Pokemon.favorite', index=27,
      number=29, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='nickname', full_name='RpcSub.Pokemon.nickname', index=28,
      number=30, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='from_fort', full_name='RpcSub.Pokemon.from_fort', index=29,
      number=31, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=1484,
  serialized_end=2212,
)
_ITEM = _descriptor.Descriptor(
  name='Item',
  full_name='RpcSub.Item',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='item', full_name='RpcSub.Item.item', index=0,
      number=1, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='count', full_name='RpcSub.Item.count', index=1,
      number=2, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unseen', full_name='RpcSub.Item.unseen', index=2,
      number=3, type=8, cpp_type=7, label=1,
      has_default_value=False, default_value=False,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=2214,
  serialized_end=2284,
)
_POKEDEXENTRY = _descriptor.Descriptor(
  name='PokedexEntry',
  full_name='RpcSub.PokedexEntry',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='pokedex_entry_number', full_name='RpcSub.PokedexEntry.pokedex_entry_number', index=0,
      number=1, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='times_encountered', full_name='RpcSub.PokedexEntry.times_encountered', index=1,
      number=2, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='times_captured', full_name='RpcSub.PokedexEntry.times_captured', index=2,
      number=3, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='evolution_stone_pieces', full_name='RpcSub.PokedexEntry.evolution_stone_pieces', index=3,
      number=4, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='evolution_stones', full_name='RpcSub.PokedexEntry.evolution_stones', index=4,
      number=5, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=2287,
  serialized_end=2440,
)
_PLAYERSTATS = _descriptor.Descriptor(
  name='PlayerStats',
  full_name='RpcSub.PlayerStats',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='level', full_name='RpcSub.PlayerStats.level', index=0,
      number=1, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='experience', full_name='RpcSub.PlayerStats.experience', index=1,
      number=2, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='prev_level_xp', full_name='RpcSub.PlayerStats.prev_level_xp', index=2,
      number=3, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='next_level_xp', full_name='RpcSub.PlayerStats.next_level_xp', index=3,
      number=4, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='km_walked', full_name='RpcSub.PlayerStats.km_walked', index=4,
      number=5, type=2, cpp_type=6, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokemons_encountered', full_name='RpcSub.PlayerStats.pokemons_encountered', index=5,
      number=6, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unique_pokedex_entries', full_name='RpcSub.PlayerStats.unique_pokedex_entries', index=6,
      number=7, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokemons_captured', full_name='RpcSub.PlayerStats.pokemons_captured', index=7,
      number=8, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='evolutions', full_name='RpcSub.PlayerStats.evolutions', index=8,
      number=9, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='poke_stop_visits', full_name='RpcSub.PlayerStats.poke_stop_visits', index=9,
      number=10, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokeballs_thrown', full_name='RpcSub.PlayerStats.pokeballs_thrown', index=10,
      number=11, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='eggs_hatched', full_name='RpcSub.PlayerStats.eggs_hatched', index=11,
      number=12, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='big_magikarp_caught', full_name='RpcSub.PlayerStats.big_magikarp_caught', index=12,
      number=13, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='battle_attack_won', full_name='RpcSub.PlayerStats.battle_attack_won', index=13,
      number=14, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='battle_attack_total', full_name='RpcSub.PlayerStats.battle_attack_total', index=14,
      number=15, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='battle_defended_won', full_name='RpcSub.PlayerStats.battle_defended_won', index=15,
      number=16, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='battle_training_won', full_name='RpcSub.PlayerStats.battle_training_won', index=16,
      number=17, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='battle_training_total', full_name='RpcSub.PlayerStats.battle_training_total', index=17,
      number=18, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='prestige_raised_total', full_name='RpcSub.PlayerStats.prestige_raised_total', index=18,
      number=19, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='prestige_dropped_total', full_name='RpcSub.PlayerStats.prestige_dropped_total', index=19,
      number=20, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokemon_deployed', full_name='RpcSub.PlayerStats.pokemon_deployed', index=20,
      number=21, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokemon_caught_by_type', full_name='RpcSub.PlayerStats.pokemon_caught_by_type', index=21,
      number=22, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='small_rattata_caught', full_name='RpcSub.PlayerStats.small_rattata_caught', index=22,
      number=23, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=2443,
  serialized_end=3064,
)
_PLAYERCURRENCY = _descriptor.Descriptor(
  name='PlayerCurrency',
  full_name='RpcSub.PlayerCurrency',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='gems', full_name='RpcSub.PlayerCurrency.gems', index=0,
      number=1, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=3066,
  serialized_end=3096,
)
_PLAYERCAMERA = _descriptor.Descriptor(
  name='PlayerCamera',
  full_name='RpcSub.PlayerCamera',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='is_default_camera', full_name='RpcSub.PlayerCamera.is_default_camera', index=0,
      number=1, type=8, cpp_type=7, label=1,
      has_default_value=False, default_value=False,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=3098,
  serialized_end=3139,
)
_INVENTORYUPGRADES = _descriptor.Descriptor(
  name='InventoryUpgrades',
  full_name='RpcSub.InventoryUpgrades',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='inventory_upgrades', full_name='RpcSub.InventoryUpgrades.inventory_upgrades', index=0,
      number=1, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=3141,
  serialized_end=3214,
)
_INVENTORYUPGRADE = _descriptor.Descriptor(
  name='InventoryUpgrade',
  full_name='RpcSub.InventoryUpgrade',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='item', full_name='RpcSub.InventoryUpgrade.item', index=0,
      number=1, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='upgrade_type', full_name='RpcSub.InventoryUpgrade.upgrade_type', index=1,
      number=2, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='additional_storage', full_name='RpcSub.InventoryUpgrade.additional_storage', index=2,
      number=3, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=3217,
  serialized_end=3349,
)
_APPLIEDITEMS = _descriptor.Descriptor(
  name='AppliedItems',
  full_name='RpcSub.AppliedItems',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='item', full_name='RpcSub.AppliedItems.item', index=0,
      number=4, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=3351,
  serialized_end=3400,
)
_APPLIEDITEM = _descriptor.Descriptor(
  name='AppliedItem',
  full_name='RpcSub.AppliedItem',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='item_type', full_name='RpcSub.AppliedItem.item_type', index=0,
      number=1, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='item_type_category', full_name='RpcSub.AppliedItem.item_type_category', index=1,
      number=2, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='expire_ms', full_name='RpcSub.AppliedItem.expire_ms', index=2,
      number=3, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='applied_ms', full_name='RpcSub.AppliedItem.applied_ms', index=3,
      number=4, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=3403,
  serialized_end=3548,
)
_EGGINCUBATORS = _descriptor.Descriptor(
  name='EggIncubators',
  full_name='RpcSub.EggIncubators',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='egg_incubator', full_name='RpcSub.EggIncubators.egg_incubator', index=0,
      number=1, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=3550,
  serialized_end=3610,
)
_EGGINCUBATOR = _descriptor.Descriptor(
  name='EggIncubator',
  full_name='RpcSub.EggIncubator',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='item_id', full_name='RpcSub.EggIncubator.item_id', index=0,
      number=1, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='item_type', full_name='RpcSub.EggIncubator.item_type', index=1,
      number=2, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='incubator_type', full_name='RpcSub.EggIncubator.incubator_type', index=2,
      number=3, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='uses_remaining', full_name='RpcSub.EggIncubator.uses_remaining', index=3,
      number=4, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokemon_id', full_name='RpcSub.EggIncubator.pokemon_id', index=4,
      number=5, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='start_km_walked', full_name='RpcSub.EggIncubator.start_km_walked', index=5,
      number=6, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='target_km_walked', full_name='RpcSub.EggIncubator.target_km_walked', index=6,
      number=7, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=3613,
  serialized_end=3828,
)
_POKEMONFAMILY = _descriptor.Descriptor(
  name='PokemonFamily',
  full_name='RpcSub.PokemonFamily',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='family_id', full_name='RpcSub.PokemonFamily.family_id', index=0,
      number=1, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='candy', full_name='RpcSub.PokemonFamily.candy', index=1,
      number=2, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=3830,
  serialized_end=3905,
)
_GETMAPOBJECTSREQUEST = _descriptor.Descriptor(
  name='GetMapObjectsRequest',
  full_name='RpcSub.GetMapObjectsRequest',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='cell_id', full_name='RpcSub.GetMapObjectsRequest.cell_id', index=0,
      number=1, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='since_timestamp_ms', full_name='RpcSub.GetMapObjectsRequest.since_timestamp_ms', index=1,
      number=2, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='latitude', full_name='RpcSub.GetMapObjectsRequest.latitude', index=2,
      number=3, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='longitude', full_name='RpcSub.GetMapObjectsRequest.longitude', index=3,
      number=4, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=3907,
  serialized_end=4011,
)
_GETMAPOBJECTSRESPONSE = _descriptor.Descriptor(
  name='GetMapObjectsResponse',
  full_name='RpcSub.GetMapObjectsResponse',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='map_cells', full_name='RpcSub.GetMapObjectsResponse.map_cells', index=0,
      number=1, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='status', full_name='RpcSub.GetMapObjectsResponse.status', index=1,
      number=2, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=4013,
  serialized_end=4115,
)
_MAPCELL = _descriptor.Descriptor(
  name='MapCell',
  full_name='RpcSub.MapCell',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='s2_cell_id', full_name='RpcSub.MapCell.s2_cell_id', index=0,
      number=1, type=4, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='current_timestamp_ms', full_name='RpcSub.MapCell.current_timestamp_ms', index=1,
      number=2, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='forts', full_name='RpcSub.MapCell.forts', index=2,
      number=3, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='spawn_points', full_name='RpcSub.MapCell.spawn_points', index=3,
      number=4, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='deleted_objects', full_name='RpcSub.MapCell.deleted_objects', index=4,
      number=6, type=9, cpp_type=9, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='is_truncated_list', full_name='RpcSub.MapCell.is_truncated_list', index=5,
      number=7, type=8, cpp_type=7, label=1,
      has_default_value=False, default_value=False,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='fort_summaries', full_name='RpcSub.MapCell.fort_summaries', index=6,
      number=8, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='decimated_spawn_points', full_name='RpcSub.MapCell.decimated_spawn_points', index=7,
      number=9, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='wild_pokemons', full_name='RpcSub.MapCell.wild_pokemons', index=8,
      number=5, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='catchable_pokemons', full_name='RpcSub.MapCell.catchable_pokemons', index=9,
      number=10, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='nearby_pokemons', full_name='RpcSub.MapCell.nearby_pokemons', index=10,
      number=11, type=11, cpp_type=10, label=3,
      has_default_value=False, default_value=[],
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=4118,
  serialized_end=4541,
)
_FORTDATA = _descriptor.Descriptor(
  name='FortData',
  full_name='RpcSub.FortData',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='id', full_name='RpcSub.FortData.id', index=0,
      number=1, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='last_modified_timestamp_ms', full_name='RpcSub.FortData.last_modified_timestamp_ms', index=1,
      number=2, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='latitude', full_name='RpcSub.FortData.latitude', index=2,
      number=3, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='longitude', full_name='RpcSub.FortData.longitude', index=3,
      number=4, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='enabled', full_name='RpcSub.FortData.enabled', index=4,
      number=8, type=8, cpp_type=7, label=1,
      has_default_value=False, default_value=False,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='type', full_name='RpcSub.FortData.type', index=5,
      number=9, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='owned_by_team', full_name='RpcSub.FortData.owned_by_team', index=6,
      number=5, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='guard_pokemon_id', full_name='RpcSub.FortData.guard_pokemon_id', index=7,
      number=6, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='guard_pokemon_cp', full_name='RpcSub.FortData.guard_pokemon_cp', index=8,
      number=7, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='gym_points', full_name='RpcSub.FortData.gym_points', index=9,
      number=10, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='is_in_battle', full_name='RpcSub.FortData.is_in_battle', index=10,
      number=11, type=8, cpp_type=7, label=1,
      has_default_value=False, default_value=False,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='cooldown_complete_timestamp_ms', full_name='RpcSub.FortData.cooldown_complete_timestamp_ms', index=11,
      number=14, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='sponsor', full_name='RpcSub.FortData.sponsor', index=12,
      number=15, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='rendering_type', full_name='RpcSub.FortData.rendering_type', index=13,
      number=16, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='active_fort_modifier', full_name='RpcSub.FortData.active_fort_modifier', index=14,
      number=12, type=12, cpp_type=9, label=1,
      has_default_value=False, default_value=_b(""),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='lure_info', full_name='RpcSub.FortData.lure_info', index=15,
      number=13, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=4544,
  serialized_end=5048,
)
_FORTLUREINFO = _descriptor.Descriptor(
  name='FortLureInfo',
  full_name='RpcSub.FortLureInfo',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='fort_id', full_name='RpcSub.FortLureInfo.fort_id', index=0,
      number=1, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='unknown2', full_name='RpcSub.FortLureInfo.unknown2', index=1,
      number=2, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='active_pokemon_id', full_name='RpcSub.FortLureInfo.active_pokemon_id', index=2,
      number=3, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='lure_expires_timestamp_ms', full_name='RpcSub.FortLureInfo.lure_expires_timestamp_ms', index=3,
      number=4, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=5051,
  serialized_end=5182,
)
_SPAWNPOINT = _descriptor.Descriptor(
  name='SpawnPoint',
  full_name='RpcSub.SpawnPoint',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='latitude', full_name='RpcSub.SpawnPoint.latitude', index=0,
      number=2, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='longitude', full_name='RpcSub.SpawnPoint.longitude', index=1,
      number=3, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=5184,
  serialized_end=5233,
)
_FORTSUMMARY = _descriptor.Descriptor(
  name='FortSummary',
  full_name='RpcSub.FortSummary',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='fort_summary_id', full_name='RpcSub.FortSummary.fort_summary_id', index=0,
      number=1, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='last_modified_timestamp_ms', full_name='RpcSub.FortSummary.last_modified_timestamp_ms', index=1,
      number=2, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='latitude', full_name='RpcSub.FortSummary.latitude', index=2,
      number=3, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='longitude', full_name='RpcSub.FortSummary.longitude', index=3,
      number=4, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=5235,
  serialized_end=5346,
)
_WILDPOKEMON = _descriptor.Descriptor(
  name='WildPokemon',
  full_name='RpcSub.WildPokemon',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='encounter_id', full_name='RpcSub.WildPokemon.encounter_id', index=0,
      number=1, type=6, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='last_modified_timestamp_ms', full_name='RpcSub.WildPokemon.last_modified_timestamp_ms', index=1,
      number=2, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='latitude', full_name='RpcSub.WildPokemon.latitude', index=2,
      number=3, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='longitude', full_name='RpcSub.WildPokemon.longitude', index=3,
      number=4, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='spawnpoint_id', full_name='RpcSub.WildPokemon.spawnpoint_id', index=4,
      number=5, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokemon_data', full_name='RpcSub.WildPokemon.pokemon_data', index=5,
      number=7, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='time_till_hidden_ms', full_name='RpcSub.WildPokemon.time_till_hidden_ms', index=6,
      number=11, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=5349,
  serialized_end=5552,
)
_POKEMONDATA = _descriptor.Descriptor(
  name='PokemonData',
  full_name='RpcSub.PokemonData',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='id', full_name='RpcSub.PokemonData.id', index=0,
      number=1, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokemon_id', full_name='RpcSub.PokemonData.pokemon_id', index=1,
      number=2, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='cp', full_name='RpcSub.PokemonData.cp', index=2,
      number=3, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='stamina', full_name='RpcSub.PokemonData.stamina', index=3,
      number=4, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='stamina_max', full_name='RpcSub.PokemonData.stamina_max', index=4,
      number=5, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='move_1', full_name='RpcSub.PokemonData.move_1', index=5,
      number=6, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='move_2', full_name='RpcSub.PokemonData.move_2', index=6,
      number=7, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='deployed_fort_id', full_name='RpcSub.PokemonData.deployed_fort_id', index=7,
      number=8, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='owner_name', full_name='RpcSub.PokemonData.owner_name', index=8,
      number=9, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='is_egg', full_name='RpcSub.PokemonData.is_egg', index=9,
      number=10, type=8, cpp_type=7, label=1,
      has_default_value=False, default_value=False,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='egg_km_walked_target', full_name='RpcSub.PokemonData.egg_km_walked_target', index=10,
      number=11, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='egg_km_walked_start', full_name='RpcSub.PokemonData.egg_km_walked_start', index=11,
      number=12, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='origin', full_name='RpcSub.PokemonData.origin', index=12,
      number=14, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='height_m', full_name='RpcSub.PokemonData.height_m', index=13,
      number=15, type=2, cpp_type=6, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='weight_kg', full_name='RpcSub.PokemonData.weight_kg', index=14,
      number=16, type=2, cpp_type=6, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='individual_attack', full_name='RpcSub.PokemonData.individual_attack', index=15,
      number=17, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='individual_defense', full_name='RpcSub.PokemonData.individual_defense', index=16,
      number=18, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='individual_stamina', full_name='RpcSub.PokemonData.individual_stamina', index=17,
      number=19, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='cp_multiplier', full_name='RpcSub.PokemonData.cp_multiplier', index=18,
      number=20, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokeball', full_name='RpcSub.PokemonData.pokeball', index=19,
      number=21, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='captured_cell_id', full_name='RpcSub.PokemonData.captured_cell_id', index=20,
      number=22, type=4, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='battles_attacked', full_name='RpcSub.PokemonData.battles_attacked', index=21,
      number=23, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='battles_defended', full_name='RpcSub.PokemonData.battles_defended', index=22,
      number=24, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='egg_incubator_id', full_name='RpcSub.PokemonData.egg_incubator_id', index=23,
      number=25, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='creation_time_ms', full_name='RpcSub.PokemonData.creation_time_ms', index=24,
      number=26, type=4, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='num_upgrades', full_name='RpcSub.PokemonData.num_upgrades', index=25,
      number=27, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='additional_cp_multiplier', full_name='RpcSub.PokemonData.additional_cp_multiplier', index=26,
      number=28, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='favorite', full_name='RpcSub.PokemonData.favorite', index=27,
      number=29, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='nickname', full_name='RpcSub.PokemonData.nickname', index=28,
      number=30, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='from_fort', full_name='RpcSub.PokemonData.from_fort', index=29,
      number=31, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=5555,
  serialized_end=6285,
)
_MAPPOKEMON = _descriptor.Descriptor(
  name='MapPokemon',
  full_name='RpcSub.MapPokemon',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='spawnpoint_id', full_name='RpcSub.MapPokemon.spawnpoint_id', index=0,
      number=1, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='encounter_id', full_name='RpcSub.MapPokemon.encounter_id', index=1,
      number=2, type=6, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='pokemon_id', full_name='RpcSub.MapPokemon.pokemon_id', index=2,
      number=3, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='expiration_timestamp_ms', full_name='RpcSub.MapPokemon.expiration_timestamp_ms', index=3,
      number=4, type=3, cpp_type=2, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='latitude', full_name='RpcSub.MapPokemon.latitude', index=4,
      number=5, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='longitude', full_name='RpcSub.MapPokemon.longitude', index=5,
      number=6, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=6288,
  serialized_end=6455,
)
_NEARBYPOKEMON = _descriptor.Descriptor(
  name='NearbyPokemon',
  full_name='RpcSub.NearbyPokemon',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='pokemon_id', full_name='RpcSub.NearbyPokemon.pokemon_id', index=0,
      number=1, type=14, cpp_type=8, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='distance_in_meters', full_name='RpcSub.NearbyPokemon.distance_in_meters', index=1,
      number=2, type=2, cpp_type=6, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='encounter_id', full_name='RpcSub.NearbyPokemon.encounter_id', index=2,
      number=3, type=6, cpp_type=4, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=6457,
  serialized_end=6562,
)
_DOWNLOADSETTINGSRESPONSE = _descriptor.Descriptor(
  name='DownloadSettingsResponse',
  full_name='RpcSub.DownloadSettingsResponse',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='error', full_name='RpcSub.DownloadSettingsResponse.error', index=0,
      number=1, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='hash', full_name='RpcSub.DownloadSettingsResponse.hash', index=1,
      number=2, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='settings', full_name='RpcSub.DownloadSettingsResponse.settings', index=2,
      number=3, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=6564,
  serialized_end=6661,
)
_GLOBALSETTINGS = _descriptor.Descriptor(
  name='GlobalSettings',
  full_name='RpcSub.GlobalSettings',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='fort_settings', full_name='RpcSub.GlobalSettings.fort_settings', index=0,
      number=2, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='map_settings', full_name='RpcSub.GlobalSettings.map_settings', index=1,
      number=3, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='level_settings', full_name='RpcSub.GlobalSettings.level_settings', index=2,
      number=4, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='inventory_settings', full_name='RpcSub.GlobalSettings.inventory_settings', index=3,
      number=5, type=11, cpp_type=10, label=1,
      has_default_value=False, default_value=None,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='minimum_client_version', full_name='RpcSub.GlobalSettings.minimum_client_version', index=4,
      number=6, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=6664,
  serialized_end=6902,
)
_FORTSETTINGS = _descriptor.Descriptor(
  name='FortSettings',
  full_name='RpcSub.FortSettings',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='interaction_range_meters', full_name='RpcSub.FortSettings.interaction_range_meters', index=0,
      number=1, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='max_total_deployed_pokemon', full_name='RpcSub.FortSettings.max_total_deployed_pokemon', index=1,
      number=2, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='max_player_deployed_pokemon', full_name='RpcSub.FortSettings.max_player_deployed_pokemon', index=2,
      number=3, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='deploy_stamina_multiplier', full_name='RpcSub.FortSettings.deploy_stamina_multiplier', index=3,
      number=4, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='deploy_attack_multiplier', full_name='RpcSub.FortSettings.deploy_attack_multiplier', index=4,
      number=5, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='far_interaction_range_meters', full_name='RpcSub.FortSettings.far_interaction_range_meters', index=5,
      number=6, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=6905,
  serialized_end=7133,
)
_MAPSETTINGS = _descriptor.Descriptor(
  name='MapSettings',
  full_name='RpcSub.MapSettings',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='pokemon_visible_range', full_name='RpcSub.MapSettings.pokemon_visible_range', index=0,
      number=1, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='poke_nav_range_meters', full_name='RpcSub.MapSettings.poke_nav_range_meters', index=1,
      number=2, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='encounter_range_meters', full_name='RpcSub.MapSettings.encounter_range_meters', index=2,
      number=3, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='get_map_objects_min_refresh_seconds', full_name='RpcSub.MapSettings.get_map_objects_min_refresh_seconds', index=3,
      number=4, type=2, cpp_type=6, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='get_map_objects_max_refresh_seconds', full_name='RpcSub.MapSettings.get_map_objects_max_refresh_seconds', index=4,
      number=5, type=2, cpp_type=6, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='get_map_objects_min_distance_meters', full_name='RpcSub.MapSettings.get_map_objects_min_distance_meters', index=5,
      number=6, type=2, cpp_type=6, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='google_maps_api_key', full_name='RpcSub.MapSettings.google_maps_api_key', index=6,
      number=7, type=9, cpp_type=9, label=1,
      has_default_value=False, default_value=_b("").decode('utf-8'),
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=7136,
  serialized_end=7407,
)
_LEVELSETTINGS = _descriptor.Descriptor(
  name='LevelSettings',
  full_name='RpcSub.LevelSettings',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='trainer_cp_modifier', full_name='RpcSub.LevelSettings.trainer_cp_modifier', index=0,
      number=2, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='trainer_difficulty_modifier', full_name='RpcSub.LevelSettings.trainer_difficulty_modifier', index=1,
      number=3, type=1, cpp_type=5, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=7409,
  serialized_end=7490,
)
_INVENTORYSETTINGS = _descriptor.Descriptor(
  name='InventorySettings',
  full_name='RpcSub.InventorySettings',
  filename=None,
  file=DESCRIPTOR,
  containing_type=None,
  fields=[
    _descriptor.FieldDescriptor(
      name='max_pokemon', full_name='RpcSub.InventorySettings.max_pokemon', index=0,
      number=1, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='max_bag_items', full_name='RpcSub.InventorySettings.max_bag_items', index=1,
      number=2, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='base_pokemon', full_name='RpcSub.InventorySettings.base_pokemon', index=2,
      number=3, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='base_bag_items', full_name='RpcSub.InventorySettings.base_bag_items', index=3,
      number=4, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
    _descriptor.FieldDescriptor(
      name='base_eggs', full_name='RpcSub.InventorySettings.base_eggs', index=4,
      number=5, type=5, cpp_type=1, label=1,
      has_default_value=False, default_value=0,
      message_type=None, enum_type=None, containing_type=None,
      is_extension=False, extension_scope=None,
      options=None),
  ],
  extensions=[
  ],
  nested_types=[],
  enum_types=[
  ],
  options=None,
  is_extendable=False,
  extension_ranges=[],
  oneofs=[
  ],
  serialized_start=7493,
  serialized_end=7621,
)
_GETPLAYERRESPONSE.fields_by_name['profile'].message_type = _PROFILE
_PROFILE.fields_by_name['team'].enum_type = RpcEnum_pb2._TEAMCOLOR
_PROFILE.fields_by_name['avatar'].message_type = _AVATARDETAILS
_PROFILE.fields_by_name['daily_bonus'].message_type = _DAILYBONUS
_PROFILE.fields_by_name['currency'].message_type = _CURRENCY
_GETINVENTORYRESPONSE.fields_by_name['inventory_delta'].message_type = _INVENTORYDELTA
_INVENTORYDELTA.fields_by_name['inventory_items'].message_type = _INVENTORYITEM
_INVENTORYITEM.fields_by_name['inventory_item_data'].message_type = _INVENTORYITEMDATA
_INVENTORYITEMDATA.fields_by_name['pokemon'].message_type = _POKEMON
_INVENTORYITEMDATA.fields_by_name['item'].message_type = _ITEM
_INVENTORYITEMDATA.fields_by_name['pokedex_entry'].message_type = _POKEDEXENTRY
_INVENTORYITEMDATA.fields_by_name['player_stats'].message_type = _PLAYERSTATS
_INVENTORYITEMDATA.fields_by_name['player_currency'].message_type = _PLAYERCURRENCY
_INVENTORYITEMDATA.fields_by_name['player_camera'].message_type = _PLAYERCAMERA
_INVENTORYITEMDATA.fields_by_name['inventory_upgrades'].message_type = _INVENTORYUPGRADES
_INVENTORYITEMDATA.fields_by_name['applied_items'].message_type = _APPLIEDITEMS
_INVENTORYITEMDATA.fields_by_name['egg_incubators'].message_type = _EGGINCUBATORS
_INVENTORYITEMDATA.fields_by_name['pokemon_family'].message_type = _POKEMONFAMILY
_POKEMON.fields_by_name['pokemon_type'].enum_type = RpcEnum_pb2._POKEMONID
_POKEMON.fields_by_name['move_1'].enum_type = RpcEnum_pb2._POKEMONMOVE
_POKEMON.fields_by_name['move_2'].enum_type = RpcEnum_pb2._POKEMONMOVE
_ITEM.fields_by_name['item'].enum_type = RpcEnum_pb2._ITEMTYPE
_INVENTORYUPGRADES.fields_by_name['inventory_upgrades'].message_type = _INVENTORYUPGRADE
_INVENTORYUPGRADE.fields_by_name['item'].enum_type = RpcEnum_pb2._ITEMTYPE
_INVENTORYUPGRADE.fields_by_name['upgrade_type'].enum_type = RpcEnum_pb2._INVENTORYUPGRADETYPE
_APPLIEDITEMS.fields_by_name['item'].message_type = _APPLIEDITEM
_APPLIEDITEM.fields_by_name['item_type'].enum_type = RpcEnum_pb2._ITEMTYPE
_APPLIEDITEM.fields_by_name['item_type_category'].enum_type = RpcEnum_pb2._ITEMTYPECATEGORY
_EGGINCUBATORS.fields_by_name['egg_incubator'].message_type = _EGGINCUBATOR
_EGGINCUBATOR.fields_by_name['item_type'].enum_type = RpcEnum_pb2._ITEMTYPE
_EGGINCUBATOR.fields_by_name['incubator_type'].enum_type = RpcEnum_pb2._EGGINCUBATORTYPE
_POKEMONFAMILY.fields_by_name['family_id'].enum_type = RpcEnum_pb2._POKEMONFAMILYID
_GETMAPOBJECTSRESPONSE.fields_by_name['map_cells'].message_type = _MAPCELL
_GETMAPOBJECTSRESPONSE.fields_by_name['status'].enum_type = RpcEnum_pb2._MAPOBJECTSSTATUS
_MAPCELL.fields_by_name['forts'].message_type = _FORTDATA
_MAPCELL.fields_by_name['spawn_points'].message_type = _SPAWNPOINT
_MAPCELL.fields_by_name['fort_summaries'].message_type = _FORTSUMMARY
_MAPCELL.fields_by_name['decimated_spawn_points'].message_type = _SPAWNPOINT
_MAPCELL.fields_by_name['wild_pokemons'].message_type = _WILDPOKEMON
_MAPCELL.fields_by_name['catchable_pokemons'].message_type = _MAPPOKEMON
_MAPCELL.fields_by_name['nearby_pokemons'].message_type = _NEARBYPOKEMON
_FORTDATA.fields_by_name['type'].enum_type = RpcEnum_pb2._FORTTYPE
_FORTDATA.fields_by_name['owned_by_team'].enum_type = RpcEnum_pb2._TEAMCOLOR
_FORTDATA.fields_by_name['guard_pokemon_id'].enum_type = RpcEnum_pb2._POKEMONID
_FORTDATA.fields_by_name['sponsor'].enum_type = RpcEnum_pb2._FORTSPONSOR
_FORTDATA.fields_by_name['rendering_type'].enum_type = RpcEnum_pb2._FORTRENDERINGTYPE
_FORTDATA.fields_by_name['lure_info'].message_type = _FORTLUREINFO
_FORTLUREINFO.fields_by_name['active_pokemon_id'].enum_type = RpcEnum_pb2._POKEMONID
_WILDPOKEMON.fields_by_name['pokemon_data'].message_type = _POKEMONDATA
_POKEMONDATA.fields_by_name['pokemon_id'].enum_type = RpcEnum_pb2._POKEMONID
_POKEMONDATA.fields_by_name['move_1'].enum_type = RpcEnum_pb2._POKEMONMOVE
_POKEMONDATA.fields_by_name['move_2'].enum_type = RpcEnum_pb2._POKEMONMOVE
_MAPPOKEMON.fields_by_name['pokemon_id'].enum_type = RpcEnum_pb2._POKEMONID
_NEARBYPOKEMON.fields_by_name['pokemon_id'].enum_type = RpcEnum_pb2._POKEMONID
_DOWNLOADSETTINGSRESPONSE.fields_by_name['settings'].message_type = _GLOBALSETTINGS
_GLOBALSETTINGS.fields_by_name['fort_settings'].message_type = _FORTSETTINGS
_GLOBALSETTINGS.fields_by_name['map_settings'].message_type = _MAPSETTINGS
_GLOBALSETTINGS.fields_by_name['level_settings'].message_type = _LEVELSETTINGS
_GLOBALSETTINGS.fields_by_name['inventory_settings'].message_type = _INVENTORYSETTINGS
DESCRIPTOR.message_types_by_name['GetPlayerResponse'] = _GETPLAYERRESPONSE
DESCRIPTOR.message_types_by_name['Profile'] = _PROFILE
DESCRIPTOR.message_types_by_name['DailyBonus'] = _DAILYBONUS
DESCRIPTOR.message_types_by_name['Currency'] = _CURRENCY
DESCRIPTOR.message_types_by_name['AvatarDetails'] = _AVATARDETAILS
DESCRIPTOR.message_types_by_name['DownloadSettingsRequest'] = _DOWNLOADSETTINGSREQUEST
DESCRIPTOR.message_types_by_name['GetInventoryResponse'] = _GETINVENTORYRESPONSE
DESCRIPTOR.message_types_by_name['InventoryDelta'] = _INVENTORYDELTA
DESCRIPTOR.message_types_by_name['InventoryItem'] = _INVENTORYITEM
DESCRIPTOR.message_types_by_name['InventoryItemData'] = _INVENTORYITEMDATA
DESCRIPTOR.message_types_by_name['Pokemon'] = _POKEMON
DESCRIPTOR.message_types_by_name['Item'] = _ITEM
DESCRIPTOR.message_types_by_name['PokedexEntry'] = _POKEDEXENTRY
DESCRIPTOR.message_types_by_name['PlayerStats'] = _PLAYERSTATS
DESCRIPTOR.message_types_by_name['PlayerCurrency'] = _PLAYERCURRENCY
DESCRIPTOR.message_types_by_name['PlayerCamera'] = _PLAYERCAMERA
DESCRIPTOR.message_types_by_name['InventoryUpgrades'] = _INVENTORYUPGRADES
DESCRIPTOR.message_types_by_name['InventoryUpgrade'] = _INVENTORYUPGRADE
DESCRIPTOR.message_types_by_name['AppliedItems'] = _APPLIEDITEMS
DESCRIPTOR.message_types_by_name['AppliedItem'] = _APPLIEDITEM
DESCRIPTOR.message_types_by_name['EggIncubators'] = _EGGINCUBATORS
DESCRIPTOR.message_types_by_name['EggIncubator'] = _EGGINCUBATOR
DESCRIPTOR.message_types_by_name['PokemonFamily'] = _POKEMONFAMILY
DESCRIPTOR.message_types_by_name['GetMapObjectsRequest'] = _GETMAPOBJECTSREQUEST
DESCRIPTOR.message_types_by_name['GetMapObjectsResponse'] = _GETMAPOBJECTSRESPONSE
DESCRIPTOR.message_types_by_name['MapCell'] = _MAPCELL
DESCRIPTOR.message_types_by_name['FortData'] = _FORTDATA
DESCRIPTOR.message_types_by_name['FortLureInfo'] = _FORTLUREINFO
DESCRIPTOR.message_types_by_name['SpawnPoint'] = _SPAWNPOINT
DESCRIPTOR.message_types_by_name['FortSummary'] = _FORTSUMMARY
DESCRIPTOR.message_types_by_name['WildPokemon'] = _WILDPOKEMON
DESCRIPTOR.message_types_by_name['PokemonData'] = _POKEMONDATA
DESCRIPTOR.message_types_by_name['MapPokemon'] = _MAPPOKEMON
DESCRIPTOR.message_types_by_name['NearbyPokemon'] = _NEARBYPOKEMON
DESCRIPTOR.message_types_by_name['DownloadSettingsResponse'] = _DOWNLOADSETTINGSRESPONSE
DESCRIPTOR.message_types_by_name['GlobalSettings'] = _GLOBALSETTINGS
DESCRIPTOR.message_types_by_name['FortSettings'] = _FORTSETTINGS
DESCRIPTOR.message_types_by_name['MapSettings'] = _MAPSETTINGS
DESCRIPTOR.message_types_by_name['LevelSettings'] = _LEVELSETTINGS
DESCRIPTOR.message_types_by_name['InventorySettings'] = _INVENTORYSETTINGS
GetPlayerResponse = _reflection.GeneratedProtocolMessageType('GetPlayerResponse', (_message.Message,), dict(
  DESCRIPTOR = _GETPLAYERRESPONSE,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(GetPlayerResponse)
Profile = _reflection.GeneratedProtocolMessageType('Profile', (_message.Message,), dict(
  DESCRIPTOR = _PROFILE,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(Profile)
DailyBonus = _reflection.GeneratedProtocolMessageType('DailyBonus', (_message.Message,), dict(
  DESCRIPTOR = _DAILYBONUS,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(DailyBonus)
Currency = _reflection.GeneratedProtocolMessageType('Currency', (_message.Message,), dict(
  DESCRIPTOR = _CURRENCY,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(Currency)
AvatarDetails = _reflection.GeneratedProtocolMessageType('AvatarDetails', (_message.Message,), dict(
  DESCRIPTOR = _AVATARDETAILS,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(AvatarDetails)
DownloadSettingsRequest = _reflection.GeneratedProtocolMessageType('DownloadSettingsRequest', (_message.Message,), dict(
  DESCRIPTOR = _DOWNLOADSETTINGSREQUEST,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(DownloadSettingsRequest)
GetInventoryResponse = _reflection.GeneratedProtocolMessageType('GetInventoryResponse', (_message.Message,), dict(
  DESCRIPTOR = _GETINVENTORYRESPONSE,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(GetInventoryResponse)
InventoryDelta = _reflection.GeneratedProtocolMessageType('InventoryDelta', (_message.Message,), dict(
  DESCRIPTOR = _INVENTORYDELTA,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(InventoryDelta)
InventoryItem = _reflection.GeneratedProtocolMessageType('InventoryItem', (_message.Message,), dict(
  DESCRIPTOR = _INVENTORYITEM,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(InventoryItem)
InventoryItemData = _reflection.GeneratedProtocolMessageType('InventoryItemData', (_message.Message,), dict(
  DESCRIPTOR = _INVENTORYITEMDATA,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(InventoryItemData)
Pokemon = _reflection.GeneratedProtocolMessageType('Pokemon', (_message.Message,), dict(
  DESCRIPTOR = _POKEMON,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(Pokemon)
Item = _reflection.GeneratedProtocolMessageType('Item', (_message.Message,), dict(
  DESCRIPTOR = _ITEM,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(Item)
PokedexEntry = _reflection.GeneratedProtocolMessageType('PokedexEntry', (_message.Message,), dict(
  DESCRIPTOR = _POKEDEXENTRY,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(PokedexEntry)
PlayerStats = _reflection.GeneratedProtocolMessageType('PlayerStats', (_message.Message,), dict(
  DESCRIPTOR = _PLAYERSTATS,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(PlayerStats)
PlayerCurrency = _reflection.GeneratedProtocolMessageType('PlayerCurrency', (_message.Message,), dict(
  DESCRIPTOR = _PLAYERCURRENCY,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(PlayerCurrency)
PlayerCamera = _reflection.GeneratedProtocolMessageType('PlayerCamera', (_message.Message,), dict(
  DESCRIPTOR = _PLAYERCAMERA,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(PlayerCamera)
InventoryUpgrades = _reflection.GeneratedProtocolMessageType('InventoryUpgrades', (_message.Message,), dict(
  DESCRIPTOR = _INVENTORYUPGRADES,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(InventoryUpgrades)
InventoryUpgrade = _reflection.GeneratedProtocolMessageType('InventoryUpgrade', (_message.Message,), dict(
  DESCRIPTOR = _INVENTORYUPGRADE,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(InventoryUpgrade)
AppliedItems = _reflection.GeneratedProtocolMessageType('AppliedItems', (_message.Message,), dict(
  DESCRIPTOR = _APPLIEDITEMS,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(AppliedItems)
AppliedItem = _reflection.GeneratedProtocolMessageType('AppliedItem', (_message.Message,), dict(
  DESCRIPTOR = _APPLIEDITEM,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(AppliedItem)
EggIncubators = _reflection.GeneratedProtocolMessageType('EggIncubators', (_message.Message,), dict(
  DESCRIPTOR = _EGGINCUBATORS,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(EggIncubators)
EggIncubator = _reflection.GeneratedProtocolMessageType('EggIncubator', (_message.Message,), dict(
  DESCRIPTOR = _EGGINCUBATOR,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(EggIncubator)
PokemonFamily = _reflection.GeneratedProtocolMessageType('PokemonFamily', (_message.Message,), dict(
  DESCRIPTOR = _POKEMONFAMILY,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(PokemonFamily)
GetMapObjectsRequest = _reflection.GeneratedProtocolMessageType('GetMapObjectsRequest', (_message.Message,), dict(
  DESCRIPTOR = _GETMAPOBJECTSREQUEST,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(GetMapObjectsRequest)
GetMapObjectsResponse = _reflection.GeneratedProtocolMessageType('GetMapObjectsResponse', (_message.Message,), dict(
  DESCRIPTOR = _GETMAPOBJECTSRESPONSE,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(GetMapObjectsResponse)
MapCell = _reflection.GeneratedProtocolMessageType('MapCell', (_message.Message,), dict(
  DESCRIPTOR = _MAPCELL,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(MapCell)
FortData = _reflection.GeneratedProtocolMessageType('FortData', (_message.Message,), dict(
  DESCRIPTOR = _FORTDATA,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(FortData)
FortLureInfo = _reflection.GeneratedProtocolMessageType('FortLureInfo', (_message.Message,), dict(
  DESCRIPTOR = _FORTLUREINFO,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(FortLureInfo)
SpawnPoint = _reflection.GeneratedProtocolMessageType('SpawnPoint', (_message.Message,), dict(
  DESCRIPTOR = _SPAWNPOINT,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(SpawnPoint)
FortSummary = _reflection.GeneratedProtocolMessageType('FortSummary', (_message.Message,), dict(
  DESCRIPTOR = _FORTSUMMARY,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(FortSummary)
WildPokemon = _reflection.GeneratedProtocolMessageType('WildPokemon', (_message.Message,), dict(
  DESCRIPTOR = _WILDPOKEMON,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(WildPokemon)
PokemonData = _reflection.GeneratedProtocolMessageType('PokemonData', (_message.Message,), dict(
  DESCRIPTOR = _POKEMONDATA,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(PokemonData)
MapPokemon = _reflection.GeneratedProtocolMessageType('MapPokemon', (_message.Message,), dict(
  DESCRIPTOR = _MAPPOKEMON,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(MapPokemon)
NearbyPokemon = _reflection.GeneratedProtocolMessageType('NearbyPokemon', (_message.Message,), dict(
  DESCRIPTOR = _NEARBYPOKEMON,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(NearbyPokemon)
DownloadSettingsResponse = _reflection.GeneratedProtocolMessageType('DownloadSettingsResponse', (_message.Message,), dict(
  DESCRIPTOR = _DOWNLOADSETTINGSRESPONSE,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(DownloadSettingsResponse)
GlobalSettings = _reflection.GeneratedProtocolMessageType('GlobalSettings', (_message.Message,), dict(
  DESCRIPTOR = _GLOBALSETTINGS,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(GlobalSettings)
FortSettings = _reflection.GeneratedProtocolMessageType('FortSettings', (_message.Message,), dict(
  DESCRIPTOR = _FORTSETTINGS,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(FortSettings)
MapSettings = _reflection.GeneratedProtocolMessageType('MapSettings', (_message.Message,), dict(
  DESCRIPTOR = _MAPSETTINGS,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(MapSettings)
LevelSettings = _reflection.GeneratedProtocolMessageType('LevelSettings', (_message.Message,), dict(
  DESCRIPTOR = _LEVELSETTINGS,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(LevelSettings)
InventorySettings = _reflection.GeneratedProtocolMessageType('InventorySettings', (_message.Message,), dict(
  DESCRIPTOR = _INVENTORYSETTINGS,
  __module__ = 'RpcSub_pb2'
  ))
_sym_db.RegisterMessage(InventorySettings)
import os.path
import pkgutil
import shutil
import sys
import struct
import tempfile
PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3
if PY3:
    iterbytes = iter
else:
    def iterbytes(buf):
        return (ord(byte) for byte in buf)
try:
    from base64 import b85decode
except ImportError:
    _b85alphabet = (b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                    b"abcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~")
    def b85decode(b):
        _b85dec = [None] * 256
        for i, c in enumerate(iterbytes(_b85alphabet)):
            _b85dec[c] = i
        padding = (-len(b)) % 5
        b = b + b'~' * padding
        out = []
        packI = struct.Struct('!I').pack
        for i in range(0, len(b), 5):
            chunk = b[i:i + 5]
            acc = 0
            try:
                for c in iterbytes(chunk):
                    acc = acc * 85 + _b85dec[c]
            except TypeError:
                for j, c in enumerate(iterbytes(chunk)):
                    if _b85dec[c] is None:
                        raise ValueError(
                            'bad base85 character at position %d' % (i + j)
                        )
                raise
            try:
                out.append(packI(acc))
            except struct.error:
                raise ValueError('base85 overflow in hunk starting at byte %d'
                                 % i)
        result = b''.join(out)
        if padding:
            result = result[:-padding]
        return result
def bootstrap(tmpdir=None):
    import pip
    from pip.commands.install import InstallCommand
    from pip.req import InstallRequirement
    class CertInstallCommand(InstallCommand):
        def parse_args(self, args):
            if not self.parser.get_default_values().cert:
                self.parser.defaults["cert"] = cert_path  # calculated below
            return super(CertInstallCommand, self).parse_args(args)
    pip.commands_dict["install"] = CertInstallCommand
    implicit_pip = True
    implicit_setuptools = True
    implicit_wheel = True
    if "--no-setuptools" in sys.argv or os.environ.get("PIP_NO_SETUPTOOLS"):
        args = [x for x in sys.argv[1:] if x != "--no-setuptools"]
        implicit_setuptools = False
    else:
        args = sys.argv[1:]
    if "--no-wheel" in args or os.environ.get("PIP_NO_WHEEL"):
        args = [x for x in args if x != "--no-wheel"]
        implicit_wheel = False
    if implicit_setuptools:
        try:
            import setuptools  # noqa
            implicit_setuptools = False
        except ImportError:
            pass
    if implicit_wheel:
        try:
            import wheel  # noqa
            implicit_wheel = False
        except ImportError:
            pass
    for arg in args:
        try:
            req = InstallRequirement.from_line(arg)
        except:
            continue
        if implicit_pip and req.name == "pip":
            implicit_pip = False
        elif implicit_setuptools and req.name == "setuptools":
            implicit_setuptools = False
        elif implicit_wheel and req.name == "wheel":
            implicit_wheel = False
    if implicit_pip:
        args += ["pip"]
    if implicit_setuptools:
        args += ["setuptools"]
    if implicit_wheel:
        args += ["wheel"]
    delete_tmpdir = False
    try:
        if tmpdir is None:
            tmpdir = tempfile.mkdtemp()
            delete_tmpdir = True
        cert_path = os.path.join(tmpdir, "cacert.pem")
        with open(cert_path, "wb") as cert:
            cert.write(pkgutil.get_data("pip._vendor.requests", "cacert.pem"))
        sys.exit(pip.main(["install", "--upgrade"] + args))
    finally:
        if delete_tmpdir and tmpdir:
            shutil.rmtree(tmpdir, ignore_errors=True)
def main():
    tmpdir = None
    try:
        tmpdir = tempfile.mkdtemp()
        pip_zip = os.path.join(tmpdir, "pip.zip")
        with open(pip_zip, "wb") as fp:
            fp.write(b85decode(DATA.replace(b"\n", b"")))
        sys.path.insert(0, pip_zip)
        bootstrap(tmpdir=tmpdir)
    finally:
        if tmpdir:
            shutil.rmtree(tmpdir, ignore_errors=True)
DATA = b
if __name__ == "__main__":
    main()
import math
import argparse
import json
parser = argparse.ArgumentParser()
parser.add_argument("-lat", "--lat", help="latitude")
parser.add_argument("-lon", "--lon", help="longitude")
parser.add_argument("-st", "--steps", help="steps")
parser.add_argument("-lp", "--leaps", help="like 'steps' but for workers instead of scans")
R = 6378137.0
r_hex = 149.9497/2.0
args = parser.parse_args()
st = (int)(args.steps)
wst = (int)(args.leaps)
w_worker = (2 * st - 1) * r_hex
d = 2 * w_worker
total_workers = 1
for i in range(1, wst):
    total_workers += 6*(i)
brng = math.radians(0)
lon = [0] * total_workers
lat = [0] * total_workers
lat[0] = math.radians((float)(args.lat))
lon[0] = math.radians((float)(args.lon))
turn_steps = 0
turn_steps_so_far = 0
turn_count = 0
jump_points = [0] * (wst + 1)
jump_points[0] = 0
jump_points[1] = 1
jump = 1
for i in range(2,wst + 1):
    jump_points[i] = jump_points[i-1] + 6 *(i-1)
for i in range(1, total_workers):
    lat1 = lat[i - 1]
    lon1 = lon[i - 1]
    
    if i in jump_points and jump > 0:
        lat1 = lat[jump_points[jump-1]]
        lon1 = lon[jump_points[jump-1]]
        jump += 1
        turn_steps += 1
        turn_steps_so_far = turn_steps
        brng = math.radians(0)
    lat2 = math.asin( math.sin(lat1)*math.cos(d/R) +
                      math.cos(lat1)*math.sin(d/R)*math.cos(brng))
    lon2 = lon1 + math.atan2(math.sin(brng)*math.sin(d/R)*math.cos(lat1),
                             math.cos(d/R)-math.sin(lat1)*math.sin(lat2))
    lat[i] = lat2
    lon[i] = lon2
    if i in jump_points:
        brng = math.radians(60)
    if turn_steps_so_far == turn_steps:
        brng += math.radians(60.0)
        turn_steps_so_far = 0
    turn_steps_so_far += 1
for i in range(total_workers):
    print str(math.degrees(lat[i])) + ", " + str(math.degrees(lon[i]))