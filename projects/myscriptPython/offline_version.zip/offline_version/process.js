var variableList = [];
var def_reg = /def\s*([^(,]+)\(([^)]+)\)\s*(?::|!)/g;
var def_var_reg = /([^,]+)/g;
var if_or_reg = /if(.*?)\sor\s(.*?):/g;
var if_reg = /^((?! or ).)*$/g;
var for_reg = /for(.*?)in(.*?):/g;
var raise_reg = /raise\s*([^(]+)(.*)/g;
var return_reg = /return(.*)/g;
var yield_reg = /yield(.*)/g;
var normal_equal_reg = /(.*)=(.*)/g;
var normal_paren_reg = /([^(]+)\(([^)]+)\)/g;
var levinThreshold = 0.7;

var normalParenSentence = function(label){
    var match = label.match(normal_paren_reg);
    if (match == null){
        if (label.replace(/[^(]/g, "").length < label.replace(/[^)]/g, "").length){ // numbers of (,)
                if (label.indexOf('l') != -1){
                    label = label.replace('l','(');
                }
                else{
                    label = label.replace('c','(');
                }
            }
        console.log('fix it normal');
    }
    var m = normal_paren_reg.exec(label);
    console.log(m);
    m[1] = m[1].replace('-','_');
    m[2] = m[2].replace('.',',');
    var wordlist = m[2].split(',');
    wordlist[0] = checkVariable(wordlist[0].replace(/ /g,''));
    variableList.push(wordlist[0]);
    wordlist[1] = checkVariable(wordlist[1].replace(/ /g,''));
    variableList.push(wordlist[1]);
    return m[1]+'('+wordlist[0]+', '+wordlist[1]+')';

}
var normalSentence = function(label){
    label = label.replace('l)','()');
    label = label.replace(' e ',' + ');
    label = label.replace(' t ',' + ');
    var match1 = label.match(normal_equal_reg);
    if (match1 != null){
        var m = normal_equal_reg.exec(label);
        if (m.index === normal_equal_reg.lastIndex) {
            normal_equal_reg.lastIndex++;
        }
        m[1] = m[1].replace('-','_');
        var newword1 = checkVariable(m[1].replace(/ /g,''));
        variableList.push(newword1);
        if (m[2].indexOf('-')!= -1){
            m[2] = m[2].replace('-','.');
        }
        if(m[2].indexOf('+')!=-1 && m[2].indexOf(')')!=-1){
            var subword1 = m[2].split('+')[0].trim();
            var subword2 = m[2].split('+')[1].split('*')[0].trim();
            var subword3 = m[2].split('+')[1].split('*')[1].trim();
            if (subword1.replace(/[^[]/g, "").length == 0 ){ 
                subword1 = subword1.replace('tit','[0]');
                subword1 = subword1.replace('bbux','bbox');
                
            }
            if (subword1.replace(/[^[]/g, "").length != subword1.replace(/[^]]/g, "").length){ // numbers of (,)
                if (subword1.indexOf('f')!=-1){
                    subword1 = subword1.replace('f','[');
                }
                else if (subword1.indexOf('3')!=-1){
                    subword1 = subword1.replace("3",']');
                }
                else if (subword1.indexOf('to]')!=-1){
                    subword1 = subword1.replace("to]",'[0]');
                }
                else {
                    subword1 = subword1.replace("co",'[0');
                }
                
            }
            subword1 = subword1.replace('[o]','[0]');
            if (subword2.replace(/[^[]/g, "").length != subword2.replace(/[^]]/g, "").length){ // numbers of (,)
                if (subword2.indexOf('D')!=-1){
                    subword2 = subword2.replace('D','1]');
                }
                else if(subword2.indexOf('Ll')!=-1){
                    subword2 = subword2.replace("Ll",'[1');
                }
                else{
                    subword2 = subword2.replace("ci]",'[1]');
                    subword2 = subword2.replace('bbux','bbox');
                }
            }
            var before = subword1+' + '+subword2;
            console.log(before);
            if (before.replace(/[^(]/g, "").length != 3 || before.replace(/[^)]/g, "").length != 3){ // numbers of (,)
                if (before.indexOf('l')!=-1){
                    before = before.replace(/l/g,'(');
                }
                else{
                    before = before.replace("c",'(');
                }
            }
            if (before.replace(/[^(]/g, "").length !=  before.replace(/[^)]/g, "").length){ // numbers of (,)
                before = before.replace('1])','1]))');
                //before = before.replace('D',')');
            }
            subword3 = subword3.replace('as','0.5');
            subword3 = subword3.replace('u.s.','0.5');
            var newword2 = before+' * '+subword3;
        }
        else if (m[2].indexOf('.') != -1){
            var varlist = m[2].split('.');
            var newvarlist = [];
            
            if (varlist.length == 2){
                console.log(varlist);
                newvarlist.push(checkVariable(varlist[0].replace(/ /g,'')));
                variableList.push(checkVariable(varlist[0].replace(/ /g,'')));
                newvarlist.push(checkVariable(varlist[1].replace(/ /g,'')));
                variableList.push(checkVariable(varlist[1].replace(/ /g,'')));
                var newword2 = newvarlist[0]+'.'+newvarlist[1];
                console.log(newword2);
            }
            else{
                console.log('many dot')
            }
        }
        else if(m[2].indexOf(')')!=-1 ){
            var sub_reg = /(.*?)\((.*)\)/g;
            
            var match1 = m[2].match(sub_reg);
            m[2] = m[2].trim();
            if(match1 == null){
                if(m[2].indexOf(')')==-1){
                    m[2] = m[2].replace('d','))');
                }
                else if (m[2].indexOf('l')!=-1){
                    m[2] = m[2].replace(/l/g,'(');
                    console.log(m[2]);
                    m[2] = 'l'+m[2].substring(1,m[2].length);
                    console.log(m[2]);
                    if(m[2].indexOf('C')!=-1 && m[2].indexOf('c')!=-1){
                        m[2] = m[2].replace(/C/g,'(');
                        m[2] = m[2].replace(/c/g,'(');
                    }
                }
                else {
                    m[2] = m[2].replace(/c/g,'(');
                }
            }
            if (m[2].replace(/[^(]/g, "").length < m[2].replace(/[^)]/g, "").length){
                m[2] = m[2].replace('c','(');
            }
            console.log(m[2]);
            var p = sub_reg.exec(m[2]);

            if (p[2].indexOf(')')!= -1 && p[2].indexOf('(')== -1){
                p[2] = p[2].replace('l','(');
            }
            if (p[2].match(sub_reg)!= null){ // list(take(df,df))
                var p1 = sub_reg.exec(p[2]);
                var newword2 = p[1].replace(/ /g,'')+'('+checkFunction(p1[1].replace(/ /g,''))+'('+ p1[2] + '))';
            }
            
            
            else{
                variableList.push(checkVariable(p[2].replace(/ /g,'')));
                var newword2 = checkFunction(p[1].replace(/ /g,''))+'('+checkVariable(p[2].replace(/ /g,''))+')';
            }
            
        }
        else{
            m[2] = m[2].replace(' 1 ',' / ');
            var newword2 = checkVariable(m[2].trim());
            variableList.push(newword2);
        }
        return newword1 + ' = ' + newword2;
    }
    else{
        return label;
    }
}
var yieldSentence = function(label){
    var match = label.match(yield_reg);
    if(match != null){
        var p = yield_reg.exec(label);
        var str = p[1];
        if (str.indexOf(')')!=-1){
            var subyield_reg = /(.*?)\((.*)\)/g;
            
            var match1 = str.match(subyield_reg);
            if(match1 == null){
                if (str.indexOf('l')!=-1){
                    str = str.replace('l','(');
                }
                else{
                    str = str.replace('k','(');
                }
            }
            console.log(str);
            if (str.replace(/[^(]/g, "").length < str.replace(/[^)]/g, "").length){ // numbers of (,)
                str = str.replace('c','(');
            }
            var m = subyield_reg.exec(str);
            variableList.push(checkVariable(m[2].replace(/ /g,'')));
            return 'yield '+ checkVariable(m[1].replace(/ /g,''))+'('+checkVariable(m[2].replace(/ /g,''))+')';
        }
        else{
            return 'yield '+ checkVariable(str.replace(/ /g,''))
        }
    }
    else{
        console.log('yield does not match');
    }
}
var returnSentence = function(label){
    var match = label.match(return_reg);
    if(match != null){
        var m = return_reg.exec(label);
        // This is necessary to avoid infinite loops with zero-width matches
        if (m.index === return_reg.lastIndex) {
            return_reg.lastIndex++;
        }
        if (m[1].indexOf(',') != -1){
            var sentence = 'return ';
            var matches = m[1].split(',');
            for (var i=0;i<matches.length;i++){
                console.log(matches[i]);
                variableList.push(checkVariable(matches[i].replace(/ /g,'')));
                sentence = sentence + checkVariable(matches[i].replace(/ /g,''))+', ';
            }
            sentence = sentence.substring(0,sentence.length-2);
            return sentence;
        }
        else{
            variableList.push(checkVariable(m[1].replace(/ /g,'')));
            return 'return '+checkVariable(m[1].replace(/ /g,''));
        }
    }
    else{
        console.log('return does not match');
        return label;
    }
}
var raiseSentence = function(label){
    label = label.replace("l'","('");
    var match = label.match(raise_reg);
    if(match != null){
        var m = raise_reg.exec(label);
        //console.log(m[1],m[2]);
        if (m[2].indexOf('%') != -1){
            m[2] = m[2].replace('( ','(');
            return 'raise '+checkFunction(m[1].replace(/ /g,''))+m[2];
        }
        else{
            var sentence = 'raise '+m[1].replace(/ /g,'')+'(';
            m[2] = m[2].replace('(','');
            m[2] = m[2].replace(')','');
            var matches = m[2].split(',');
            for (var i=0;i<matches.length;i++){
                variableList.push(matches[i].replace(/ /g,''));
                sentence = sentence + matches[i]+', ';
            }
            sentence = sentence.substring(0,sentence.length-2)+')';
            return sentence;
        }
    }
    else{
        return label;
    }
}
var forSentence = function(label){
    label = label.substring(0,label.length-1)+':';
    var matches = label.match(for_reg);
    if(matches != null){
        var m = for_reg.exec(label);
        console.log(m[1],m[2]);
        return 'for '+forSubSentence(m[1])+' in '+forSubSentence(m[2])+':';
    }
    else{
        return label;
    }
}
var forSubSentence = function(str){
    if(str.indexOf('(') != -1 || str.indexOf(')') != -1){
        var subfor_reg = /(.*?)\((.*)\)/g;
        var match1 = str.match(subfor_reg);
        if(match1 == null){
            if (str.indexOf('[')!=-1){
                str = str.replace('[','(');
            }
            else if (str.indexOf('c') != -1  && str.indexOf('c') < str.indexOf('l')){
                str = str.replace('c','(');
            }
            else if (str.indexOf('C') != -1){
                str = str.replace('C','(');
            }
            else{
                str = str.replace('l','(');
            }
        }
        var m = subfor_reg.exec(str);
        variableList.push(checkVariable(m[2]));
        return checkFunction(m[1].replace(/ /g,''))+'('+checkVariable(m[2].replace(/ /g,''))+')';

    }
    else{
        console.log(str);
        variableList.push(checkVariable(str.replace(/ /g,'')));
        console.log(checkVariable(str.replace(/ /g,'')));
        return checkVariable(str.replace(/ /g,''));
    }
}
var ifSentence = function(label){
    label = label.substring(0,label.length-1)+':';
    var match1 = label.match(if_or_reg);
    var match2 = label.match(if_reg);
    if(match1 != null){ // or
        var m = if_or_reg.exec(label);
        //console.log(m[1],m[2]);
        return 'if '+ifSubSentence(m[1])+' or '+ifSubSentence(m[2])+':';
    }
    else if(match2 != null){
        var str = label.substring(3,label.length-1);
        if (str.startsWith('not')){
            return 'if not '+ifSubSentence(str.substring(3,label.length)).trim()+':'
        }
        else{
            return 'if '+ifSubSentence(str)+':';
        }
    }
    else{
        console.log('if not match');
    }
}
var ifSubSentence = function(str){ // process sub sentence in if
    if (str.indexOf(' is not ') != -1){
        var wordlist = str.split('is not');
        return pushVariableList(wordlist[0]) + ' '+'is not'+' '+pushVariableList(wordlist[1]);
    }
    else if (str.indexOf(' is ') != -1){
        var wordlist = str.split('is');
        return pushVariableList(wordlist[0]) + ' '+'is'+' '+pushVariableList(wordlist[1]);
    }
    else if (str.indexOf(' == ') != -1){
        var wordlist = str.split('==');
        return pushVariableList(wordlist[0]) + ' '+'=='+' '+pushVariableList(wordlist[1]);
    }
    else if(str.indexOf(')') != -1){
        if (str.indexOf('(') == -1){
            for (var i=2; i<str.length;i++){
                if (str[i] == 'l'){
                    str = str.substring(0,i)+'('+str.substring(i+1,str.length);
                }
                else if (str[i] == 'c'){
                    str = str.substring(0,i)+'('+str.substring(i+1,str.length);
                }
            }
            return str;
        }
        else{
            if (str.indexOf(' (') != -1){
                return str.replace(' (','(');
            }
            else{
                return str;
            }
        }
        
        

    }
    else{
        return pushVariableList(str);
    }
}
var pushVariableList = function(word){
    if (word.indexOf('-')!= -1){
        word = word.replace('-','.');
    }
    if (word.indexOf(',')!= -1){
        word = word.replace(',','.');
    }
    if (word.indexOf('.') != -1){
        var varlist = word.split('.');
        var newvarlist = [];
        //console.log(varlist);
        if (varlist.length == 2){

            newvarlist.push(checkVariable(varlist[0].replace(/ /g,'')));
            variableList.push(checkVariable(varlist[0].replace(/ /g,'')));
            newvarlist.push(checkVariable(varlist[1].replace(/ /g,'')));
            variableList.push(checkVariable(varlist[1].replace(/ /g,'')));
            console.log(newvarlist);
            return newvarlist[0]+'.'+newvarlist[1];
        }
        else{
            variableList.push(varlist[0].replace(/ /g,'')+'.'+varlist[1].replace(/ /g,''));
            variableList.push(varlist[2].replace(/ /g,''));
            newvarlist.push(checkVariable(varlist[0].replace(/ /g,'')+'.'+varlist[1].replace(/ /g,'')));
            newvarlist.push(checkVariable(varlist[2].replace(/ /g,'')));
            return newvarlist[0]+'.'+newvarlist[1];
        }
    }
    else{
        var newword = checkVariable(word.replace(/ /g,''));
        variableList.push(newword);
        return newword;
    }
}
var def = function(label){
    label = label.replace(/-_/g,'=');
    label = label.replace(/-/g,'_');
    label = label.substring(0,label.length-2)+'):';
    if (label.indexOf(')') != -1 && label.indexOf('(') == -1){
        label = label.replace('l','(');
    }
    if (label.indexOf(')') != -1 && label.indexOf('(') == -1){
        label = label.replace('c','(');
    }
    var match = label.match(def_reg);
    if(match != null){ // or
        var m = def_reg.exec(label);
        // This is necessary to avoid infinite loops with zero-width matches
        var matches = [], found;
        while (found = def_var_reg.exec(m[2])) {
            matches.push(found[0]);
            def_var_reg.lastIndex = found.index+found[0].length;
        }
        var sentence = 'def '+m[1].replace(/ /g,'')+'(';
        keywords.push(m[1].replace(/ /g,''));
        for (var i=0;i<matches.length;i++){
            if (matches[i].indexOf('_')!=-1){
                matches[i] = matches[i].replace('_','=');
            }
            if (matches[i].indexOf('=') != -1){
                var para = matches[i].split('=');
                variableList.push(checkVariable(para[0].replace(/ /g,'')));
                variableList.push(checkVariable(para[1].replace(/ /g,'')));
                var thispara = checkVariable(para[0].replace(/ /g,''))+'='+checkVariable(para[1].replace(/ /g,''));
                //console.log(thispara);
            }
            else{// first word is self, selfe
                if(i==0 && CharacterErrorRate(matches[0], 'self')>0.5){
                    matches[0] = 'self';
                    variableList.push('self');
                    var thispara = 'self';
                }
                else{
                    variableList.push(checkVariable(matches[i].replace(/ /g,'')));
                    var thispara = checkVariable(matches[i].replace(/ /g,''));
                }
                
            }
            sentence = sentence + thispara+', ';
        }
        sentence = sentence.substring(0,sentence.length-2)+'):';
        //console.log(sentence);
        //console.log(variableList);
        return sentence;
    }
    else{
        console.log("def does not match");
        return label;
    }
}

var checkVariable = function(word){
    //console.log(variableList);

    for (var i = 0; i<variableList.length;i++){

        var score = CharacterErrorRate(word,variableList[i]);

        if (score >= levinThreshold){ // don't know what happened, when a, b both length == 1
            if (word.length == 1 && word != variableList[i]){
                return word;
            }
            else{
                //console.log(word, variableList[i],score);
                return variableList[i];
            }
            
        }
        // else{
        //     console.log(word, CharacterErrorRate(variableList[i], word))
            
        // }
    }
    return word
}
var checkFunction = function(word){
    for (var i = 0; i<keywords.length;i++){
        var score = CharacterErrorRate(keywords[i], word);
        if (score >= levinThreshold){
            console.log(word, keywords[i],score)
            return keywords[i];
        }
    }
    return word;
}
var process = function(sentence){
    if (sentence.startsWith('it')){
        sentence = sentence.replace('it ','if ');
    }
    if (sentence.startsWith('def')){
        sentence = def(sentence);
    }
    else if(sentence.startsWith('if')){
        sentence = ifSentence(sentence);
    }
    else if(sentence.startsWith('for')){
        sentence = forSentence(sentence);
    }
    else if(sentence.startsWith('raise')){
        sentence = raiseSentence(sentence);
    }
    else if(sentence.startsWith('return')){
        sentence = returnSentence(sentence);
    }
    else if(sentence.startsWith('Yield')){
        sentence = 'y'+sentence.substring(1,sentence.length);
        sentence = yieldSentence(sentence);
    }
    else if(sentence.startsWith('yield')){
        sentence = yieldSentence(sentence);
    }
    else if(sentence.startsWith('break')){
        sentence = 'break';
    }
    else if(sentence.indexOf(' = ')!= -1){
        sentence = normalSentence(sentence);
    }
    else if(sentence.indexOf('(')!= -1 || sentence.indexOf(')')!= -1){
        sentence = normalParenSentence(sentence);
    }

    variableList = variableList.filter( function( item, index, inputArray ) {
           return inputArray.indexOf(item) == index;
    });
    console.log(variableList);
    return sentence;  
}



var keywords = ["abs","divmod","input","open","staticmethod","all","enumerate","int","ord","any","eval","isinstance","pow","sum","basestring","execfile","issubclass","print","super","bin","file","iter","property","tuple","bool","filter","len","range","type","bytearray","float","list","raw_input","unichr","callable","format","locals","reduce","unicode","chr","frozenset","long","reload","vars","classmethod","isinstance","getattr","map","repr","xrange","cmp","globals","max","reversed","zip","compile","hasattr","memoryview","round","__import__","complex","hash","min","set","delattr","help","next","setattr","dict","hex","object","slice","dir","id","oct","sorted","and","append","args","argparse","as","assert","break","class","close","codecs","count","continue","def","del","dump","elif","else","except","exec","file","finally","for","x","from","global","if","import","in","indent","is","json","lambda","len","not","or","os","pass","raise","range","readline","return","sys","time","try","while","None","with","yield","StopIteration","SystemExit","StandardError","ArithmeticError","OverflowError","FloatingPointError","ZeroDivisonError","AssertionError","AttributeError","EOFError","ImportError","KeyboardInterrupt","LookupError","IndexError","TypeError","KeyError","NameError","CookieConflictError","UnboundLocalError","EnvironmentError","IOError","SyntaxError","IndentationError","SystemErrorSystemExit","ValueError","RuntimeError","NotImplementedError","True","False","==","+=","*=","__init__","="];

