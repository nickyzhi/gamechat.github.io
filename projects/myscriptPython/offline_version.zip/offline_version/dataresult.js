﻿
var showResult = function(){
    $("p").remove(".saveddataText");
    var index = $.jStorage.index();  // index is all keys in JStorage
    //$.jStorage.flush()   //clear jstorage content
    for (i=0;i<index.length;i++){
        if (index[i].indexOf('_1_') == -1 && index[i].indexOf('_2_') == -1){
            //var value = $.jStorage.get(index[i]);
            $('<p class="saveddataText">'+index[i]+'</p>').appendTo('#saveddata');
            return index[i];
        }
        
    }
};

var Recognize = function(){
    var key = showResult();
    //console.log(key);
    recognize($.jStorage.get(key));
}

var showMyscriptRecResult = function(){
    $("p").remove(".myscriptrecresultText");
    var index = $.jStorage.index(); 
    for (i=0;i<index.length;i++){
        if (index[i].indexOf('_result_1') != -1){
            var recresult = $.jStorage.get(index[i]);
            var consoleresult = recresult.replace(/\n/g,'</br>');
            $('<p class="myscriptrecresultText">'+consoleresult+'</p>').appendTo('#myscriptrecresult');
        }
    }
    return recresult;
}

var showPythonMyscriptRecResult = function(){
    $("p").remove(".pythonmyscriptrecresultText");
   
    var index = $.jStorage.index();  // index is all keys in JStorage
    
    //$.jStorage.flush()   //clear jstorage content
    for (i=0;i<index.length;i++){
        if (index[i].indexOf('_result_2') != -1){
            var temp = $.jStorage.get(index[i]);
            console.log(temp);
            var newrecresult = '';
            var sentences = temp.split('\n');
            for (j=0;j<sentences.length;j++){
                var postprocess = process(sentences[j]);
                newrecresult = newrecresult+postprocess+'\n';
            }
            var consoleresult = newrecresult.replace(/\n/g,'</br>');
            $('<p class="pythonmyscriptrecresultText">'+consoleresult+'</p>').appendTo('#pythonmyscriptrecresult');
        }
    }
    return newrecresult;
}

var showGoldResult = function(){
    $("p").remove(".goldresultText");
    var reference = $('#reference').val();
    var list = []
    list = reference.split('\n');
    reference = reference.replace(/\n/g, '<br />');
    $('<p class="goldresultText">'+reference+'</p>').appendTo('#goldresult');
    return list
}

var deleteData = function(){
    $.jStorage.flush() 
}
var levenshtein = function (s1, s2) {
    // init
    var d = [],
        m = s1.length,
        n = s2.length,
        i, j,cost;
    
    for (i = 0; i <= m; i++) {
        d[i] = [];
        d[i][0] = i;
    }
    for (j = 0; j <= n; j++) {
        d[0][j] = j;
    }
    
    for (j = 1; j <= n; j++) {
        for (i = 1; i <= m; i++) {
            if (s1[i] === s2[j]) {
                cost = 0;
            } 
            else {
                cost =1;
            }
            d[i][j] = Math.min(
                    d[i - 1][j] + 1, // a deletion
                    d[i][j - 1] + 1, // an insertion
                    d[i - 1][j - 1] + cost // a substitution
                )
        }
    }
    return d[m][n];
}

function listWER(testlist, goldlist){
    var sumleven = 0;
    var sumlength = 0;
    for (var i=0; i<goldlist.length;i++){
        // var s1 = testlist[i].split(" ");
        // var s2 = goldlist[i].split(" ");
        var a_tokens = testlist[i].match(/[\s,.\(\)]|[^\s,.\(\)]+/g);
        var b_tokens = goldlist[i].match(/[\s,.\(\)]|[^\s,.\(\)]+/g);
        s1 = a_tokens.filter(function(v){return v!==' '});
        s2 = b_tokens.filter(function(v){return v!==' '});
        var len = s2.length;
        sumlength += len;
        sumleven += levenshtein(s1, s2);
    }
    return 1-sumleven/sumlength;
}

function listCER(testlist, goldlist){
    var sumleven = 0;
    var sumlength = 0;
    for (var i=0; i<goldlist.length;i++){
        var s1 = testlist[i].split("");
        var s2 = goldlist[i].split("");
        var len = s2.length;
        sumlength += len;
        sumleven += levenshtein(s1, s2);
        console.log(testlist[i],goldlist[i],levenshtein(s1,s2));
    }
    return 1-sumleven/sumlength;
}
function WordErrorRate(a, b) {

    var a_tokens = a.match(/[\s,.\(\)]|[^\s,.\(\)]+/g);
    var b_tokens = b.match(/[\s,.\(\)]|[^\s,.\(\)]+/g);
    s1 = a_tokens.filter(function(v){return v!==' '});
    s2 = b_tokens.filter(function(v){return v!==' '});
    //console.log(levenshtein(s1, s2),s2.length);
    return 1-levenshtein(s1, s2)/s2.length;
};
function CharacterErrorRate(a, b) {
    var s1 = a.split("");
    var s2 = b.split("");
    //console.log(s1,s2,levenshtein(s1, s2),s2.length);
    return 1-levenshtein(s1, s2)/s2.length;
};
function sortlist(a, b) {
    if (a[1] === b[1]) {
        return 0;
    }
    else {
        return (a[1] > b[1]) ? -1 : 1;
    }
};

//select best sentence from result
function SentenceSelection(sentencelist,goldlist){
    var newlist = [];
    for(var i=0;i<sentencelist.length;i++){
        var seplist = [];
        for (var j=0;j<sentencelist[i].length;j++){
            var obj = [];
            obj[0] = sentencelist[i][j];
            obj[1] = WordErrorRate(sentencelist[i][j], goldlist[i]);
            seplist.push(obj);
        }
        var sortedseplist = seplist.sort(sortlist);
        newlist.push(sortedseplist[0][0]);
    }
    console.log(newlist);
    return newlist
};

// Initialisations to be done immediately after the page is loaded


    document.getElementById("showData").addEventListener("click", showResult, false);
    document.getElementById("activerecognize").addEventListener("click", Recognize, false);
    document.getElementById("showMyscriptRecResult").addEventListener("click", showMyscriptRecResult, false);
    document.getElementById("showPythonMyscriptRecResult").addEventListener("click", showPythonMyscriptRecResult, false);
    document.getElementById("deleteData").addEventListener("click", deleteData, false);
    document.getElementById("showGoldResult").addEventListener("click", showGoldResult, false);
    document.getElementById("similarity").addEventListener("click", function(){
        $("p").remove(".evalresultText");
        var goldList = showGoldResult();
        var recresult = showMyscriptRecResult();
        var recresultList = [];
        recresultList = recresult.split('\n');
        var myscriptscore = listWER(recresultList,goldList).toFixed(3);
        var myscriptscore1 = listCER(recresultList,goldList).toFixed(3);
        $('<p class="evalresultText"> Myscript  ' +myscriptscore + '    '+myscriptscore1+'<br/>'+'</p>').appendTo('#evalresult');
        var python_recresult = showPythonMyscriptRecResult();
        var python_recresultList = [];
        python_recresultList = python_recresult.split('\n');
        var pythonmyscriptscore = listWER(python_recresultList,goldList).toFixed(3);
        var pythonmyscriptscore1 = listCER(python_recresultList,goldList).toFixed(3);
        $('<p class="evalresultText"> PythonMyscript  '+pythonmyscriptscore +'    '+pythonmyscriptscore1+ '<br/>'+'</p>').appendTo('#evalresult');
                
    }, false);


