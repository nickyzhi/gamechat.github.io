﻿// Global vars
var inkCanvas;					// Canvas where scripter writes
var inkContext;					// Context of the ink canvas
var pointerDown = [];		// True when scripter is writing (between penDown and penUp)

var stroke;							// The current stroke being drawn
var strokes = [];				// The stroke collection
var strokesSave = [];		// The undo buffer

var recoResult;					// Contains the recognition result
var resultIdx;					// Index of the current selected result candidate
var wordInfos = [];			// The label and enclosing rectangle of recognized words

var language = 'en_US';	// Holds current language ISO code
var transparency = 4;		// Transparency of the text layer
var result;
// Check if the user clicked in the orange rectangle (link to Wikipedia)
var ptInRect = function (aPt, aRect) {
	if ((aPt.x >= aRect.left) && (aPt.x <= aRect.right) && (aPt.y >= aRect.bottom - 2) && (aPt.y <= aRect.bottom + 6)) {
		return true;
	}
	return false;
};

// Convert global cursor position to coordinates local to the canvas
var getCursorPosition = function (event) {
  var rect = inkCanvas.getBoundingClientRect();
	return {x: event.clientX - rect.left, y: event.clientY - rect.top};
}

var onPointerDown = function (evt) {
	var aPt = getCursorPosition(evt);
	for(var idx = 0; idx < wordInfos.length; idx++) {
		// If user clicked into the orange rectangle, open a Wikipedia page
		if (ptInRect(aPt, wordInfos[idx])) {
			window.open('http://en.wikipedia.org/wiki/' + wordInfos[idx].label, '_blank', 'top=200, left=200, width=600, height=400, location=no, menubar=no, toolbar=no');
			return;
		}
	}
	pointerDown[evt.pointerId] = true;
	var timestamp = new Date();
	stroke = {"type":"stroke", "x" : [aPt.x], "y" : [aPt.y], "timestamp" : [timestamp.getTime()]};
	
};

var onPointerMove = function(evt) {
	if (pointerDown[evt.pointerId]) {
		//Get points for this pointerId
		var aPt = getCursorPosition(evt);
		//Paint path
		inkContext.beginPath();
		inkContext.moveTo(stroke.x[stroke.x.length - 1], stroke.y[stroke.x.length - 1]);
		inkContext.lineTo(aPt.x, aPt.y);
		inkContext.stroke();
		//Store point
		stroke.x.push(aPt.x);
		stroke.y.push(aPt.y);
  	}

  	
};

var onPointerUp = function (evt) {

	if (pointerDown[evt.pointerId]) {
		var lastPt = {"x" : stroke.x[stroke.x.length - 1], "y" : stroke.y[stroke.x.length - 1]};
		inkContext.beginPath();
		if (stroke.x.length == 1) {
			inkContext.arc(lastPt.x, lastPt.y, inkContext.lineWidth, 0, 2 * Math.PI);
			inkContext.fill();
		} else {
			inkContext.moveTo(stroke.x[stroke.x.length - 2], stroke.y[stroke.x.length - 2]);
			inkContext.lineTo(lastPt.x, lastPt.y);
			inkContext.stroke();
		}
		var timestamp = new Date();
  		stroke.timestamp.push(timestamp.getTime());
		console.log(stroke);
		pointerDown[evt.pointerId] = false;
		strokes.push(stroke);
		while(strokesSave.length != 0) strokesSave.pop();
		//console.log(strokes);
		//download(strokes);
		result = strokes;

  }    
};

// Draw onto the canvas the given stroke
var paintStroke = function (aStroke) {
	inkContext.beginPath();
	// If stroke is a single point, make it wide enough to be visible.
	if (aStroke.x.length == 1) {
		inkContext.arc(aStroke.x[0], aStroke.y[0], inkContext.lineWidth, 2, 2 * Math.PI);
		inkContext.fill();
	} else {	
		for (var idx = 0; idx < aStroke.x.length; idx++) {
			inkContext.moveTo (aStroke.x[idx], aStroke.y[idx]);
			inkContext.lineTo (aStroke.x[idx + 1], aStroke.y[idx + 1]);
		}
		inkContext.stroke();
	}
};

// When user clicks the clear button:
//  1. empty the strokes array
//  2. empty the undo buffer
//  3. clear the canvas
//  4. clear the candidates zone
//  5. reset the undo & redo buttons
var onClearClick = function (evt) {
	while (strokes.length != 0) strokes.pop();
	while (strokesSave.length != 0) strokesSave.pop();
	initCanvas();
	$("#result").text("");
	$("#redo").attr("src", "images/redo_disabled.png");
	$("#undo").attr("src", "images/undo_disabled.png");
};

// When user clicks the undo button:
//  1. remove the last stroke from the strokes array and save it into the undo buffer
//  2. clear the canvas and redraw remaining strokes
//  3. clear the candidates zone if no more strokes
//  4. set the undo & redo buttons
//  5. relaunch the recognition process
var onUndoClick = function (evt) {
	if (strokes.length > 0) {
		strokesSave.push(strokes.pop());
		initCanvas();
		if (strokes.length > 0) {
			for (var idx = 0; idx < strokes.length; idx++) {
				paintStroke(strokes[idx]);
			}
		} else {
			$("#result").text("");
			$("#undo").attr("src", "images/undo_disabled.png");
		}
		$("#redo").attr("src", "images/redo.png");
		console.log(strokes);
		return strokes;
	}
};

// When user clicks the redo button:
//  1. restore the last stroke from the undo buffer into the strokes array 
//  2. clear the canvas and redraw all strokes
//  3. set the undo & redo buttons
//  4. relaunch the recognition process
var onRedoClick = function (evt) {
	if(strokesSave.length > 0) {
		strokes.push(strokesSave.pop());
		initCanvas();
		for(var idx = 0; idx < strokes.length; idx++) {
			paintStroke(strokes[idx]);
		}
		$("#undo").attr("src", "images/undo.png");
		if(strokesSave.length == 0)
			$("#redo").attr("src", "images/redo_disabled.png");
		console.log(strokes);
		return strokes;
	}
};
// ##################################################################################################
// ## Recognition functions
// ##################################################################################################
// The recognition process : make an http call to MyScript Web Services
// input: language + strokes + parameters
// output: text candidates



var download = function(){
	var name = $('#name').val();
	var number = $('#number').val();
	var key = name+ '_' +number;
	console.log(key);
	$.jStorage.set(key, result);
	alert("save successfully as key: "+key);
};

var showResult = function(){
	var index = $.jStorage.index();  // index is all keys in JStorage
	alert(index);
	//$.jStorage.flush()   //clear jstorage content
	for (i=0;i<index.length;i++){
		console.log($.jStorage.get(index[i]));
	}
};


// ##################################################################################################
// ## Initialisation functions
// ##################################################################################################
// Initialize the inkCanvas
var initCanvas = function() {
	inkContext.clearRect(0, 0, inkCanvas.width, inkCanvas.height);
	
	// Draw the base line in light grey
	inkContext.lineWidth = '1';
	inkContext.strokeStyle = '#CCC';		
	inkContext.beginPath();
	inkContext.moveTo(10, 30 + inkCanvas.height / 2);
	inkContext.lineTo(inkCanvas.width - 10, 30 + inkCanvas.height / 2);
	inkContext.stroke();

	// Set defaults values for writing
	inkContext.lineWidth = 2;
	inkContext.lineCap = "round";
	inkContext.lineJoin = "round";
	inkContext.fillStyle = "blue";
	inkContext.strokeStyle = "blue";
	return inkContext;
};

// Initialisations to be done immediately after the page is loaded
var onload = function() {
	// Set canvas size and initial content
	inkCanvas = document.getElementById("inkCanvas");
	inkCanvas.width = inkCanvas.clientWidth;
	inkCanvas.height = inkCanvas.clientHeight;
	inkContext = inkCanvas.getContext("2d");
	initCanvas();

	// Add event listener to the canvas
	inkCanvas.addEventListener("PointerDown", onPointerDown, false);
	inkCanvas.addEventListener("PointerMove", onPointerMove, false);
	inkCanvas.addEventListener("PointerUp", onPointerUp, false);
	inkCanvas.addEventListener("PointerOut", onPointerUp, false);

	// Add event listener to all the buttons of the user interface
	document.getElementById("clear").addEventListener("click", onClearClick, false);
	document.getElementById("undo").addEventListener("click", onUndoClick, false);
	document.getElementById("redo").addEventListener("click", onRedoClick, false);
	document.getElementById("download").addEventListener("click", download, false);
	document.getElementById("showData").addEventListener("click", showResult, false);
	// Prevent elastic scrolling for iPad/iPhone
	inkCanvas.addEventListener('touchmove', function(event){event.preventDefault();}, false);

	window.addEventListener('resize', function(){
		inkCanvas.width = inkCanvas.clientWidth;
		inkCanvas.height = inkCanvas.clientHeight;
	}, false);
};

if (document.addEventListener !== undefined) {
	document.addEventListener("DOMContentLoaded", onload, false);
}