
var download = function(){
    var name = $('#name').val();
    var number = $('#number').val();
    var key = name+ '_' +number;
    console.log(key);
    $.jStorage.set(key, result);
    alert("save successfully as key: "+key);
};

var showResult = function(){
    $("p").remove(".saveddataText");
    var index = $.jStorage.index();  // index is all keys in JStorage
    //$.jStorage.flush()   //clear jstorage content
    for (i=0;i<index.length;i++){
        var value = $.jStorage.get(index[i]);
        $('<p class="saveddataText">'+index[i]+':     '+value+'</p>').appendTo('#saveddata');
    }
};

var showMyscriptRecResult = function(){
    $("p").remove(".myscriptrecresultText");
    var name = $('#name').val();
    var number = $('#number').val();
    var key = name+ '_' +number;
    //console.log(key);
    recognize($.jStorage.get(key));
    var index = $.jStorage.index();  // index is all keys in JStorage
    
    //$.jStorage.flush()   //clear jstorage content
    for (i=0;i<index.length;i++){
        if (index[i].indexOf(name+'_'+number+'_result_1')==0){
            var recresult = $.jStorage.get(index[i]);
            console.log(recresult);
            $('<p class="myscriptrecresultText">'+recresult+'</p>').appendTo('#myscriptrecresult');
        }
    }
    
}

var showPythonMyscriptRecResult = function(){
    $("p").remove(".pythonmyscriptrecresultText");
    var name = $('#name').val();
    var number = $('#number').val();
    var key = name+ '_' +number;
    //console.log(key);
    recognize($.jStorage.get(key));
    var index = $.jStorage.index();  // index is all keys in JStorage
    
    //$.jStorage.flush()   //clear jstorage content
    for (i=0;i<index.length;i++){
        if (index[i].indexOf(name+'_'+number+'_result_2')==0){
            var recresult = $.jStorage.get(index[i]);
            console.log(recresult);
            $('<p class="pythonmyscriptrecresultText">'+recresult+'</p>').appendTo('#pythonmyscriptrecresult');
        }
    }
}

var showGoldResult = function(){
    $("p").remove(".goldresultText");
    var reference = $('#reference').val();
    console.log(reference);
    $('<p class="goldresultText">'+reference+'</p>').appendTo('#goldresult');
}

var deleteData = function(){
    $.jStorage.flush() 
}

var levenshtein = function (s1, s2) {
    // init
    var d = [],
        m = s1.length,
        n = s2.length,
        i, j,cost;
    for (i = 0; i <= m; i++) {
        d[i] = [];
        d[i][0] = i;
    }
    for (j = 0; j <= n; j++) {
        d[0][j] = j;
    }
    
    for (j = 1; j <= n; j++) {
        for (i = 1; i <= m; i++) {
            if (s1[i] === s2[j]) {
                cost = 0;
            } 
            else {
                cost =1;
            }
            d[i][j] = Math.min(
                    d[i - 1][j] + 1, // a deletion
                    d[i][j - 1] + 1, // an insertion
                    d[i - 1][j - 1] + cost // a substitution
                )
        }
    }
    return d[m][n];
}

function WordErrorRate(a, b) {
    var s1 = a.split(" ");
    var s2 = b.split(" ");
    console.log(levenshtein(s1, s2),s2.length);
    return levenshtein(s1, s2);
};
function CharacterErrorRate(a, b) {
    var s1 = a.split("");
    var s2 = b.split("");
    console.log(levenshtein(s1, s2),s2.length);
    return levenshtein(s1, s2);
};

// Initialisations to be done immediately after the page is loaded


    document.getElementById("showData").addEventListener("click", showResult, false);
    document.getElementById("showMyscriptRecResult").addEventListener("click", showMyscriptRecResult, false);
    document.getElementById("showPythonMyscriptRecResult").addEventListener("click", showPythonMyscriptRecResult, false);
    document.getElementById("deleteData").addEventListener("click", deleteData, false);
    document.getElementById("showGoldResult").addEventListener("click", showGoldResult, false);
    document.getElementById("similarity").addEventListener("click", function(){
        $("p").remove(".evalresultText");
        var name = $('#name').val();
        var number = $('#number').val();
        // var key = name+ '_' +number;
        // var reference = $('#reference').val();
        // var Myscriptcount = 0;
        // var PythonMyscriptcount = 0;
        // var index = $.jStorage.index();  // index is all keys in JStorage
        // //$.jStorage.flush()   //clear jstorage content
        // for (i=0;i<index.length;i++){
        //     if (index[i].indexOf(key+'_result_1')==0){
        //         Myscriptcount += 1;
        //         var recresult = $.jStorage.get(index[i]);
        //         var score = similarity(recresult,reference);
        //         $('<p class="evalresultText"> Myscript '+Myscriptcount+": ("+recresult+")  :"+score+'</p>').appendTo('#evalresult');
        //     }
            
        //     if (index[i].indexOf(key+'_result_2')==0){
        //         PythonMyscriptcount += 1;
        //         var recresult = $.jStorage.get(index[i]);
        //         var score = similarity(recresult,reference);
        //         $('<p class="evalresultText"> PythonMyscript '+PythonMyscriptcount+": ("+recresult+")  :"+score+'</p>').appendTo('#evalresult');
        //     }
        // }
        var score1 = WordErrorRate(name,number);
        var score2 = CharacterErrorRate(name,number);
        $('<p class="evalresultText">' +score1+'    '+score2+'</p>').appendTo('#evalresult');
    }, false);


