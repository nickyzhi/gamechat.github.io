var candidateSize = 1;
var recognize = function(strokes) {
    var namekey = showResult();
    
    var aStr = [];
    var apiKey = "6472cc16-e3a6-4ba9-821d-7de3827d959b";
    var url = "http://cloud.myscript.com/api/v3.0/recognition/rest/text/doSimpleRecognition.json";
       
  

    var jsonPost = {
        'textParameter': {
            'textInputMode': 'CURSIVE',
            'resultDetail': 'TEXT',
            'language': 'en_US',
            "textProperties": {
                "textCandidateListSize": candidateSize
            },
            'contentTypes': ['text'],
            'userResources': ['pythonKeywords', 'python']
        },
        "inputUnits": [{
            "components": strokes
        }]

    };
    var data = {
        "applicationKey" : apiKey,
        "textInput" : JSON.stringify(jsonPost)
    };

    var jsonPost1 = {
        'textParameter': {
            'textInputMode': 'CURSIVE',
            'resultDetail': 'TEXT',
            'language': 'en_US',
            "textProperties": {
                "textCandidateListSize": candidateSize
            },
            'contentTypes': ['text']
        },
        "inputUnits": [{
            "components": strokes
        }]

    };
    
    var data1 = {
        "applicationKey" : apiKey,
        "textInput" : JSON.stringify(jsonPost1)
    };
    $.post(
        url, 
      data, 
      function(jsonResult) {
            //console.log("Python myscript output");
            recoResult = jsonResult.result;
            resultIdx = recoResult.textSegmentResult.selectedCandidateIdx;
            if ((resultIdx >= 0) && (recoResult.textSegmentResult.candidates.length > 0)) {
                for (var idx = 0; idx < candidateSize; idx++) {
                    //var result = sumprocess(recoResult.textSegmentResult.candidates[idx].label)
                    var result = recoResult.textSegmentResult.candidates[idx].label;
                    console.log(result);
                    var key = namekey+ '_result_2_'+idx;
                    $.jStorage.set(key, result);

                    //console.log(key,result);
                }
            }
      },
      "json"
    );
    $.post(
        url, 
      data1, 
      function(jsonResult) {
            //console.log("myscript output");
            recoResult = jsonResult.result;
            resultIdx = recoResult.textSegmentResult.selectedCandidateIdx;
            if ((resultIdx >= 0) && (recoResult.textSegmentResult.candidates.length > 0)) {
                for (var idx = 0; idx < candidateSize; idx++) {
                    var key = namekey+ '_result_1_'+idx;
                    $.jStorage.set(key, recoResult.textSegmentResult.candidates[idx].label);
                    console.log(recoResult.textSegmentResult.candidates[idx].label);
                }
            }
      },
      "json"
    );

};